# This file contains code not normally of concern to the API user

from ctypes import *
import os
import sys
import platform

from TdhGIS_API_universal import *

if (platform.system() == "Linux") :
  TdhGISnet_API = CDLL(libDir+"libTdhGISnet_API_py.so")
if (platform.system() == "Windows") :
  TdhGISnet_API = cdll.LoadLibrary(libDir+"TdhGISnet_API_py.dll") 


def Set_TdhGISnet_Cfuncs ():
    TdhGISnet_API.Create_TdhGISnetIO_py.restype = c_void_p

    TdhGISnet_API.Delete_TdhGISnetIO_py.argtypes = [c_void_p]

    TdhGISnet_API.TdhGISnetIO_SetDB.argtypes = [c_void_p, c_char_p]
    TdhGISnet_API.TdhGISnetIO_SetDB.restype = c_bool

    TdhGISnet_API.TdhGISnetIO_ReadNetwork.argtypes = [c_void_p, c_char_p, c_void_p]
    TdhGISnet_API.TdhGISnetIO_ReadNetwork.restype = c_bool

    TdhGISnet_API.TdhGISnetIO_WriteNetwork.argtypes = [c_void_p, c_void_p]
    TdhGISnet_API.TdhGISnetIO_WriteNetwork.restype = c_bool

    TdhGISnet_API.TdhGISnetIO_DeleteNetwork.argtypes = [c_void_p, c_char_p]

    TdhGISnet_API.TdhGISnetIO_ImportOSM.argtypes = [c_void_p, c_char_p, c_void_p, c_void_p, c_void_p]
    TdhGISnet_API.TdhGISnetIO_ImportOSM.restype = c_bool

    TdhGISnet_API.Create_GisNetwork_py.restype = c_void_p

    TdhGISnet_API.Delete_GisNetwork_py.argtypes = [c_void_p]