# This file contains code not normally of concern to the API user

from ctypes import *
import os
import sys
import platform

from TdhGIS_API_universal import *

if (platform.system() == "Linux") :
  TdhPath = CDLL(libDir+"libTdhPath_API_py.so")
if (platform.system() == "Windows") :
  TdhPath = cdll.LoadLibrary(libDir+"TdhPath_Py.dll") 

def Set_NetNode_Cfuncs ():
  TdhPath.TNetNode_Network.argtypes = [c_void_p]
  TdhPath.TNetNode_Network.restype = c_void_p

  TdhPath.TNetNode_NodeID.argtypes = [c_void_p]
  TdhPath.TNetNode_NodeID.restype = c_char_p

  TdhPath.TNetNode_set_NodeID.argtypes = [c_void_p, c_char_p]

  TdhPath.TNetNode_AutoDelete.argtypes = [c_void_p]
  TdhPath.TNetNode_AutoDelete.restype = c_bool

  TdhPath.TNetNode_set_AutoDelete.argtypes = [c_void_p, c_bool]

  TdhPath.TNetNode_set_Temp.argtypes = [c_void_p, c_bool]

  TdhPath.TNetNode_Temp.argtypes = [c_void_p]
  TdhPath.TNetNode_Temp.restype = c_bool

  TdhPath.TNetNode_DownLink.argtypes = [c_void_p]
  TdhPath.TNetNode_DownLink.restype = c_void_p

  TdhPath.TNetNode_DownNode.argtypes = [c_void_p]
  TdhPath.TNetNode_DownNode.restype = c_void_p

  TdhPath.TNetNode_DownConn.argtypes = [c_void_p]
  TdhPath.TNetNode_DownConn.restype = c_void_p

  TdhPath.TNetNode_TravVal.argtypes = [c_void_p]
  TdhPath.TNetNode_TravVal.restype = c_double

  TdhPath.TNetNode_LinkCount.argtypes = [c_void_p]
  TdhPath.TNetNode_LinkCount.restype = c_int

  TdhPath.TNetNode_GetLink.argtypes = [c_void_p, c_void_p]
  TdhPath.TNetNode_GetLink.restype = c_void_p

  TdhPath.TNetNode_InitForTraverse.argtypes = [c_void_p]

  TdhPath.TNetNode_ResetForTraverse.argtypes = [c_void_p]

  TdhPath.TNetNode_Segment.argtypes = [c_void_p]
  TdhPath.TNetNode_Segment.restype = c_uint

  TdhPath.TNetNode_set_Segment.argtypes = [c_void_p, c_uint]

  TdhPath.TNetNode_ConnNav.argtypes = [c_void_p]
  TdhPath.TNetNode_ConnNav.restype = c_void_p

  TdhPath.TNetNode_set_DownConn.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetNode_PopQueue.argtypes = [c_void_p]
  TdhPath.TNetNode_PopQueue.restype = c_void_p

  TdhPath.TNetNode_PushQueue.argtypes = [c_void_p]
  TdhPath.TNetNode_PushQueue.restype = c_void_p

  TdhPath.TNetNode_getX.argtypes = [c_void_p]
  TdhPath.TNetNode_getX.restype = c_double

  TdhPath.TNetNode_getY.argtypes = [c_void_p]
  TdhPath.TNetNode_getY.restype = c_double

  TdhPath.TNetNode_set_Y.argtypes = [c_void_p, c_double]

  TdhPath.TNetNode_set_X.argtypes = [c_void_p, c_double]

  TdhPath.TNetNode_Pt_ptr.argtypes == [c_void_p]
  TdhPath.TNetNode_Pt_ptr.restype = c_void_p

  TdhPath.TNetNode_Radius.argtypes = [c_void_p]
  TdhPath.TNetNode_Radius.restype = c_double

  TdhPath.TNetNode_set_Radius.argtypes = [c_void_p, c_double]

  TdhPath.TNetNode_Radius_cord.argtypes = [c_void_p]
  TdhPath.TNetNode_Radius_cord.restype = c_double

  TdhPath.TNetNode_set_Radius_cord.argtypes = [c_void_p, c_double]

  TdhPath.TNetNode_Color.argtypes = [c_void_p]
  TdhPath.TNetNode_Color.restype = c_uint

  TdhPath.TNetNode_set_Color.argtypes = [c_void_p, c_uint]

  TdhPath.TNetNode_ColorFlag.argtypes = [c_void_p]
  TdhPath.TNetNode_ColorFlag.restype = c_int

  TdhPath.TNetNode_set_ColorFlag.argtypes = [c_void_p, c_int]

  TdhPath.TNetNode_Width.argtypes = [c_void_p]
  TdhPath.TNetNode_Width.restype = c_char

  TdhPath.TNetNode_set_Width.argtypes = [c_void_p, c_char]

  TdhPath.Create_NetNode.restype = c_void_p
  TdhPath.Create_NetNode.argtypes = [c_void_p]

  TdhPath.Delete_NetNode.argtypes = [c_void_p]

def Set_NetLink_Cfuncs ():
  TdhPath.TNetLink_Network.argtypes = [c_void_p]
  TdhPath.TNetLink_Network.restype = c_void_p

  TdhPath.TNetLink_LinkID.argtypes = [c_void_p]
  TdhPath.TNetLink_LinkID.restype = c_char_p

  TdhPath.TNetLink_set_LinkID.argtypes = [c_void_p, c_char_p]

  TdhPath.TNetLink_Node1.argtypes = [c_void_p]
  TdhPath.TNetLink_Node1.restype = c_void_p

  TdhPath.TNetLink_Node2.argtypes = [c_void_p]
  TdhPath.TNetLink_Node2.restype = c_void_p

  TdhPath.TNetLink_set_Node1.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetLink_set_Node2.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetLink_get_Node.argtypes = [c_void_p, c_char]
  TdhPath.TNetLink_get_Node.restype = c_void_p

  TdhPath.TNetLink_set_Node.argtypes = [c_void_p, c_char, c_void_p, c_bool]

  TdhPath.TNetLink_set_NodeByKey.argtypes = [c_void_p, c_char, c_char_p]

  TdhPath.TNetLink_CreateConn.argtypes = [c_void_p, c_char]
  TdhPath.TNetLink_CreateConn.restype = c_void_p

  TdhPath.TNetLink_Restrict.argtypes = [c_void_p]
  TdhPath.TNetLink_Restrict.restype = c_int

  TdhPath.TNetLink_set_Restrict.argtypes = [c_void_p, c_int]

  TdhPath.TNetLink_TempClosed.argtypes = [c_void_p]
  TdhPath.TNetLink_TempClosed.restype = c_bool

  TdhPath.TNetLink_Status.argtypes = [c_void_p, c_bool]
  TdhPath.TNetLink_Status.restype = c_char

  TdhPath.TNetLink_Value.argtypes = [c_void_p]
  TdhPath.TNetLink_Value.restype = c_double

  TdhPath.TNetLink_set_Value.argtypes = [c_void_p, c_double]

  TdhPath.TNetLink_set_Temp.argtypes = [c_void_p, c_bool]

  TdhPath.TNetLink_Temp.argtypes = [c_void_p]
  TdhPath.TNetLink_Temp.restype = c_bool

  TdhPath.TNetLink_Network.SplitAttributes = [c_void_p, c_void_p, c_void_p, c_double]

  TdhPath.TNetLink_unSplitAttributes.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetLink_CopyDataTo.argtypes = [c_void_p, c_void_p]
  TdhPath.TNetLink_CopyDataTo.restype = c_void_p

  TdhPath.TNetLink_InitForTraverse.argtypes = [c_void_p]

  TdhPath.TNetLink_ResetForTraverse.argtypes = [c_void_p]

  TdhPath.TNetLink_Radius.argtypes = [c_void_p]
  TdhPath.TNetLink_Radius.restype = c_double

  TdhPath.TNetLink_set_Radius.argtypes = [c_void_p, c_double]

  TdhPath.TNetLink_Radius_cord.argtypes = [c_void_p]
  TdhPath.TNetLink_Radius_cord.restype = c_double

  TdhPath.TNetLink_set_Radius_cord.argtypes = [c_void_p, c_double]

  TdhPath.TNetLink_LabelPt_getX.argtypes = [c_void_p]
  TdhPath.TNetLink_LabelPt_getX.restype = c_double

  TdhPath.TNetLink_LabelPt_getY.argtypes = [c_void_p]
  TdhPath.TNetLink_LabelPt_getY.restype = c_double

  TdhPath.TNetLink_LabelPt_ptr.argtypes = [c_void_p]
  TdhPath.TNetLink_LabelPt_ptr.restype = c_void_p


  TdhPath.TNetLink_Color.argtypes = [c_void_p]
  TdhPath.TNetLink_Color.restype = c_uint

  TdhPath.TNetLink_set_Color.argtypes = [c_void_p, c_uint]

  TdhPath.TNetLink_ColorFlag.argtypes = [c_void_p]
  TdhPath.TNetLink_ColorFlag.restype = c_int

  TdhPath.TNetLink_set_ColorFlag.argtypes = [c_void_p, c_int]

  TdhPath.TNetLink_Width.argtypes = [c_void_p]
  TdhPath.TNetLink_Width.restype = c_char

  TdhPath.TNetLink_set_Width.argtypes = [c_void_p, c_char]

  TdhPath.TNetLink_MultiLine.argtypes = [c_void_p]
  TdhPath.TNetLink_MultiLine.restype = c_void_p

  TdhPath.TNetLink_CalcLength.argtypes = [c_void_p]
  TdhPath.TNetLink_CalcLength.restype = c_double

  TdhPath.TNetLink_GetExtents.argtypes = [c_void_p]
  TdhPath.TNetLink_GetExtents.restype = c_void_p

  TdhPath.TNetLink_NearestPt.argtypes = [c_void_p, c_void_p, c_void_p]

  TdhPath.TNetLink_ToMultiLine.argtypes = [c_void_p]
  TdhPath.TNetLink_ToMultiLine.restype = c_void_p

  TdhPath.TNetLink_FromMultiLine.argtypes = [c_void_p, c_void_p, c_bool]

  TdhPath.TNetLink_SplitMultiline.argtypes = [c_void_p, c_void_p, c_void_p, c_double]
  TdhPath.TNetLink_SplitMultiline.restype = c_bool

  TdhPath.TNetLink_GetNodeCords.argtypes = [c_void_p, c_int, c_void_p]

  TdhPath.TNetLink_GetNodeRadius.argtypes = [c_void_p, c_int]
  TdhPath.TNetLink_GetNodeRadius.restype = c_double

  TdhPath.Create_NetLink.argtypes = [c_void_p] # 1st param is a TtdhNetwork0
  TdhPath.Create_NetLink.restype = c_void_p

  TdhPath.Delete_NetLink.argtypes = [c_void_p]


def Set_NetConn_Cfuncs ():
  TdhPath.TNetConn0_Link.argtypes = [c_void_p]
  TdhPath.TNetConn0_Link.restype = c_void_p

  TdhPath.TNetConn0_LinkID.argtypes = [c_void_p]
  TdhPath.TNetConn0_LinkID.restype = c_char_p

  TdhPath.TNetConn0_set_ConnNode.argtypes = [c_void_p, c_void_p, c_void_p]

  TdhPath.TNetConn0_ConnNode.argtypes = [c_void_p]
  TdhPath.TNetConn0_ConnNode.restype = c_void_p

  TdhPath.TNetConn0_OppConn.argtypes = [c_void_p]
  TdhPath.TNetConn0_OppConn.restype = c_void_p

  TdhPath.TNetConn0_DownConn.argtypes = [c_void_p]
  TdhPath.TNetConn0_DownConn.restype = c_void_p

  TdhPath.TNetConn0_Dir.argtypes = [c_void_p]
  TdhPath.TNetConn0_Dir.restype = c_char

  TdhPath.TNetConn0_NextConn.argtypes = [c_void_p]
  TdhPath.TNetConn0_NextConn.restype = c_void_p


def Set_Network_Cfuncs ():
  TdhPath.TNetwork_Traverse.argtypes = [c_void_p]
  TdhPath.TNetwork_Traverse.restype = c_void_p

  TdhPath.TNetwork_NoDraw.argtypes = [c_void_p]
  TdhPath.TNetwork_NoDraw.restype = c_bool

  TdhPath.TNetwork_set_NoDraw.argtypes = [c_void_p, c_bool]

  TdhPath.TNetwork_Create_Node0.argtypes = [c_void_p]
  TdhPath.TNetwork_Create_Node0.restype = c_void_p

  TdhPath.TNetwork_Create_Link0.argtypes = [c_void_p]
  TdhPath.TNetwork_Create_Link0.restype = c_void_p

  TdhPath.TNetwork_NodeNav.argtypes = [c_void_p]
  TdhPath.TNetwork_NodeNav.restype = c_void_p

  TdhPath.TNetwork_LinkNav.argtypes = [c_void_p]
  TdhPath.TNetwork_LinkNav.restype = c_void_p

  TdhPath.TNetwork_set_NodeNav.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetwork_set_LinkNav.argtypes = [c_void_p, c_void_p]

  TdhPath.TNetwork_Create_NodeNav.argtypes = [c_void_p, c_bool]
  TdhPath.TNetwork_Create_NodeNav.restype = c_void_p

  TdhPath.TNetwork_Create_LinkNav.argtypes = [c_void_p, c_bool]
  TdhPath.TNetwork_Create_LinkNav.restype = c_void_p

  TdhPath.TNetwork_DeleteConns.argtypes = [c_void_p]

  TdhPath.TNetwork_NetID.argtypes = [c_void_p]
  TdhPath.TNetwork_NetID.restype = c_char_p

  TdhPath.TNetwork_set_NetID.argtypes = [c_void_p, c_char_p]

  TdhPath.TNetwork_AddNode.argtypes = [c_void_p, c_char_p, c_bool]
  TdhPath.TNetwork_AddNode.restype = c_void_p

  TdhPath.TNetwork_AddLink.argtypes = [c_void_p, c_char_p, c_bool]
  TdhPath.TNetwork_AddLink.restype = c_void_p

  TdhPath.TNetwork_GetNode.argtypes = [c_void_p, c_char_p, c_bool]
  TdhPath.TNetwork_GetNode.restype = c_void_p

  TdhPath.TNetwork_DeleteNode.argtypes = [c_void_p, c_void_p]
  TdhPath.TNetwork_DeleteNode.restype = c_bool

  TdhPath.TNetwork_SplitLink.argtypes = [c_void_p, c_void_p, c_double, c_char_p, c_void_p, c_void_p]
  TdhPath.TNetwork_SplitLink.restype = c_void_p

  TdhPath.TNetwork_FindConnectedLink.argtypes = [c_void_p, c_char_p, c_char_p]
  TdhPath.TNetwork_FindConnectedLink.restype = c_void_p

  TdhPath.TNetwork_Reset.argtypes = [c_void_p]

  TdhPath.TNetwork_Description.argtypes = [c_void_p]
  TdhPath.TNetwork_Description.restype = c_char_p

  TdhPath.TNetwork_set_Description.argtypes = [c_void_p, c_char_p]

  TdhPath.TNetwork_get_defaultColor.argtypes = [c_void_p]
  TdhPath.TNetwork_get_defaultColor.restype = c_uint

  TdhPath.TNetwork_PopQueueHead.argtypes = [c_void_p]
  TdhPath.TNetwork_PopQueueHead.restype = c_void_p

  TdhPath.Create_TdhNetwork_py.restype = c_void_p
  TdhPath.Delete_TdhNetwork_py.argtypes = [c_void_p]

  #TdhPath.Create_NodeNav.restype = c_void_p


def Set_TargetNode_Cfuncs ():
  TdhPath.TargetNode_NodeID.argtypes = [c_void_p]
  TdhPath.TargetNode_NodeID.restype = c_char_p

  TdhPath.TargetNode_set_NodeID.argtypes = [c_void_p, c_char_p]

  TdhPath.TargetNode_GetKey.argtypes = [c_void_p]
  TdhPath.TargetNode_GetKey.restype = c_void_p

  TdhPath.TargetNode_StartFlag.argtypes = [c_void_p]
  TdhPath.TargetNode_StartFlag.restype = c_bool

  TdhPath.TargetNode_set_StartFlag.argtypes = [c_void_p, c_bool]

  TdhPath.TargetNode_EndFlag.argtypes = [c_void_p]
  TdhPath.TargetNode_EndFlag.restype = c_bool
  
  TdhPath.TargetNode_set_EndFlag.argtypes = [c_void_p, c_bool]

  TdhPath.TargetNode_IntermediateFlag.argtypes = [c_void_p]
  TdhPath.TargetNode_IntermediateFlag.restype = c_bool

  TdhPath.TargetNode_set_IntermediateFlag.argtypes = [c_void_p, c_bool]

  TdhPath.Create_TargetNode_py.restype = c_void_p

  TdhPath.Delete_TargetNode_py.argtypes = [c_void_p]

  TdhPath.Create_TargetNodeNav_py.restype = c_void_p

  TdhPath.Delete_TargetNodeNav_py.argtypes = [c_void_p]


def Set_PathData_Cfuncs ():
  TdhPath.PathData_GetKey.argtypes = [c_void_p]
  TdhPath.PathData_GetKey.restype = c_void_p

  TdhPath.PathData_Node.argtypes = [c_void_p]
  TdhPath.PathData_Node.restype = c_void_p

  TdhPath.PathData_Link.argtypes = [c_void_p]
  TdhPath.PathData_Link.restype = c_void_p

  TdhPath.PathData_DataType.argtypes = [c_void_p]
  TdhPath.PathData_DataType.restype = c_int

  TdhPath.PathData_Dir.argtypes = [c_void_p]
  TdhPath.PathData_Dir.restype = c_int


def Set_Path_Cfuncs ():
  TdhPath.Path_PathData.argtypes = [c_void_p]
  TdhPath.Path_PathData.restype = c_void_p

  TdhPath.Path_Distance.argtypes = [c_void_p]
  TdhPath.Path_Distance.restype = c_double

  TdhPath.Path_NetID.argtypes = [c_void_p]
  TdhPath.Path_NetID.restype = c_char_p

#  TdhPath.Create_Path_py.restype = c_void_p

#  TdhPath.Delete_Path_py.argtypes = [c_void_p]

def Set_PathIntf_Cfuncs ():
  TdhPath.PathIntf_NoneStr.argtypes = [c_void_p]
  TdhPath.PathIntf_NoneStr.restype = c_char_p

  TdhPath.PathIntf_NearStr.argtypes = [c_void_p]
  TdhPath.PathIntf_NearStr.restype = c_char_p

  TdhPath.PathIntf_NotFoundStr.argtypes = [c_void_p]
  TdhPath.PathIntf_NotFoundStr.restype = c_char_p

  TdhPath.PathIntf_Network0.argtypes = [c_void_p]
  TdhPath.PathIntf_Network0.restype = c_void_p

  TdhPath.PathIntf_CalculatedPath.argtypes = [c_void_p]
  TdhPath.PathIntf_CalculatedPath.restype = c_void_p

  TdhPath.PathIntf_FindMinPath.argtypes = [c_void_p, c_char_p, c_char_p, c_void_p, c_int]
  TdhPath.PathIntf_FindMinPath.restype = c_bool

  TdhPath.PathIntf_ReportCSV.argtypes = [c_void_p]
  TdhPath.PathIntf_ReportCSV.restype = c_char_p

  TdhPath.PathIntf_MaxTravel.argtypes = [c_void_p, c_char_p, c_double]
  TdhPath.PathIntf_MaxTravel.restype = c_void_p

  TdhPath.PathIntf_ReportTravTimes.argtypes = [c_void_p]
  TdhPath.PathIntf_ReportTravTimes.restype = c_char_p

  TdhPath.PathIntf_TempNodeFuncs.argtypes = [c_void_p]
  TdhPath.PathIntf_TempNodeFuncs.restype = c_void_p

  TdhPath.PathIntf_RemoveTempNodes.argtypes = [c_void_p]

  TdhPath.Create_TdhPath_Intf_py.restype = c_void_p

  TdhPath.Delete_TdhPath_Intf_py.argtypes = [c_void_p]

  TdhPath.Create_TdhPath_Intf_py.restype = c_void_p
  TdhPath.Create_TdhPath_Intf_py.argtypes = [c_void_p]

  TdhPath.Delete_TdhPath_Intf_py.argtypes = [c_void_p]


def Set_TempNodes_Cfuncs ():
  TdhPath.TempNodes_TempFlagStr.argtypes = [c_void_p]
  TdhPath.TempNodes_TempFlagStr.restype = c_char_p

  TdhPath.TempNodes_TempDelim.argtypes = [c_void_p]
  TdhPath.TempNodes_TempDelim.restype = c_char_p

  TdhPath.TempNodes_Network.argtypes = [c_void_p]
  TdhPath.TempNodes_Network.restype = c_void_p

  TdhPath.TempNodes_AddNode.argtypes = [c_void_p, c_void_p, c_double, c_char_p, c_void_p, c_void_p]
  TdhPath.TempNodes_AddNode.restype = c_void_p

  TdhPath.TempNodes_AddNodeAtPt.argtypes = [c_void_p, c_void_p, c_char_p]
  TdhPath.TempNodes_AddNodeAtPt.restype = c_void_p

  TdhPath.TempNodes_AddOneTempNode.argtypes = [c_void_p, c_void_p]
  TdhPath.TempNodes_AddOneTempNode.restype = c_bool

  TdhPath.TempNodes_AddTempNodes.argtypes = [c_void_p, c_void_p, c_void_p, c_void_p]
  TdhPath.TempNodes_AddTempNodes.restype = c_bool

  TdhPath.TempNodes_FindCordNode.argtypes = [c_void_p, c_void_p]
  TdhPath.TempNodes_FindCordNode.restype = c_void_p

  TdhPath.TempNodes_FindCordLink.argtypes = [c_void_p, c_void_p]
  TdhPath.TempNodes_FindCordLink.restype = c_void_p

  TdhPath.Create_TempNodeFuncs_py.argtypes = [c_void_p]
  TdhPath.Create_TempNodeFuncs_py.restype = c_void_p

  TdhPath.Delete_TempNodeFuncs_py.argtypes = [c_void_p]
