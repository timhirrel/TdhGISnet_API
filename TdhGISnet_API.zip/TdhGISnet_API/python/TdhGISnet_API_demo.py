# This file demonstrates some functionality of the TdhGISnet API
# The analysis functionality is provided within the TdhPath_API library
# The input/output functionality is provided within the TdhGISnet_API library
# The TdhGISnet_API library uses the Sqlite library
# To visualize the data and results, please use the TdhGISnet app, selecting the supplied database with the File | Projects menu option
# The API libraries should be in a directory specfied by TdhGIS_API_universal.py libDir

from TdhPath_API_py.TdhPath_Intf import *
from TdhGISnet_API_py.TdhGISnet_API import *
from TdhGIS_API_universal import *

class TTdhGISnet_api_demo_py:
# demonstrates some functionality of the TdhGISnet API

    def __init__(self):
    # create the classes used within the demo
        self.network = TGisNetwork_py()
        self.gisnetIO = TTdhGISnetIO_py()
        self.pathAPI = TTdhPath_Intf_py(self.network)
        self.targetNav = TTargetNodeNav_py()
        self.tempnodeFuncs = TTempNodesFuncs_py(self.network);
  
    def Set_DB (self, dirParam) :
    # set the database file
        return self.gisnetIO.SetDB (dirParam+"TdhGISnet_Data.sqlite")

    def Main (self) :
    # read network, perform path analyses and report results    
        if (self.ReadNetwork () != True) :
            return False
        if (self.FindMinPath1()) :
            self.ReportPath1()
        if (self.FindMinPath2()) :
            self.ReportPath2()
        return True

    def WriteNetwork (self) :
        # write netowrk data to a TdhGISnet database
        self.gisnetIO.WriteNetwork(self.network) # write network

    def ReadNetwork (self) :
    # reads a network data from a TdhGISnet database
        result = self.gisnetIO.ReadNetwork("test1", self.network, True) # read a network previously written to the TdhGISnet database
        return result;

    def FindMinPath1 (self) :
    # a simple use of the path analysis function
    # find the minimum path from node 3 to node 4 with no intermediate nodes specified
        return self.pathAPI.FindMinPath("3", "4", self.targetNav, TPathMethod_py.pmMinimum.value)
    
    def FindMinPath2 (self) :
    # a more complex use of the path analysis functionality
    # specify 3 target nodes, with one of those specified as not an intermediate node (i.e. it must be either the starting node or the ending node)
    # create a temporary node within link 6 and add it to the target nodes
    # run the path analysis without specifying a start or end node (i.e. any target node can be either the start or end node)

        self.targetNav.DeleteAll() #empty the target list
        targeNode5 = TTargetNode_py ("5")  
        self.targetNav.Push (targeNode5)
        targeNode5.set_IntermediateFlag(False) # this target cannot be used as an intermediate node
        targeNode3 = TTargetNode_py ("3")  
        self.targetNav.Push (targeNode3)
        targeNode4 = TTargetNode_py ("4")  
        self.targetNav.Push (targeNode4)

        self.pathAPI.RemoveTempNodes() 
        exLink = self.network.LinkNav().GetRec("6")
        linkStr1 = TStringIntf_py()
        linkStr2 = TStringIntf_py()
        tempNode = self.tempnodeFuncs.AddNode(exLink, 0.60, "", linkStr1, linkStr2)
        print (tempNode.NodeID(),  linkStr1.get_Str(), linkStr2.get_Str())
        targetTemp = TTargetNode_py(tempNode.NodeID())
        self.targetNav.Push (targetTemp)

        print("  Target Nodes: ",  self.targetNav.get_Count())
        return self.pathAPI.FindMinPath(self.pathAPI.NoneStr(), self.pathAPI.NoneStr(), self.targetNav, TPathMethod_py.pmMinimum.value)

    def ReportPath1 (self) :
    # uses an API function to output the calculated path
        print (self.pathAPI.ReportCSV())

    def ReportPath2 (self) :
    # demonstrates how to use API functionality to access the calculated path
        currPath = self.pathAPI.CalculatedPath()
        currElement = TPathData_py
        typeStr = str
        print (f"Total Distance: {currPath.Distance():.2f}")
        goFlag = currPath.PathData().GotoFirst()
        while (goFlag):
            currElement = currPath.PathData().GetData()
            match currElement.DataType():
                case 0: 
                    typeStr = "Node " + currElement.Node().NodeID()
                case 1:
                    typeStr = "Link " + currElement.Link().LinkID() + f" {currElement.Link().Value():.2f}"
            print(typeStr)
            goFlag = currPath.PathData().GotoNext()

    def ImportOSM (self, dirStr):  
    # demonstrates importing data from an OSM data file
        requiredTags = TStringVectorIntf_py()
        excludeTags =  TStringVectorIntf_py()
        fileStr = dirStr + "CarsonCity_NV.osm"
        netid = "CarsonCity_OSM"
        self.gisnetIO.DeleteNetwork (netid) #remove network from database, if it exists
        self.network.Reset(); #remove all elements from network
        requiredTags.PushStr("highway, *") #include all ways with highway tag
#        excludeTags.PushStr("highway, footpath") #exclude way with highway tag and footpath value
        self.gisnetIO.ImportOSM(fileStr, self.network, requiredTags, excludeTags)
        self.network.set_NetID(netid);
        print("Carson City from OSM")
        print("Nodes: ", self.network.NodeNav().get_Count())
        print("Links: ", self.network.LinkNav().get_Count())


def main ():
#    dataDir = "/media/tim/ntfs/API_Bindings/TdhGISnet_API_demo_Data/" #set this to the location of the TdhGIS_API_demo Data directory
    dataDir = "e:/API_Bindings/TdhGISnet_API_demo_Data/" #set this to the location of the TdhGIS_API_demo Data directory
    gisnetAPI = TTdhGISnet_api_demo_py()
    if (gisnetAPI.Set_DB(dataDir) != True):
      return
    gisnetAPI.Main()
    gisnetAPI.ImportOSM(dataDir)

main()    