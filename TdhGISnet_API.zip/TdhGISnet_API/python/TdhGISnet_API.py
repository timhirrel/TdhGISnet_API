# The function Set_TdhGISnet_API__Cfuncs must be called before using the classes in this file
# This file provided the capability to store and retrieve
# data used within the TdhGISnet API using a TdhGISnet (sqlite) database
# This file requires the Sqlite library in addition to the TdhCommon and TdhPath libraries

from TdhPath_API_py.TdhPath_Intf import *
from TdhGISnet_API_py.TdhGISnet_API_Cfuncs import *

Set_TdhGISnet_Cfuncs()

class TGisNetwork_py (TtdhNetwork_py):
# this class must be used for networks to be stored and retrieved from a TdhGISnet database    
    def __init__(self, cParam = None):
        # cParam is a c++ instance of TGisNetwork
        # cParam is not used when an API user creates an instance of this class
        self.cOwner2 = False
        if cParam == None:
            cParam = TdhGISnet_API.Create_GisNetwork_py()
            self.cOwner2 = True
        super().__init__(cParam)
    def __exit__ (self):
        if (self.cOwner2):    
          TdhGISnet_API.Delete_GisNetwork_py (self.cPtr) 


class TTdhGISnetIO_py :
# this class proived read/write functionality for a TdhGISnet database
    def __init__(self, cParam = None):
        # cParam is not used when an API user creates an instance of this class
        self.cOwner = False
        if (cParam == None):
            cParam = TdhGISnet_API.Create_TdhGISnetIO_py()
            self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner):
            TdhGISnet_API.Delete_TdhGISnetIO_py(self.cPtr)

    def SetDB (self, dbParam):
        return TdhGISnet_API.TdhGISnetIO_SetDB (self.cPtr, C_Str(dbParam));

    def ReadNetwork (self, netid, network :TGisNetwork_py, reset) :
        return TdhGISnet_API.TdhGISnetIO_ReadNetwork(self.cPtr, C_Str(netid), network.cPtr, reset);

    def WriteNetwork (self, network :TGisNetwork_py) :
        return TdhGISnet_API.TdhGISnetIO_WriteNetwork (self.cPtr, network.cPtr);

    def DeleteNetwork (self, netid) :
         TdhGISnet_API.TdhGISnetIO_DeleteNetwork(self.cPtr, C_Str(netid))

    def ImportOSM (self, fileStr, network :TGisNetwork_py, tagsRequired :TStringVectorIntf_py, tagsExclude :TStringVectorIntf_py) :
        return TdhGISnet_API.TdhGISnetIO_ImportOSM (self.cPtr, C_Str(fileStr), network.cPtr, tagsRequired.cPtr, tagsExclude.cPtr);

