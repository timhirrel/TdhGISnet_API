# The function Set_PathIntf_Cfuncs must be called before using the classes in this file
# This file contains classes providing path analysis functionality

from ctypes import *
import os
import sys

from TdhCommon_py.RecordsNav import *
from TdhCommon_py.CadPrimitives import *
from TdhPath_API_py.TdhPath_Cfuncs import *

from typing import Self
from enum import Enum, auto

def Set_PathAPI_Cfuncs ():
# this function must be called before the use of any of the classes in this file
    Set_NetNode_Cfuncs()
    Set_NetLink_Cfuncs()
    Set_NetConn_Cfuncs()
    Set_Network_Cfuncs()
    Set_TargetNode_Cfuncs()
    Set_PathData_Cfuncs()
    Set_Path_Cfuncs()
    Set_TempNodes_Cfuncs()
    Set_PathIntf_Cfuncs()

Set_PathAPI_Cfuncs()

class TNetNode_py:
# provides access to the data needed for nodes in network topology
# instances of this class should be created through TtdhNetwork_py:Create_NetNode
    def __init__(self, cParam):
        # cParam is a c++ instance of TNetNode0
        self.cOwner = False
        if cParam == None:
            cParam = TdhPath.Create_NetNode(None)
            self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self) :
        if (self.cOwner):    
          TdhPath.Delete_NetNode(self.cPtr);
    def Network (self) :
        # return the network to which the node belongs
        return TdhPath.TNetNode_Network (self.cPtr)
    def NodeID (self) :
        # unique id among nodes in the network
        return StrFromCstr(TdhPath.TNetNode_NodeID (self.cPtr))
    def set_NodeID (self, strParam) :
        # set the unique id
        TdhPath.TNetNode_set_NodeID (self.cPtr, C_Str(strParam))
    def AutoDelete (self) :
        # if true, the node is automatically deleted if all links using the node are deleted
        return TdhPath.TNetNode_AutoDelete (self.cPtr)
    def set_AutoDelete (self, boolParam) :
        # sets autodelete
        TdhPath.TNetNode_set_AutoDelete (self.cPtr, boolParam)
    def Temp (self) :
        # node will be removed when TTempNodesFuncs::RemoveTempsNodes() is called
        return TdhPath.TNetNode_Temp (self.cPtr)
    def set_Temp (self, boolParam) :
        # sets Temp flag
        TdhPath.TNetNode_set_Temp (self.cPtr, boolParam)
    def DownLink (self) :
        # returns the connecting link along calculated path
        return TdhPath.TNetNode_DownLink (self.cPtr)
    def DownNode (self) :
        # returns the previous node along the calculated
        return TdhPath.TNetNode_DownNode (self.cPtr)
    def DownConn (self) :
        # returns the TNetConn0 pointing downtree from this node
        return TdhPath.TNetNode_DownConn (self.cPtr)
    def set_DownConn (self, connParam) :
        # set the TNetCoon that goes down the traverse
         TdhPath.TNetNode_set_DownConn (self.cPtr, connParam)
    def TravVal (self) :
        # returns the calculated value at the node along the calculated path
        return TdhPath.TNetNode_TravVal (self.cPtr)
    def LinkCount (self) :
        # returns the number of links connecting to the node
        return TdhPath.TNetNode_LinkCount (self.cPtr)
    def GetLink (self, linkParam) :
       # used to access links connected to this.
       # for fist link, set 1st param to NULL
       # for a subsequent link, set 1st param to cufrrent link
        return TdhPath.TNetNode_GetLink (self.cPtr, linkParam)
    def InitForTraverse (self) :
        #called once before any traversal for a given network configuration
        return TdhPath.TNetNode_InitForTraverse (self.cPtr)
    def ResetForTraverse (self) :
        #called before each network traversal
        return TdhPath.TNetNode_ResetForTraverse (self.cPtr)
    def Segment (self) :
        # returns the network segment number to which the node belongs
        return TdhPath.TNetNode_Segment (self.cPtr)
    def set_Segment (self, segParam) :
        # set the network number to which the node belongs
        TdhPath.TNetNode_set_Segment (self.cPtr, segParam)
    def ConnNav (self) :
        # a navigator for TNetConn's
        return TConnNav_py(TdhPath.TNetNode_ConnNav (self.cPtr))
    def PopQueue (self) :
        # pop a queue representing the order in which the nodes were traversed
        return TdhPath.TNetNode_PopQueue (self.cPtr)
    def PushQueue (self) :
        # returns the Pushqueue pointer
        return TdhPath.TNetNode_PushQueue (self.cPtr)
    

# the following functions are used to draw the network
# if a drawing is not wanted or if coordinates are not available,
# the memory requirements for the API can be reduced by setting TtdhNetwork0::NoDraw (true)
# in which case the following functions will not produce meaningful results
    def Pt (self) :
        # returns the TPointXY associated the node
        return TPointXY_py(TdhPath.TNetNode_Pt_ptr(self.cPtr))
    def set_Pt (self, ptParam :TPointXY_py) :
        # set the TPointXY associated the node
        TdhPath.TNetNode_set_Pt (self.cPtr, ptParam.cPtr)
    def Radius (self) :
        # returns the radius used to draw the node, in distance units (i.e. converts lon/lat difference to distance)
        return TdhPath.TNetNode_Radius(self.cPtr)
    def set_Radius (self, valParam) :
        # set the radius used to draw the node, in distance units
        TdhPath.TNetNode_set_Radius(self.cPtr, valParam)
    def Radius_cord (self) :
        # returns the radius used to draw the node, in distance units (i.e. converts lon/lat difference to distance)
        return TdhPath.TNetNode_Radius(self.cPtr)
    def set_Radius_cord (self, valParam) :
        #  set the radius used to draw the node, in coordinate units
        TdhPath.TNetNode_set_Radius(self.cPtr, valParam)
    def Color (self) :
        # the drawing color, if ColorFlag is set to cf Color_gis
        return TdhPath.TNetNode_Color(self.cPtr)
    def set_Color (self, valParam) :
        #  set the drawing color
        TdhPath.TNetNode_set_Color(self.cPtr, valParam)
    def ColorFlag (self) :
        # if set to cfOwner_gis the network color is used
        return TdhPath.TNetNode_ColorFlag(self.cPtr)
    def set_ColorFlag (self, valParam) :
        #  set ColorFlag
        TdhPath.TNetNode_set_ColorFlag(self.cPtr, valParam)
    def Width (self) :
        # the drawing width, if 0 the network default width is used.
        return TdhPath.TNetNode_Witdh(self.cPtr)
    def set_Width (self, valParam) :
        #  set the Width
        TdhPath.TNetNode_set_Width(self.cPtr, valParam)

class TNetLink_py:
# provides access to the data needed for links in network topology
# instances of this class should be created through TtdhNetwork_py:Create_NetLink
    def __init__(self, cParam):
        # cParam is a c++ instance of TNetLink0
        self.cOwner = False
        if cParam == None:
            cParam = TdhPath.Create_NetLink(None)
            self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner) :   
          TdhPath.Delete_NetLink (self.cPtr) 
    def Network (self) :
        # return the network to which the node belongs
        return TdhPath.TNetLink_Network (self.cPtr)
    def LinkID (self) :
        # unique id among links in the network
        return StrFromCstr(TdhPath.TNetLink_LinkID (self.cPtr))
    def set_LinkID (self, strParam) :
        # set the unique id
        TdhPath.TNetLink_set_LinkID (self.cPtr, C_Str(strParam))
    def Node1 (self) :
        # the first node to which the link connects
        return TdhPath.TNetLink_Node1 (self.cPtr)
    def Node2 (self) :
        # the second node to which the link connects
        return TdhPath.TNetLink_Node2 (self.cPtr)
    def set_Node1 (self, nodeParam) :
        # set the first node to which the link connects
        TdhPath.TNetLink_set_Node1 (self.cPtr, nodeParam)
    def set_Node2 (self, nodeParam) :
        # set the second node to which the link connects
        TdhPath.TNetLink_set_Node2 (self.cPtr, nodeParam)
    def get_Node (self, pos) :
        # return either the first or second node depending on whether the 1st param is 1 or 2
        return TdhPath.TNetLink_get_Node (self.cPtr, pos)
    def set_Node (self, pos, nodeParam, keep = False) :
        # sets the 2nd param as the node for the link in position determined by 1st param
        # if the 3rd param is false, the existing node will he deleted, if it connects to no other link
        TdhPath.TNetLink_Set_Node (self.cPtr, pos, nodeParam, keep)
    def set_NodeByKey (self, pos, nodeid) :
        # call set_Node (1st param, Network()->GetNode (2nd param, true))
        TdhPath.TNetLink_set_NodeByKey (self.cPtr, pos, nodeid)
    def CreateConn (self, dir) :
        # returns a new TNetConn. 1st param specifies direction (1 = node1 to node2, -1 = node2 to node1)
        return TdhPath.TNetLink_CreateConn (self.cPtr, dir)
    def Restrict (self) :
        # returns the travel restriction parameter for the link
        return TdhPath.TNetLink_Restrict (self.cPtr)
    def set_Restrict (self, dir) :
        # sets the travel restriction parameter for the link
        TdhPath.TNetLink_set_Restrict (self.cPtr, dir)
    def TempClosed (self) :
        # returns true if the link is temporarily closed
        #(i.e. will be automatically opened for next analysis unless otherwise specified
        return TdhPath.TNetLink_TempClosed (self.cPtr)
    def Status (self, dir) :
        # returns 1 if the link is open, 0 if it closed for the specified direction
        # 1st param specifies desired direction, 0 for node1 to node2, 1 for node2 to node1
        return TdhPath.TNetLink_Status (self.cPtr)
    def Value (self) :
        # the value used for the link when calculating path values
        return TdhPath.TNetLink_Value (self.cPtr)
    def set_Value (self, val) :
        # sets the value used for the link when calculating path values
        TdhPath.TNetLink_set_Value (self.cPtr, val)
    def Value (self) :
        # the value used for the link when calculating path values
        return TdhPath.TNetLink_Value (self.cPtr)
    def set_Value (self, val) :
        # sets the value used for the link when calculating path values
        TdhPath.TNetLink_set_Value (self.cPtr, val)
    def Temp (self) :
        #  link will be removed when TTempNodesFuncs::RemoveTempsNodes() is called
        return TdhPath.TNetLink_Temp (self.cPtr)
    def set_Temp (self, val) :
        # sets Temp
        TdhPath.TNetLink_set_Temp (self.cPtr, val)
    def SplitAttributes (self, link1 :Self, link2 :Self, ratio) :
        # split this link's attributes (e.g. multiline  and Value) among the 1st param and 2nd param
        # with the 3rd param specifying the the ratio of the split
        TdhPath.TNetLink_SplitAttributes (self.cPtr, link1.cPtr, link2.cPtr, ratio)
    def unSplitAttributes (self, linkParam :Self) :
        # combine attribute of 1st param into this (multiline and value)
        TdhPath.TNetLink_unSplitAttributes (self.cPtr, linkParam.cPtr)
    def CopyDataTo (self, linkParam :Self) :
        # copies attributes to another link
        return TdhPath.TNetLink_CopyDataTo (self.cPtr, linkParam.cPtr)
    def InitForTraverse (self) :
        # called once before any traversal for a given network configuration
        TdhPath.TNetLink_InitForTraverse (self.cPtr)
    def ResetForTraverse (self) :
        # called before a traverse
        TdhPath.TNetLink_ResetForTraverse (self.cPtr)

# the following functions are used to draw the network
# if a drawing is not wanted or if coordinates are not available,
# the memory requirements for the API can be reduced by setting TtdhNetwork0::NoDraw (true)
# in which case the following functions will not produce meaningful results
    def Radius (self) :
        # the radius used to draw the link id, in distance units
        return TdhPath.TNetLink_Radius (self.cPtr)
    def set_Radius (self, val) :
        # sets Radius
        TdhPath.TNetLink_set_Radius (self.cPtr, val)
    def Radius_cord (self) :
        # the radius used to draw the link id, in coordinate units
        return TdhPath.TNetLink_Radius_cord (self.cPtr)
    def set_Radius_cord (self, val) :
        # sets Radius_cord
        TdhPath.TNetLink_set_Radius_cord (self.cPtr, val)
    def Radius_cord (self) :
        # the radius used to draw the link id, in coordinate units
        return TdhPath.TNetLink_Radius_cord (self.cPtr)
    def set_Radius_cord (self, val) :
        # sets Radius_cord
        TdhPath.TNetLink_set_Radius_cord (self.cPtr, val)
    def LabelPt (self) :
        # the geographic point for drawing the link id
        # the return value can be used for both setting and retreiving the LablePt
        return TPointXY_py(TdhPath.TNetLink_LabelPt_ptr (self.cPtr))
#    def set_LabelPt (self, ptParam :TPointXY_py) :
        # sets LabelPt
#        TdhPath.TNetLink_set_LabelPt (self.cPtr, ptParam.cPtr)
    def Color (self) :
        # the drawing color, if ColorFlag is set to cf Color_gis
        return TdhPath.TNetLink_Color (self.cPtr)
    def set_Color (self, val) :
        # sets Color
        TdhPath.TNetLink_set_Color (self.cPtr, val)
    def ColorFlag (self) :
        # if set to cfOwner_gis the network color is used
        return TdhPath.TNetLink_ColorFlag (self.cPtr)
    def set_ColorFlag (self, val) :
        # sets ColorFlag
        TdhPath.TNetLink_set_ColorFlag (self.cPtr, val)
    def Width (self) :
        # the drawing width, if 0 the network default width is used.
        return TdhPath.TNetLink_Width (self.cPtr)
    def set_Width (self, val) :
        # sets Width
        TdhPath.TNetLink_set_Width (self.cPtr, val)
    def MultiLine (self) :
        # returns the TMultiLine0 containing the link vertex points between the nodes
        return TMultiLine_py(TdhPath.TNetLink_MultiLine (self.cPtr))
    def CalcLength (self) :
        # returns the TMultiLine0 containing the link vertex points between the nodes
        return TdhPath.TNetLink_CalcLength (self.cPtr)
    def GetExtents (self) :
        # returns the coordinate extents of the link
        return TdhPath.TNetLink_GetExtents (self.cPtr)
    def NearestPt (self, inPt :TPointXY_py, outPt :TPointXY_py) :
        # sets the 2nd param to the point on the link closest to 1st param
        TdhPath.TNetLink_NearestPt (self.cPtr, inPt.cPtr, outPt.cPtr)
    def GetExtents (self) :
        # returns the coordinate extents of the link
        return TCadRect_py(TdhPath.TNetLink_GetExtents (self.cPtr))
    def ToMultiLine (self) :
        # returns a multiline combining the nodes and any multiline points
        return TMultiLine_py(TdhPath.TNetLink_ToMultiLine (self.cPtr))
    def FromMultiLine (self, lineParam :TMultiLine_py, nodesFlag) :
        # uses a TMultiLine0 (1st param) to set link geometry
        # if 2nd param is true, the first and last vertices of the 1st param used as the points for the nodes 1 and 2, respectively
        TdhPath.TNetLink_FromMultiLine (self.cPtr, lineParam.cPtr, nodesFlag)
    def SplitMultiLine (self, link1 :Self, link2 :Self, ratio) :
        # spli this link multiLine into 1st param and 2nd param
        # with the 3rd param specifying the the ratio of the distance to the split point over the link length
        return TdhPath.TNetLink_SplitMultiLine (self.cPtr, link1.cPtr, link2.cPtr, ratio)
    def GetNodeCords (self, pos, outPt :TPointXY_py) :
        # set the 2nd param to the node pt for link node in the position of the 1st param (1 or 2)
        TdhPath.TNetLink_GetNodeCords (self.cPtr, pos, outPt.cPtr)
    def GetNodeRadius (self, pos) :
        # return radius of node at pos of 1st param (1 or 2)
        return TdhPath.TNetLink_GetNodeCords (self.cPtr, pos)

class TNetConn_py :
# data describing which links connect to a node
# this data is stored in a navigator belonging to the node
# instances of this class are not normally created by the API user
    def __init__(self, cParam):
        # cParam is a c++ instance of TNetConn0
        self.cOwner = False
#        if cParam == None:
#            cParam = TdhPath.Create_Conn()
#            self.cOwner = true
        self.cPtr = cParam
#    def __exit__ (self):
#        if (self.cOwner) :   
#          TdhPath_Delete_Conn (self.cPtr) 
    def Link (self) :
        # returns the link being referenced
        return TNetLink_py(TdhPath.NetConn0_Link (self.cPtr))
    def LinkID (self) :
        # returns the id of the link being referenced
        return StrFromCstr(TdhPath.NetConn0_LinkID (self.cPtr))
    def ConnNode (self):
        # return the other node for the link
        return TNetNode_py(TdhPath.NetConn0_ConnNode (self.cPtr))
    def set_ConnNode (self, nodeParam :TNetNode_py, connParam :Self = None):    
        # se the other node for the link
        tdhconn = None
        if (connParam != None):
          tdhconn = connParam.cPtr
        TdhPath.NetConn0_set_ConnNode (self.cPtr, nodeParam.cPtr, tdhconn)
    def OppConn (self):
        # return the other TNetConn for the referenced link
        return TNetConn_py(TdhPath.NetConn0_OppConn (self.cPtr))
    def DownConnnn (self):
        # return the DownConn() for CannNode()
        return TNetConn_py(TdhPath.NetConn0_DownConn (self.cPtr))
    def Dir (self):
        # 1 = from node1, -1 = from node2
        return TdhPath.NetConn0_Dir (self.cPtr)
    def NextConn (self):
        # return the next TNetConn0 in the list
        return TNetConn_py(TdhPath.NetConn0_NextConn (self.cPtr))

class TNodeNav_py (TRecordsNav_py) :
# This class provides a navigator of a TNetNode_py list
# instances of this class should be created through TtdhNetwork_py:Create_NodeNav
    def __init__(self, cParam): 
        # 1st param is a C++ instance of a TNodeNav
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TNetNode_py(objParam)
      return pt

class TLinkNav_py (TRecordsNav_py) :
# This class provides a navigator of a TNetLink_py list
# instances of this class should be created through TtdhNetwork_py:Create_LinkNav
    def __init__(self, cParam): 
        # 1st param is a C++ instance of a TLinkNav
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TNetLink_py(objParam)
      return pt

class TConnNav_py (TRecordsNav_py) :
# This class provides a navigator for TNetConn_py's
# instances of this class are not normally created by the API user
    def __init__(self, cParam): 
        # 1st param is a C++ instance of a TConnNav
        super().__init__(cParam)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TNetConn_py(objParam)
      return pt

class TtdhNetwork_py :
# contains link and node data for a network
    def __init__(self, cParam = None):
        # cParam is a c++ instance of TtdhNetwork0
        # cParam is not used when an API user creates an instance of this class
        self.cOwner = False
        if cParam == None:
            cParam = TdhPath.Create_Network()
            self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner):    
          TdhPath.Delete_Network (self.cPtr) 
    def NetID (self):
        # return id for the network
        return StrFromCstr(TdhPath.TNetwork_NetID (self.cPtr))
    def set_NetID (self, val):
        # set id for the network
        TdhPath.TNetwork_set_NetID (self.cPtr, C_Str(val))
    def noDraw (self):
        #  if true, the network components will not include geographic data
        return TdhPath.TNetwork_noDraw (self.cPtr)
    def set_noDraw (self, val):
        # set noDraw value
        TdhPath.TNetwork_set_noDraw (self.cPtr, val)
    def Create_Node (self):
        # returns an new instance of TNetNode_py appropriate the version of TtdhNetowrk0
        return TNetNode_py (TdhPath.TNetwork_Create_Node0 (self.cPtr))
    def Create_Link (self):
        # returns an instance of TNetLink_py appropriate the version of TtdhNetowrk0
        return TNetLink_py (TdhPath.TNetwork_Create_Link0 (self.cPtr))
    def NodeNav (self):
        # returns default navigator for nodes in network
        return TNodeNav_py(TdhPath.TNetwork_NodeNav (self.cPtr))
    def LinkNav (self):
        # returns default navigator for links in network
        return TLinkNav_py(TdhPath.TNetwork_LinkNav (self.cPtr))
    def set_NodeNav (self, navParam :TNodeNav_py):
        # set default navigator for nodes
        TdhPath.TNetwork_set_NodeNav (self.cPtr, navParam.cPtr)
    def set_LinkNav (self, navParam :TLinkNav_py):
        # set default navigator for links
        TdhPath.TNetwork_set_LinkNav (self.cPtr, navParam.cPtr)
    def Create_NodeNav (self, listFlag):
        # create a new navigator for nodes.
        # if 1st param is true create a new node list for the navigator, otherwise, use default list
        return TNodeNav_py(TdhPath.TNetwork_Create_NodeNav (self.cPtr, listFlag))
    def Creaet_LinkNav (self, listFlag):
        # create a new navigator for links.
        # if 1st param is true create a new link list for the navigator, otherwise, use default list
        return TLinkNav_py(TdhPath.TNetwork_Create_LinkNav (self.cPtr, listFlag))
    def DeleteConns (self):
        # delete all TNetConn_py's for all nodes
        TdhPath.TNetwork_DeleteConns (self.cPtr)
    def AddNode (self, idParam, replaceFlag):
        # create and add a node to the network
        # 1st param is node id
        # if 2nd param is true and there is an existing node with the same id, the existing node will be replaced
        # returns new node or NULL if an existing node with same id is not replaced 
        return TNetNode_py(TdhPath.TNetwork_AddNode (self.cPtr, C_Str(idParam), replaceFlag))
    def AddLink (self, idParam, replaceFlag):
        # create and add a link to the network
        # 1st param is link id
        # if 2nd param is true and there is an existing link with the same id, the existing link will be replaced
        # returns new link or NULL if an existing link with same id is not replaced 
        return TNetLink_py(TdhPath.TNetwork_AddLink (self.cPtr, C_Str(idParam), replaceFlag))
    def GetNode (self, idParam, addFlag):
        # returns an existing node with an id equal to the 1st param, if such a node exists
        # otherwise, if the 2nd param is true, creates and return such a node
        # otherwise returns NULL
        return TNetNode_py(TdhPath.TNetwork_GetNode (self.cPtr, C_Str(idParam), addFlag))
    def DeleteNode (self, nodeParam :TNetNode_py):
        # deletes a node (1st param) if it is not used by any link
        return TdhPath.TNetwork_DeleteNode (self.cPtr, nodeParam.cPtr)
    def SplitLink (self, linkParam :TNetLink_py, ratio, nodeid, linkid1 :TStringIntf_py, linkid2 :TStringIntf_py):
        # splits a link (1st param), placing a new node at a position determined by 2nd param (ratio of length to position over total length)
        # the link value is divided between the 2 new links proportional to the 2nd param
        # the existing link is removed from the network but the instance is not deleted. the instance should be saved or deleted by the client
        # if the 3rd param is not blank, it will be used for the new node id, otherwise an id will be assigned automaticallly
        # if the 4th param is not blank, it will be used for the 1st new link id, otherwise an id will be assigned automaticallly
        # if the 5th param is not blank, it will be used for the 2nd new link id, otherwise an id will be assigned automaticallly
        # the new node will be returned
        return TNetNode_py(TdhPath.TNetwork_SplitLink (self.cPtr, linkParam.cPtr, ratio, C_Str(nodeid), linkid1.cPtr, linkid2.cPtr))
    def TNetwork_FindConnectedLink (self, nodeid, linkid):
        # return a link connected to the node specified by the 1st param
        # set 2nd param = "" to find first link or to a link id to find the following link.
        # returns NULL if no link found
        return TNetNode_py(TdhPath.TNetwork_FindConnectedLink (self.cPtr, C_Str(nodeid), C_Str(linkid)))
    def Reset (self):
        # deletes all nodes and links in the network, sets id to "new"
        TdhPath.TNetwork_Reset (self.cPtr)
    def Description (self):
        # return user defined description for the network
        return StrFromCstr(TdhPath.TNetwork_Description (self.cPtr))
    def set_Description (self, val):
        # set a user defined description for the network
        TdhPath.TNetwork_set_Description (self.cPtr, C_Str(val))
    def get_defaultColor (self):
        #  return the color used to draw network elements when the element ColorFlag is set to cfOwner_gis
        return TdhPath.TNetwork_get_defaultColor (self.cPtr)
    def PopQueueHead (self):
        # return the head node of a queue representing the order in which the nodes were traversed
        return TNetNode_py(TdhPath.TNetwork_PopQueueHead (self.cPtr))

class TTargetNode_py:
# data for a target node in a minpath analysis
    def __init__(self, nodeId :str):
        cParam = TdhPath.Create_TargetNode_py(C_Str(nodeId))
        self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner):    
          TdhPath.Delete_TargetNode_py (self.cPtr) 
    def NodeID (self) :
        # returns the id of the node being referenced
        return StrFromCstr(TdhPath.TargetNode_NodeID (self.cPtr))
    def set_NodeID (self, idParam) :
        # set the id of the node being referenced
        TdhPath.TargetNode_set_NodeID (self.cPtr, C_Str(idParam))
    def GetKey (self) :
        # returns a unique value for a TtargetNode0 instance, useable in navigator functions
        return TdhPath.TargetNode_GetKey (self.cPtr)
    def StartFlag (self) :
        # indicates whether the instance can be used as a start node
        return TdhPath.TargetNode_StartFlag (self.cPtr)
    def set_StartFlag (self, flagParam) :
        # sets whether the instance can be used as a start node
        return TdhPath.TargetNode_set_StartFlag (self.cPtr, flagParam)
    def EndFlag (self) :
        # indicates whether the instance can be used as an end node
        return TdhPath.TargetNode_EndFlag (self.cPtr)
    def set_EndFlag (self, flagParam) :
        # sets whether the instance can be used as an end node
        return TdhPath.TargetNode_set_EndFlag (self.cPtr, flagParam)
    def IntermediateFlag (self) :
        # indicates whether the instance can be used as an intermedidate node
        return TdhPath.TargetNode_IntermediateFlag (self.cPtr)
    def set_IntermediateFlag (self, flagParam) :
        # sets whether the instance can be used as an intermedidate node
        return TdhPath.TargetNode_set_IntermediateFlag (self.cPtr, flagParam)

class TTargetNodeNav_py (TRecordsNav_py) :
# This class provides a navigator for TTargetNode_py instances
# This is a queue navigator so instances must be added using Push(), not AddRec()
    def __init__(self, cParam = None): 
        # 1st param is a C++ instance of a TTargetNodeNav
        # 1st param is normally not provided when an instance is created by an API user
        self.cOwner = False
        if (cParam == None):
            cParam = TdhPath.Create_TargetNodeNav_py()
            self.cOwner = True
        super().__init__(cParam)
    def __exit__ (self):
      if (self.cOwner):
        TdhPath.Delete_TargetNodeNav (self.cPtr)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TTargetNode_py(objParam)
      return pt
    def AddRec (self, objParam, keyParam, replaceFlag) :
      return False # instances must be added using Push(), not AddRec()   

class TPathData_py :
# provides data describing the components of a calculated path
# this data is stored in a TPathData navigator
# instances of this class are not normally created by the API user
    def __init__(self, cParam):
        # cParam is a c++ instance of TPathData0
        self.cOwner = False
#        if cParam == None:
#            cParam = TdhPath.Create_PathData()
#            self.cOwner = true
        self.cPtr = cParam
#    def __exit__ (self):
#       if (self.cOwner):    
#         TdhPath_Delete_PathData (self.cPtr) 
    def GetKey (self) :
        # returns a unique value for TPathData0 within a TPathData0 navigator
        return TdhPath.PathData_GetKey (self.cPtr)
    def Node (self) :
        # returns reference to a node component
        return TNetNode_py(TdhPath.PathData_Node (self.cPtr))
    def Link (self) :
        # returns reference to a link component
        return TNetLink_py(TdhPath.PathData_Link (self.cPtr))
    def DataType (self) :
        # returns the data type for the instance, 0 = Node,  1 = Link
        return TdhPath.PathData_DataType (self.cPtr)
    def Dir (self) :
        # for link data, indicates direction of travel, 1 = from node1 to node2, -1 = from node2 to node1
        return TdhPath.PathData_Dir (self.cPtr)

class TPathDataNav_py (TRecordsNav_py) :
# This class provides a navigator for TPathData instances
# instances of this class are accessed through TPath0_py
    def __init__(self, cParam): 
        # 1st param is a C++ instance of a TPathDataNav
        self.cOwner = False
#        if (cParam == None):
#            cParam = TdhPath.Create_TargetNodeNav()
#            self.cOwner = True
        super().__init__(cParam)
#    def __exit__ (self):
#      if (self.cOwner)
#        TdhPath.Delete_TargetNodeNav (self.cPtr)
    def _C_obj (self, objParam) :
      return objParam.cPtr
    def _Py_Obj (self, objParam) :
      pt = TPathData_py(objParam)
      return pt

class TPath_py :
# provides the data needed to define a calculated path
    def __init__(self, cParam = None):
        # cParam is a c++ instance of TPath0
        # cParam is normally not provided when an instance is created by an API user
        self.cOwner = False
        if cParam == None:
            cParam = TdhPath.Create_Path_py()
            self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
       if (self.cOwner) :   
         TdhPath.Delete_Path_py (self.cPtr) 
    def PathData (self) :
        #  returns a TPathData0 navigator containing elements of a calculated path
        return TPathDataNav_py(TdhPath.Path_PathData (self.cPtr))
    def Distance (self) :
        #  returns the net of link values along the path
        return TdhPath.Path_Distance (self.cPtr)
    def NetID (self) :
        #  returns the id for the network from which the path was calculated
        return StrFromCstr(TdhPath.Path_NetID (self.cPtr))


class TTempNodesFuncs_py :
# provides functionality for creating and removing temporary nodes
# an instance of this class is provided through TPathIntf_py
    def __init__(self, netParam :TtdhNetwork_py):
        cParam = TdhPath.Create_TempNodeFuncs_py (netParam.cPtr)
        self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner) :  
          TdhPath.Delete_TdhPath_Intf (self.cPtr) 
    def TempFlagStr (self) :
        # return "[temp]"
        return StrFromCstr(TdhPath.TempNodes_TempFlagStr (self.cPtr))
    def TempDelim (self) :
        # returns ":"
        return StrFromCstr(TdhPath.TempNodes_TempDelim (self.cPtr))
    def Network (self) :
        # the network to which nodes will be added
        return TtdhNetwork_py(TdhPath.TempNodes_Network (self.cPtr))
    def AddNode (self, linkParam :TNetLink_py, ratio, nodeid, linkid1 :TStringIntf_py, linkid2 :TStringIntf_py) :
        # TtdhNetwork_py::SplitLink is called is called, using the same parameters, creating a new node and replacing the existing link with 2 new links
        # the new node and links will be removed and the original link restored when RemoveTempNodes is called
        # the new node is returned
        return TNetNode_py (TdhPath.TempNodes_AddNode (self.cPtr, linkParam.cPtr, ratio, C_Str(nodeid), linkid1.cPtr, linkid2.cPtr))
    def AddNodeAtPt (self, ptParam :TPointXY_py, nodeid) :
        # after finding the link which passes closest to the 1st param and the closest point
        # AddNode will be called
        # the 2nd param will be the id for the new node if the id is not blank or already used; otherwise an id will be assigned automatically
        # the new node is returned
        return TNetNode_py (TdhPath.TempNodes_AddNode (self.cPtr, ptParam.cPtr, C_Str(nodeid)))
    def AddOneTempNode (self, strParam :TStringIntf_py) :
        # calls AddNodeAtPt if the 1st param has the format:
        # "[temp]:<nodeid>:<x,y coordinates>
        return TdhPath.TempNodes_AddOneTempNode (self.cPtr, strParam)
    def AddTempNodes (self, startStr :TStringIntf_py, endStr :TStringIntf_py, navParam :TTargetNodeNav_py) :
        # calls AddOneTemoNode for 1st and 2nd param and all nodes listed in the 3rd param
        return TdhPath.TempNodes_AddTempNodes (self.cPtr, startStr.cPtr, endStr.cPtr, navParam.cStr)
    def FindCordNode (self, ptParam :TPointXY_py) :
        # return the node closest to the 1st param
        return TNetNode_py(TdhPath.TempNodes_FindCordNode (self.cPtr, ptParam.cPtr))
    def FindCordLink (self, ptParam :TPointXY_py) :
        # return the link passing closest to the 1st param
        return TNetLink_py(TdhPath.TempNodes_FindCordLink (self.cPtr, ptParam.cPtr))


class TPathMethod_py (Enum): 
    pmSpecified = 0
    pmNearest = 1
    pmMinimum = 2

class TTdhPath_Intf_py:
# provides the functionality needed to calculate minimum paths
    def __init__(self, netParam :TtdhNetwork_py):
        cParam = TdhPath.Create_TdhPath_Intf_py (netParam.cPtr)
        self.cOwner = True
        self.cPtr = cParam
    def __exit__ (self):
        if (self.cOwner):    
          TdhPath.Delete_TdhPath_Intf_py (self.cPtr) 
    def NoneStr (self) :
        # returns "[None]"
        return StrFromCstr(TdhPath.PathIntf_NoneStr (self.cPtr))
    def NearStr (self) :
        # returns "[Nearest]"
        return StrFromCstr(TdhPath.PathIntf_NearStr (self.cPtr))
    def NotFoundStr (self) :
        # returns a message listing target nodes not found
        return StrFromCstr(TdhPath.PathIntf_NotFoundStr (self.cPtr))
    def Network0 (self) :
        # returns the network being used
        return TtdhNetwork_py(TdhPath.PathIntf_Network0 (self.cPtr))
    def CalculatedPath (self) :
        # returns the calculated path
        return TPath_py(TdhPath.PathIntf_CalculatedPath (self.cPtr))
    def FindMinPath (self, startID, endID, targetNav :TTargetNodeNav_py, method :TPathMethod_py) :
        # find the minimum path between 1st param and 2nd param
        # using the 3rd param as intermediate nodes, as determined by 4th param (see TPathMethod)
        # if the 2nd param is NearStr(), only the path to the nearest intermediate node will be found
        # if the 4th param is pmMinimum:
            # if the 1st param is NoneStr(), any intermediate node can be the start node
            # if the 2nd param is NoneStr(), any intermediate node can be the end node
        # returns false if no path is found
        # results are retrieved through CalculatedPath()
        return TdhPath.PathIntf_FindMinPath (self.cPtr, C_Str(startID), C_Str(endID), targetNav.cPtr, method)
    def ReportCSV (self) :
        # returns a report listing the calculated path
        return StrFromCstr(TdhPath.PathIntf_ReportCSV (self.cPtr))
    def ReportTravTimes (self) :
        # return a list of all nodes visited during a call to MaxTravel() and their TravVal()
        return StrFromCstr(TdhPath.PathIntf_ReportTravTimes (self.cPtr))
    def MaxTravel (self, startID, limit) :
        # starting from node defined by param 1
        # find the travel time to every node
        # with a travel time no more than the 2nd param (if greater than 0)
        # results can be retrieved through TNetNode0::TravVal() or in report form through ReportTravTimes()
        # return the starting node
        return TNetNode_py(TdhPath.PathIntf_MaxTravel (self.cPtr, C_Str(startID), limit))
    def TempNodeFuncs (self) :
        # returns an instance of TTempNodeFuncs0
        return TTempNodesFuncs_py(TdhPath.PathIntf_TempNodeFuncs (self.cPtr))
    def RemoveTempNodes (self) :
        # removes all temporary nodes in the associated network
        TdhPath.PathIntf_RemoveTempNodes (self.cPtr)


