# This file contains code not normally of concern to the API user

from TdhGIS_API_universal import *

if (platform.system() == "Linux") :
  TdhCommon = CDLL(libDir+"libTdhCommon_py.so")
if (platform.system() == "Windows") :
#  TdhCommon = cdll.LoadLibrary(libDir+"TdhCommon_py.dll") 
  TdhCommon = cdll.LoadLibrary("libDir+libTdhCommon_py.a") 

colorWhite = 0xffffffff
colorBlack = 0xff000000
colorGrey = 0xff7f7f7f
colorLightGrey = 0xffaaaaaa

def C_Str(py_string):
    return c_char_p(py_string.encode('utf-8'))

def StrFromCstr (cParam :c_char_p) :
    return cParam.decode()

class TStringIntf_py :
# provides access to a C++ std::string
    def __init__(self):
        self.cPtr = TdhCommon.Create_StringIntf_py()
    def __exit__ (self):
        TdhCommon.Delete_StringIntf_py (self.cPtr) 
    def get_Str (self):
       return StrFromCstr(TdhCommon.String_Intf_getStr (self.cPtr))   
    def set_Str (self, strParam):
       TdhCommon.String_Intf_setStr (self.cPtr, C_Str(strParam))

class TStringVectorIntf_py :
# provides access to a C++ TStringVector
    def __init__(self):
        self.cPtr = TdhCommon.Create_StringVectorIntf_py()
    def __exit__ (self):
        TdhCommon.Delete_StringVectorIntf_py (self.cPtr) 
    def get_Str (self, pos :c_int):
       return StrFromCstr(TdhCommon.StringVector_Intf_getStr (self.cPtr, pos))   
    def PushStr (self, strParam):
       TdhCommon.StringVector_Intf_PushStr (self.cPtr, C_Str(strParam))
    def Count (self):
       return TdhCommon.StringVector_Intf_Count (self.cPtr)
    def Clear (self):
       TdhCommon.StringVector_Intf_Clear (self.cPtr)

def StringIntf_Cfuncs ():
  TdhCommon.String_Intf_getStr.argtypes = [c_void_p]
  TdhCommon.String_Intf_getStr.restype = c_char_p

  TdhCommon.String_Intf_setStr.argtypes = [c_void_p, c_char_p]

  TdhCommon.Create_StringIntf_py.restype = c_void_p
  TdhCommon.Delete_StringIntf_py.argtypes = [c_void_p]

def StringVectorIntf_Cfuncs ():
  TdhCommon.StringVector_Intf_getStr.argtypes = [c_void_p, c_int]
  TdhCommon.StringVector_Intf_getStr.restype = c_char_p

  TdhCommon.StringVector_Intf_PushStr.argtypes = [c_void_p, c_char_p]

  TdhCommon.StringVector_Intf_Count.argtypes = [c_void_p]
  TdhCommon.StringVector_Intf_Count.restype = c_int

  TdhCommon.StringVector_Intf_Clear.argtypes = [c_void_p]

  TdhCommon.Create_StringVectorIntf_py.restype = c_void_p
  TdhCommon.Delete_StringVectorIntf_py.argtypes = [c_void_p]



def Set_RecordsNav_Cfuncs ():
  TdhCommon.RecordsNav_pyStr_AddRec.restype = c_bool
  TdhCommon.RecordsNav_pyStr_AddRec.argtypes = [c_void_p, c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_DeleteAll.restype = c_bool
  TdhCommon.RecordsNav_pyStr_DeleteAll.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_DeleteOne.restype = c_bool
  TdhCommon.RecordsNav_pyStr_DeleteOne.argtypes = [c_void_p, c_char_p, c_bool]
  TdhCommon.RecordsNav_pyStr_DeleteCount.restype = c_bool
  TdhCommon.RecordsNav_pyStr_DeleteCount.argtypes = [c_void_p, c_uint, c_uint]
  TdhCommon.RecordsNav_pyStr_GetFirst.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetFirst.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GetNext.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetNext.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_GetLast.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetLast.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GetPrev.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetPrev.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_GetRec.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetRec.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_GetItem.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetItem.argtypes = [c_void_p, c_uint]
  TdhCommon.RecordsNav_pyStr_get_Count.restype = c_uint
  TdhCommon.RecordsNav_pyStr_get_Count.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_DefaultRec.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_DefaultRec.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_set_DefaultRec.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_DataExists.restype = c_bool
  TdhCommon.RecordsNav_pyStr_DataExists.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GotoFirst.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoFirst.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GotoLast.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoLast.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GotoNext.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoNext.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GotoPrev.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoPrev.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GotoRec.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoRec.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_GotoNear.restype = c_bool
  TdhCommon.RecordsNav_pyStr_GotoNear.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_AtFirst.restype = c_bool
  TdhCommon.RecordsNav_pyStr_AtFirst.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_AtLast.restype = c_bool
  TdhCommon.RecordsNav_pyStr_AtLast.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_get_RecNum.restype = c_uint
  TdhCommon.RecordsNav_pyStr_get_RecNum.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GetKey.restype = c_char_p
  TdhCommon.RecordsNav_pyStr_GetKey.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_KeyComp.restype = c_int
  TdhCommon.RecordsNav_pyStr_KeyComp.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_SetKey.restype = c_bool
  TdhCommon.RecordsNav_pyStr_SetKey.argtypes = [c_void_p, c_char_p, c_bool]
  TdhCommon.RecordsNav_pyStr_SetOrGetKey.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_SetOrGetKey.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_get_UnUsedObj.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_get_UnUsedObj.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_GetData.restype = c_void_p
  TdhCommon.RecordsNav_pyStr_GetData.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_SetData.restype = c_bool
  TdhCommon.RecordsNav_pyStr_SetData.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_GetPosition.restype = c_uint
  TdhCommon.RecordsNav_pyStr_GetPosition.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_NewData_nokey.restype = c_bool
  TdhCommon.RecordsNav_pyStr_NewData_nokey.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_KeyToStr.restype = c_char_p
  TdhCommon.RecordsNav_pyStr_KeyToStr.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_KeyError.restype = c_bool
  TdhCommon.RecordsNav_pyStr_KeyError.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_KeyUsed.restype = c_bool
  TdhCommon.RecordsNav_pyStr_KeyUsed.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_GetNextAvailableKey.restype = c_char_p
  TdhCommon.RecordsNav_pyStr_GetNextAvailableKey.argtypes = [c_void_p, c_char_p]
  TdhCommon.RecordsNav_pyStr_AddNotify.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_RemoveNotify.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_pyStr_SetIDs.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_Hide.restype = c_bool
  TdhCommon.RecordsNav_pyStr_Hide.argtypes = [c_void_p]
  TdhCommon.RecordsNav_pyStr_set_Hide.argtypes = [c_void_p, c_bool]
  TdhCommon.RecordsNav_queue_Push.restype = c_bool
  TdhCommon.RecordsNav_queue_Push.argtypes = [c_void_p, c_void_p]
  TdhCommon.RecordsNav_queue_Pop.restype = c_void_p
  TdhCommon.RecordsNav_queue_Pop.argtypes = [c_void_p]
  TdhCommon.RecordsNav_queue_Insert.restype = c_bool
  TdhCommon.RecordsNav_queue_Insert.argtypes = [c_void_p, c_void_p, c_uint]
  TdhCommon.RecordsNav_queue_InsertNav.restype = c_bool
  TdhCommon.RecordsNav_queue_InsertNav.argtypes = [c_void_p, c_void_p, c_uint]

def Set_PointXY_Cfuncs ():
  TdhCommon.PointXY_py_setX.argtypes = [c_void_p, c_double]
  TdhCommon.PointXY_py_setY.argtypes = [c_void_p, c_double]
  TdhCommon.PointXY_py_getX.restype = c_double
  TdhCommon.PointXY_py_getX.argtypes = [c_void_p]
  TdhCommon.PointXY_py_getY.restype = c_double
  TdhCommon.PointXY_py_getY.argtypes = [c_void_p]
  TdhCommon.PointXY_py_SetXY.argtypes = [c_void_p, c_double, c_double]
  TdhCommon.PointXY_py_CopyXY.argtypes = [c_void_p, c_void_p]
  TdhCommon.PointXY_py_CopyXY.argtypes = [c_void_p, c_double, c_double]
  TdhCommon.PointXY_py_IsShareable.restype = c_bool
  TdhCommon.PointXY_py_IsShared.restype = c_bool
  TdhCommon.PointXY_py_okToDelete.restype = c_bool
  TdhCommon.PointXY_py_ShareCode.restype = c_uint
  TdhCommon.Create_PointXY_py.restype = c_void_p
  TdhCommon.Create_PointXY_py.argtypes = [c_double, c_double]
  TdhCommon.Delete_PointXY_py.argtypes = [c_void_p]
  
def Set_CadRect_Cfuncs ():
  TdhCommon.Create_CadRect_py.restype = c_void_p
  TdhCommon.Delete_CadRect_py.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MinPt.restype = c_void_p
  TdhCommon.CadRect_py_MinPt.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MaxPt.restype = c_void_p
  TdhCommon.CadRect_py_MaxPt.argtypes = [c_void_p]
  TdhCommon.CadRect_py_SetPoints.argtypes = [c_void_p, c_double, c_double, c_double, c_double]
  TdhCommon.CadRect_py_Height.restype = c_double
  TdhCommon.CadRect_py_Height.argtypes = [c_void_p]
  TdhCommon.CadRect_py_Width.restype = c_double
  TdhCommon.CadRect_py_Width.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MaxX.restype = c_double
  TdhCommon.CadRect_py_MaxX.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MaxY.restype = c_double
  TdhCommon.CadRect_py_MaxY.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MinX.restype = c_double
  TdhCommon.CadRect_py_MinX.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MinY.restype = c_double
  TdhCommon.CadRect_py_MinY.argtypes = [c_void_p]
  TdhCommon.CadRect_py_Expand.restype = c_bool
  TdhCommon.CadRect_py_Expand.argtypes = [c_void_p, c_double, c_double]
  TdhCommon.CadRect_py_ExtentsValid.restype = c_bool
  TdhCommon.CadRect_py_ExtentsValid.argtypes = [c_void_p]
  TdhCommon.CadRect_py_ContainsPt.restype = c_bool
  TdhCommon.CadRect_py_ContainsPt.argtypes = [c_void_p, c_double, c_double, c_double]
  TdhCommon.CadRect_py_ContainsRect.restype = c_bool
  TdhCommon.CadRect_py_ContainsRect.argtypes = [c_void_p, c_double, c_double, c_double, c_double, c_double]
  TdhCommon.CadRect_py_InfinExtents.restype = c_bool
  TdhCommon.CadRect_py_InfinExtents.argtypes = [c_void_p]
  TdhCommon.CadRect_py_MidPoint.argtypes = [c_void_p, c_void_p]
  TdhCommon.CadRect_py_CalcArea.restype = c_double
  TdhCommon.CadRect_py_CalcArea.argtypes = [c_void_p]
  TdhCommon.CadRect_py_NearestDist.restype = c_double
  TdhCommon.CadRect_py_NearestDist.argtypes = [c_void_p, c_double, c_double]

def Set_Vertex_Cfuncs ():
  TdhCommon.Vertex_py_GetKey.restype = c_void_p
  TdhCommon.Vertex_py_GetKey.argtypes = [c_void_p]
  TdhCommon.Vertex_py_getX.restype = c_double
  TdhCommon.Vertex_py_getX.argtypes = [c_void_p]
  TdhCommon.Vertex_py_getY.restype = c_double
  TdhCommon.Vertex_py_getY.argtypes = [c_void_p]
  TdhCommon.Vertex_py_setX.argtypes = [c_void_p, c_double]
  TdhCommon.Vertex_py_setY.argtypes = [c_void_p, c_double]
  TdhCommon.Vertex_py_SetXY.argtypes = [c_void_p, c_double, c_double]
  TdhCommon.Vertex_py_setPt.restype = c_bool
  TdhCommon.Vertex_py_setPt.argtypes = [c_void_p, c_void_p, c_bool]
  TdhCommon.Vertex_py_getPt.restype = c_void_p
  TdhCommon.Vertex_py_getPt.argtypes = [c_void_p]
  TdhCommon.Vertex_py_getPtAddr.restype = c_void_p
  TdhCommon.Vertex_py_getPtAddr.argtypes = [c_void_p]
  TdhCommon.Vertex_py_Share.restype = c_void_p
  TdhCommon.Vertex_py_Share.argtypes = [c_void_p, c_void_p]
  TdhCommon.Vertex_py_UnShare.argtypes = [c_void_p]
  TdhCommon.Vertex_py_getPt.restype = c_bool
  TdhCommon.Vertex_py_getPt.argtypes = [c_void_p]
  TdhCommon.Create_VertexNav_py.restype = c_void_p


def Set_MultiLine_Cfuncs ():
   TdhCommon.Create_MultiLine_py.restype = c_void_p
   TdhCommon.Create_MultiLine_py.argtypes = [c_void_p, c_bool]
   TdhCommon.Delete_MultiLine_py.argtypes = [c_void_p]
   TdhCommon.get_TMultiLineProc. restype = c_void_p
   TdhCommon.MultiLine_py_PtNav.restype = c_void_p
   TdhCommon.MultiLine_py_PtNav.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_Closed.restype = c_bool
   TdhCommon.MultiLine_py_Closed.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_set_Closed.argtypes = [c_void_p, c_void_p, c_bool]
   TdhCommon.MultiLine_py_Create_Vertex.restype = c_void_p
   TdhCommon.MultiLine_py_Create_Vertex.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
   TdhCommon.MultiLine_py_AddVertex.restype = c_bool
   TdhCommon.MultiLine_py_AddVertex.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_AddXY.restype = c_void_p
   TdhCommon.MultiLine_py_AddXY.argtypes = [c_void_p, c_void_p, c_double, c_double]
   TdhCommon.MultiLine_py_AddPt.restype = c_void_p
   TdhCommon.MultiLine_py_AddPt.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
   TdhCommon.MultiLine_py_AddPt_First.restype = c_void_p
   TdhCommon.MultiLine_py_AddPt_First.argtypes = [c_void_p, c_void_p, c_double, c_double, c_bool]
   TdhCommon.MultiLine_py_AddPt_shared.restype = c_void_p
   TdhCommon.MultiLine_py_AddPt_shared.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_CopyPt.restype = c_void_p
   TdhCommon.MultiLine_py_CopyPt.argtypes = [c_void_p, c_void_p, c_void_p, c_bool]
   TdhCommon.MultiLine_py_CopyPts.restype = c_void_p
   TdhCommon.MultiLine_py_CopyPts.argtypes = [c_void_p, c_void_p, c_void_p, c_uint, c_uint, c_char]
   TdhCommon.MultiLine_py_CopyPtVals.restype = c_void_p
   TdhCommon.MultiLine_py_CopyPtVals.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_InsertPt.restype = c_bool
   TdhCommon.MultiLine_py_InsertPt.argtypes = [c_void_p, c_void_p, c_double, c_double, c_uint]
   TdhCommon.MultiLine_py_InsertPts.restype = c_bool
   TdhCommon.MultiLine_py_InsertPts.argtypes = [c_void_p, c_void_p, c_void_p, c_uint]
   TdhCommon.MultiLine_py_AddendMultiLine.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_PrependMultiLine.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_ReversePts.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_set_Point.argtypes = [c_void_p, c_void_p, c_uint, c_double, c_double]
   TdhCommon.MultiLine_py_get_Point.restype = c_void_p
   TdhCommon.MultiLine_py_get_Point.argtypes = [c_void_p, c_void_p, c_uint]
   TdhCommon.MultiLine_py_ResetExtents.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_ExtentsValid.restype = c_bool
   TdhCommon.MultiLine_py_ExtentsValid.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_GetExtents.restype = c_void_p
   TdhCommon.MultiLine_py_GetExtents.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_CleanVertices.argtypes = [c_int]
   TdhCommon.MultiLine_py_CleanVertices.argtypes = [c_void_p, c_void_p, c_double]
   TdhCommon.MultiLine_py_UnSharePt.argtypes = [c_void_p, c_void_p, c_uint]
   TdhCommon.MultiLine_py_CalcLength.restype = c_double
   TdhCommon.MultiLine_py_CalcLength.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_CalcMidPt.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_NearestVertex.restype = c_void_p
   TdhCommon.MultiLine_py_NearestVertex.argtypes = [c_void_p, c_void_p, c_double, c_double]
   TdhCommon.MultiLine_py_NearestPt.argtypes = [c_void_p, c_void_p, c_double, c_double, c_void_p]
   TdhCommon.MultiLine_py_CurrVertex.restype = c_void_p
   TdhCommon.MultiLine_py_CurrVertex.argtypes = [c_void_p, c_void_p]
   TdhCommon.MultiLine_py_CurrPt.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_NextPt.restype = c_void_p
   TdhCommon.MultiLine_py_NextPt.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_PrevPt.restype = c_void_p
   TdhCommon.MultiLine_py_PrevPt.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_GotoVertex.restype = c_bool
   TdhCommon.MultiLine_py_GotoVertex.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_MovePt.restype = c_bool
   TdhCommon.MultiLine_py_MovePt.argtypes = [c_void_p, c_void_p, c_double, c_double]
   TdhCommon.MultiLine_py_DeleteVertex.restype = c_bool
   TdhCommon.MultiLine_py_DeleteVertex.argtypes = [c_void_p, c_void_p, c_void_p]
   TdhCommon.MultiLine_py_DeleteCurrent.restype = c_bool
   TdhCommon.MultiLine_py_DeleteCurrent.argtypes = [c_void_p, c_void_p]

def Set_CadOptions_Cfuncs ():
  TdhCommon.Create_CadOptions_py.restype = c_void_p
  TdhCommon.Delete_CadOptions_py.argtypes = [c_void_p]
  TdhCommon.CadOptions_py_set_LonLat.argtypes = [c_void_p, c_bool]
  TdhCommon.CadOptions_py_get_LonLat.restype = c_bool
  TdhCommon.CadOptions_py_get_LonLat.argtypes = [c_void_p]

  TdhCommon.CadOptions_py_setDistUnits.argtypes = [c_void_p, c_int]

  TdhCommon.CadOptions_py_getDistUnits.restype = c_int
  TdhCommon.CadOptions_py_getDistUnits.argtypes = [c_void_p, c_char_p]

  TdhCommon.CadOptions_py_DistUnitsFromStr.restype = c_int
  TdhCommon.CadOptions_py_DistUnitsFromStr.argtypes = [c_void_p, c_char_p]

  TdhCommon.CadOptions_py_DistUnits_ToStr.restype = c_char_p
  TdhCommon.CadOptions_py_DistUnits_ToStr.argtypes = [c_void_p, c_int]

  TdhCommon.CadOptions_py_set_DistTolerance.argtypes = [c_void_p, c_double]
  TdhCommon.CadOptions_py_get_DistTolerance.restype = c_double
  TdhCommon.CadOptions_py_get_DistTolerance.argtypes = [c_void_p]


