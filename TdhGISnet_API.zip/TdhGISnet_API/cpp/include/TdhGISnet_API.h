#ifndef TdhGISnetAPI_Header
#define TdhGISnetAPI_Header

/*
this file provides functionality to read and write TdhGISnet data from a database
and to import TdhGISnet data from an OpenStreetMap (OSM) file.

The Import OSM functionality provided here cannot convert to different coordinates systems.
That functionality is provided in the TdhOGR_API.

when using this functionality, the client must use the data structures defined in the header file GisNetData.h
which are descendants of the data structures defined in TdhPath_Intf.h
*/


#include "TdhPath_Intf.h"
#include "GisNetData.h"


class EXPORTPROC TTdhGISnetIO0 {
public:
  virtual ~TTdhGISnetIO0 () {}
  virtual bool SetDB (tdhString) = 0;
    // sets the directory containing the database file (TdhGISnet_Data.sqlite) to be used.
  virtual bool ReadNetwork (tdhString, TGisNetwork*, bool = true) = 0;
    // reeds a network with the netID (1st param) from the database into the specified network structure (2nd param)
    // if the 3rd param is true, the network structure will be emptied before the new data is added
  virtual bool WriteNetwork (TGisNetwork*) = 0;
    // write network data from a specified network structure (1st param) to the database
  virtual void DeleteNetwork (tdhString) = 0;
    // delete from the database the network with NetID() equal to 1st param
  virtual bool ImportOSM (tdhString, TGisNetwork*, TStringVector*, TStringVector*) = 0;
    // reads data from an OSM file (1st param) into a network structure (2nd param)
    // the 3rd param provides a list {tags, value} combinations required for an element to be imported
    // the 4th param provides a list {tags, value} combinations for which an otherwise eligible element will be excluded
    // see the TdhGISnet help file for complete description of the import process and tag strings
  };

TTdhGISnetIO0 EXPORTPROC *Create_TdhGISnetIO (TMessenger0* = NULL);



#endif // TdhGISnetAPI_Header
