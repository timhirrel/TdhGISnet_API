#ifndef uiUtils_genericHeader
#define uiUtils_genericHeader
// utilities that don't include wx types in their definitions

#include "Common.hpp"
#include "CadPrimitives0.h"

class TCadRect;

extern unsigned EXPORT_common defaultColor_tdh;

class EXPORTPROC TuiUtils_generic {
protected:
public:
  TuiUtils_generic ();
  virtual ~TuiUtils_generic();

  virtual void SortVector(TStringVector);
  virtual bool ToDouble (tdhString, double*);

  virtual tdhString MakeFullPath (tdhString dirStr, tdhString fileStr);
  virtual bool FileExists (tdhString);
  virtual bool DirExists (tdhString);
  virtual tdhString GetPathSeparator ();
  virtual bool MakeDir (tdhString);

  virtual tdhString GetDir_FromUser (tdhString, tdhString = "");
  virtual tdhString RemoveFileFromPath (tdhString);

  virtual tdhString GetExecPath(bool = true) { return ""; }
  virtual tdhString GetDataPath ();
  virtual tdhString GetCurrentPath ();

  virtual tdhString GetTextFromUser (tdhString prompt, tdhString caption ="", tdhString defStr ="");
  virtual bool MessageBox_ok (tdhString, tdhString = "", bool = false);
  virtual bool MessageBox_yes (tdhString, tdhString = "", bool = false);
  virtual bool getRectFromUser (TCadRect*, tdhString); //prompt user for rectangle coordinates and return results. 1st parameter is default coordinates. 2nd parameter is dialog title
  virtual TMessenger0 *Messenger();

  virtual tdhString wxFormatFloat (tdhString formatStr, double floatval);
  virtual tdhString wxPtStr (TPtParam) {return "";}
  virtual bool GetPtFromUser (TPointPtr, tdhString = "Information") {return false;}
  virtual bool GetDoubleFromUser (double*, tdhString);
//int EXPORTPROC get_GridRow (wxGrid*);

  virtual tdhString SaveLiterals (tdhString inStr);
  virtual tdhString RestoreLiterals (tdhString inStr);

  virtual tdhString get_ColorName(unsigned);
  virtual bool ColorNameExists (tdhString);
  virtual bool GetColorCode_fromStr (tdhString, unsigned*);
  virtual bool GetColorCode_fromWxBase (tdhString, unsigned*);
  virtual bool GetColorCode_fromWheel (unsigned*);
  virtual bool GetColorCode_wSelect(tdhString, unsigned*);
  virtual bool GetColorCode_fromUser(unsigned*, tdhString = "");
  virtual unsigned GetColorCode_wDefault (tdhString, unsigned = defaultColor_tdh);

  virtual int DisplayPDF(tdhString);

  virtual tdhString LongToAscTime (long);
  };

extern EXPORT_common TuiUtils_generic *uiUtils;
extern TuiUtils_generic EXPORTPROC *UiUtils ();
EXTERNC EXPORTPROC void Init_UiUtils_generic();

extern char EXPORTPROC UiMessage (std::string, char = 0);
extern char EXPORTPROC UiMessage_yes (std::string, char = 0);

class EXPORT_common TMessenger_Utils : public TMessenger0 {
public:
  virtual char Message (std::string messStr, std::string titleStr = "Information") {
    if (!UiUtils())
      return 0;
    return UiUtils()->MessageBox_ok(messStr, titleStr);
    }
  virtual char Message_confirm (std::string messStr, std::string titleStr = "Confirmation") {
    if (!UiUtils())
      return 0;
    return UiUtils()->MessageBox_yes(messStr, titleStr);
    }
  };
TMessenger_Utils EXPORT_common *Messenger_Utils();

#endif
