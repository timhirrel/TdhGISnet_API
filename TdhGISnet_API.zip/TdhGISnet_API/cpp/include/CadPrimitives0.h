/***************************************************************
 * Copyright: Tim Hirrel (2025)
 * Contact:   timhirrel@tdhgis.com
 **************************************************************/


// Provides the most basic functionality for vector graphics

#ifndef CadPrimitives0_Header
#define CadPrimitives0_Header

#include "ExportDef.hpp"
#include "RecordsNav0.h"

const unsigned int colorWhite = 0xffffffff;
const unsigned int colorBlack = 0xff000000;
const unsigned int colorGrey = 0xff7f7f7f;
const unsigned int colorLightGrey = 0xffaaaaaa;

class TPointXY0;
typedef TPointXY0& TPtParam;

typedef TPointXY0* TPointPtr;

class EXPORTPROC TPointXY0 {
// an abstract class for providing access to x,y coordinates
// provides shell functions for x,y coordinates to be shared by different entities.
protected:
  virtual void Decr_refcount () {}
  virtual void Incr_refcount () {}
  virtual short RefCount () {return 0;}
  virtual void set_ShareCode (unsigned long) {}
  friend class TSharedPt;
public:
  TPointXY0 ();
  virtual ~TPointXY0 ();
  void operator = (TPointXY0&);
  virtual void setX (double) = 0; // sets the x value
  virtual void setY (double) = 0; // sets the y value
  virtual double getX () = 0; // gets the x value
  virtual double getY () = 0; // gets the y value
  virtual void SetXY (double xParam, double yParam) {setX(xParam); setY(yParam);} //sets the x and y values
  virtual void CopyXY (TPointPtr ptParam) {SetXY(ptParam->getX(), ptParam->getY());} //copies the x and y vales from the 1st param
  virtual void CopyXY (TPtParam ptParam) {SetXY(ptParam.getX(), ptParam.getY());}
  virtual bool IsShareable () {return false;} //returns true if the point can be shared
  virtual bool IsShared () {return false;} //returns true if the point is shared
  virtual bool okToDelete () {return true;} //returns true if it is ok to delete the point (i.e. the point is not being used)
  virtual unsigned long ShareCode () {return 0;} //if the point is shared and the share codes are set, returns a unique code. Otherwise, returns 0.
  };


class EXPORTPROC TPointXY : public TPointXY0 {
// an implementation class for x,y coordinates
// this class is used if no other implementation class is specified in TDH's geometric functions
// this class does not implement coordinate sharing
protected:
  double x, y;
public:
  TPointXY ();
  TPointXY(double, double);
  TPointXY (TPtParam);
  TPointXY (TPointPtr);
  virtual bool okToDelete ();
  void operator = (TPointXY);
  void operator = (TPtParam);
  virtual void setX (double val) {x = val;}
  virtual void setY (double val) {y = val;}
  virtual double getX () {return x;}
  virtual double getY () {return y;}
  };

class EXPORTPROC TPointXY_share : public TPointXY {
// an extension of class TPointXY that implements coordinate sharing
// this class is used for coordinate sharing if no other class is specified
protected:
  unsigned long shareCode;
  unsigned short refcount;
  virtual void Decr_refcount ();
  virtual void Incr_refcount ();
  virtual short RefCount () {return refcount;}
  virtual void set_ShareCode (unsigned long val) {shareCode = val;}
  virtual bool okToDelete ();
public:
  TPointXY_share ();
  TPointXY_share (TPtParam);
  virtual ~TPointXY_share ();
  virtual bool IsShareable () {return true;}
  virtual bool IsShared(); //returns true if the point is shared
  virtual unsigned long ShareCode () {return shareCode;} // a value used for I/O of shared points
  };

class EXPORTPROC TPtCreator {
//this class facilitates the use of custom TPointXY0 data types within the api
//by creating a derived class that overrides these functions
//and passing an instance of the derived class using set_PtCreator in TMultiLine0 and TPtGroup
public:
  virtual ~TPtCreator () {}
  virtual TPointPtr Create_Pt () {return new TPointXY;} //override this function to use a TPointXY0 other than TPointXY for TVertex
  virtual bool OwnPt () {return true;} //override this function to specify whether the point is owned by the TVertex
  };

class EXPORTPROC TCadRect0 {
// an abstract class for rectangle functions
// these rectangles are always in line with the coordinate system
public:
  virtual ~TCadRect0 () {}
  virtual TPointPtr MinPt() = 0; //returns the lowest x,y values
  virtual TPointPtr MaxPt() = 0; //return the highest x,y values
  virtual void SetPoints (TPtParam, TPtParam) = 0; //sets the rectangle by specifying 2 opposing corners
  virtual double Height() = 0; //returns the y dimension
  virtual double Width() = 0; //return the x dimension
  virtual double MaxX () = 0; //return the highest x value
  virtual double MaxY () = 0; //return the highest y value
  virtual double MinX () = 0; //return the lowest x value
  virtual double MinY () = 0; //return the lowest y value
  virtual bool Expand (TPtParam) = 0; //the extents are expanded, if necessary, to include the 1st param
  virtual bool ExtentsValid () = 0; //returns true if the distance between the defining points is greater than TCadOptions::get_DistTolerance
  virtual bool ContainsPt (TPtParam, double = -1) = 0;
    //returns true if the extents plus the tolerance (2nd param) contain the 1st param.
    //a 2nd param value < 0 indicates than an api specified default should be used
  virtual bool ContainsRect (TCadRect0*, double = -1) = 0;
    //returns true if the extents plus the tolerance (2nd param) contains any part of the 1st param.
    //a 2nd param value < 0 indicates than an api specified default should be used
  virtual bool InfinExtents () = 0; //returns true if the extents are infinite, i.e. it will always contain everything else
  virtual void MidPoint (TPointPtr) = 0; //returns the midpoint of the rectangle
  virtual double CalcArea() = 0; //returns the area of the rectangle
  virtual double NearestDist (TPtParam) = 0; //return the minimum distance from the pt (1st param) to the rect
  };

class TVertex_tdh; //used internally by TdhCommon

class EXPORTPROC TVertex0 {
// an abstract class used for lists of TPointXY0 data in multi point lines
// by default, a TVertex0 will use a TPointXY, but may use other derivations of TPointXY0, as explained below
// a TVertex0 instance can be created only by functions with TMultiLine0 (to ensure the TVertex0 version is compatible with the TMultiLine0 version
public:
  virtual ~TVertex0 () {}
  virtual TVertex_tdh *GetKey() = 0; //returns the key value for a TVertex0
  virtual double getX() = 0; //return the x value for this vertex
  virtual double getY() = 0; //return the y value for this vertex
  virtual void setX (double) = 0; //sett the x value for this vertex
  virtual void setY (double) = 0; //set the y value for this vertex
  virtual void SetXY (double, double) = 0; //set both the x and y valu  es for this vertex
  virtual void SetXY (TPtParam) = 0; // set the x and y values equal thosed contained in the first parameter
  virtual bool setPt (TPointPtr, bool) = 0;
    // sets the TPointXY used by the vertex, replacing the existing TPointXY
    // the 2nd param specifies whether the TPointPtr is owned by the vertex
  virtual TPointPtr getPt () = 0; //returns the TPointPtr used by the vertex
  virtual TPointXY getPtVal() = 0; // return the x,y values in the form of a TPointXY
  virtual TPointPtr *getPtAddr () = 0; //return the address of the TPointPtr used by the vertex
//the following 3 functions to be overridden if sharing is allowed
  virtual void Share (TPointPtr*) {}
    //if the 1st param is a shared TPointXY0, it will not be changed, otherwise, it will be changed to a shared TPointXY0 using the same xy data
    //this vertex will use the shared TPointXY0 resulting from the above statement
  virtual void UnShare () {} //if the TPointXY0 used by this vertex is shared, it will be replaced with a new, unshared TPointXY0
  virtual bool IsShared () {return false;} //return true if the TPointXY0 is shared
  };

typedef TRecordsNav0 <TVertex0, TVertex_tdh*> TVertexNav;

extern TVertexNav *VertexNav_default;
TVertexNav EXPORTPROC *Create_VertexNav ();

class EXPORTPROC TMultiLine0 {
//an abstract class for for multi point lines
public:
  virtual ~TMultiLine0 () {}
  virtual TVertexNav *PtNav () = 0; //return the TVertexNav for the multiline
  virtual bool Closed () = 0; //returns true if the multiline closes, i.e. the last pt connects to the first pt
  virtual void set_Closed (bool) = 0; //set true if the multiline closes, i.e. the last pt connects to the first pt
  virtual TVertex0 *Create_Vertex (TPtParam) = 0; //return a new TVertex0 using the xy data in the 1st param
  virtual TVertex0 *Create_Vertex (TPointPtr, bool = true) = 0;
    //return a new TVertex0 using the TPointXY instance in the first param.
    //if the 2nd param is true, the TVertex0 instance takes ownership of the TPointXY instance
  virtual bool AddVertex (TVertex0*) = 0; //add the vertex specified in the 1st param
  virtual TVertex0 *AddPt (double, double) = 0; //add a vertex using the x,y data in the params; return the vertex or NULL if not sucessfule
  virtual TVertex0 *AddPt (TPtParam) = 0; //add a vertex using the x,y data in the 1st param; return the vertex or NULL if not sucessfule
  virtual TVertex0 *AddPt (TPointPtr, bool=true) = 0; //calls Create_Vertex using the the 2 params and then AddVertex using the new vertex; return the vertex or NULL if not sucessfule
  virtual TVertex0 *AddPt_First (TPtParam, bool) = 0; //adds a vertex in the first position. if 2nd param is true, all other vertexes are deleted.
  virtual TVertex0 *AddPt_shared (TPointPtr*) = 0; //add a vertex using the shared TPointXY0 in the 1st param (see TVertex0::Share); return the vertex or NULL if not sucessfule
  virtual void set_PtCreator (TPtCreator*) = 0;
    //allows the TMultiLine0 instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TTdhOGR_PtCreator
  virtual TPointPtr CopyPt (TPointPtr*, bool) = 0;
    //for the current vertex in PtNav(),
    // if the 2nd param is true, copy the 1st param as a shared pt  (see TVertex0::Share)
    // if the 2nd param is false, copy the xy data from the 1st parm
    // returns the TPointXY0 for the current vertex
  virtual TMultiLine0 *CopyPts (TMultiLine0* = NULL, unsigned = 0, unsigned = 0, char = 1) = 0;
    // if the 1st param is NULL, a new TMulitLine is created and becomes the target
    // pts are added to the 1st param using data from this PtNav
    // 2nd param is staring at the position within PtNav
    // 3rd param is the number of pts from PtNav
    // 4th param specifies whether the pts are shared, as follows:
      // 0 - pts are never shared, only xy data is used
      // 1 - pt is shared with target if the source pt is shared
      // 2 - all pts are shared
    // returns the target TMultiLine0
  virtual void CopyPtVals (TMultiLine0*) = 0;
    // for up to the number of pts in this or the number of pts in the 1st param
    // the value of a pt in this copied the pt in the corresponding position of the 1st param
  virtual bool InsertPt (TPtParam, unsigned) = 0; //using the xy data from the 1st param insert a vertex at position specified by 2nd param. return true if sucessful
  virtual bool InsertPts (TVertexNav*, unsigned) = 0;
    // the verices contained the 1st param are inserted into PtNav starting as position specified by 2nd param
    // 1st param is emptied. return true if sucessful
  virtual void AddendMultiLine (TVertexNav*) = 0;  //transfer points from param to end of this line, param will lose all points
  virtual void PrependMultiLine (TVertexNav*) = 0; //transfer points from param to beginning of this line, param will lose all points
  virtual void ReversePts () = 0; //reverse the order of vertices in this TMultiLine0
  virtual void set_Point (unsigned, TPtParam) = 0; //for the pt at position 1st param, set the xy value equal to 2nd param
  virtual TPointPtr get_Point(unsigned) = 0; //return TPointXY0 pointer for the pt at position 1st param of PtNav
  virtual void ResetExtents () = 0; //sets extentsvalid as false, called automatically when the pts change
  virtual bool ExtentsValid () = 0; //if extents have been marked invalid, calculates new extents and return true if the extents exceed near zero in both dimensions
  virtual TCadRect0 *GetExtents () = 0; //calls ExtentsValid() and returns a reference to a TCadRect0 containing the extents for the multiline.
  virtual int CleanVertices (double = -1) = 0; //deletes pt when distance from previous pt is < tolerance. returns number of verticies deleted
  virtual void UnSharePt (unsigned) = 0; //unshare pt at position 1st param in PtNave
  virtual double CalcLength () = 0; //return the length of the  multiline.  if closed, include segment from last pt to first pt
  virtual double CalcLength_ratio (TPtParam) = 0;
    // find the point on the multiline nearest the 1st param and the length to that point
    // return the ratio of the the length to point over total length
  virtual TPointXY CalcMidPt () = 0;
    //return the midpoint of the multiline, i.e. equal distance along multiline from 1st pt to last pt.
    //if closed, include segment from last pt to first pt
  virtual TVertex0 *NearestVertex (TPtParam) = 0;// return the vertex on the multiline closest to 1st param
  virtual TPointXY NearestPt (TPtParam) = 0; // return the point on the multiline closest to 1st param
  virtual TVertex0 *CurrVertex()  {return PtNav()->GetData();} //return PtNav current vertex
  virtual TPointXY CurrPt() {return CurrVertex()->getPtVal();} //return the xy data used by the current vertex
  virtual TVertex0 *NextPt (TVertex0* = NULL) = 0;
    // return the next vertex after the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return first vertex
  virtual TVertex0 *PrevPt (TVertex0* = NULL) = 0;
    // return the next vertex before the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return last vertex
  virtual bool GotoVertex (TPointPtr) = 0; //sets the current vertex to the one using the 1st param, if such a vertex belongs to the multiline
  virtual bool MovePt (TPtParam) = 0; //set the xy values for current vertex to the 1st param
  virtual bool DeleteVertex (TVertex0*) = 0; //delete the 1st param from the PtNav
  virtual bool DeleteCurrent () = 0; //delete PtNav current vertex
  virtual void Truncate (double) = 0; //removes segments beyond a specified length (1st param)
  virtual bool Split (double, TMultiLine0*, TMultiLine0*) = 0;
    // split the multiline at the length ratio defined by 1st param
    // set the 2nd and 3rd params to the resulting multilines
    // returns true if both new lines have more then 1 vertex
  };

TMultiLine0 EXPORTPROC *Create_MultiLine (TVertexNav* = NULL, bool = true);
  // create multiline using 1st param as pt navigator and 2nd param owner navigator owner flag
  // if the default parameters are used, a TVertexNav is created


const unsigned char ColorMax = 255;
extern char EXPORTPROC RGBdefault;

struct EXPORTPROC ColorRGB {
  unsigned char blue, green, red, alpha;
  ColorRGB();
  };

union EXPORT_common ColorUnion {
// a class containing data for 24 bit color with an alpha channel
public:
  unsigned int intg;
  ColorRGB RGB;
  ColorUnion () {
      intg = colorGrey;
    }
  ColorUnion (char red, char green, char blue, char alpha) {
    RGB.red = red;
    RGB.green = green;
    RGB.blue = blue;
    RGB.alpha = alpha;
    }
  };

class EXPORT_common TtdhColor {
// a class for setting and accessing colors in various formats
protected:
  virtual tdhString hexStr_field (char);
  virtual char HexField (tdhString*);
  virtual bool Defined ();
public:
  ColorUnion value;
  static char minAlpha;
  TtdhColor ();
  TtdhColor (unsigned, bool = true);
  virtual void set_byRGB (unsigned char redparam, unsigned char greenparam, unsigned char blueparam, unsigned char alphaparam=ColorMax);
  virtual void set_byint (unsigned, bool = true);
  virtual bool sameRGB (TtdhColor);
  virtual unsigned int get_color() {return value.intg;}
  virtual ColorRGB get_colorRGB() {return value.RGB;}
  virtual void set_Alpha (unsigned char val) {value.RGB.alpha = val;}
  virtual tdhString hexStr_rgba (tdhString = "0x");
  virtual void set_byHexStr (tdhString);
  virtual bool Copy (TtdhColor);
  };
extern EXPORT_common TtdhColor default_color;


class EXPORTPROC TCadOptions {
// sets options used in geometry calculations
// by default, Tdh geometry is unit agnostic, whatever units the input data refers to are the units output by calculations
// however, if the input data represent longitude/latitude, then the desired output units should be specified using the setDistUnit functions below
public:
  enum UnitsDist {duOther = -1, duMeters, duFeet, duMiles, duKiloMeters, duLast};
protected:
  virtual void SetDistStrs (); //fills DistStrs. called within constructor.
  UnitsDist distUnits;
  TStringVector distanceUnitStrs;
public:
  TCadOptions (UnitsDist);
  virtual ~TCadOptions () {}
  virtual void set_LonLat (bool); //sets whether geometry is specified using longitude/latitude (affects calculation of distance and area)
  virtual bool get_LonLat (); //returns whether geometry is specified using longitude/latitude
  virtual void set_DistUnits (UnitsDist); //specify units as one of the DistanceUnit enum
  virtual UnitsDist DistUnits (); // return distUnits
  virtual UnitsDist DistUnits_fromStr (tdhString); //specify units as either "meters", "feet", "miles" or "kilometers"
  virtual tdhString DistUnits_toStr (UnitsDist = duLast);
    // return "other", "meters", "feet", "miles" or "kilometer", depending on 1st param
    // if 1st param duLast then distUnits is used;
  virtual TStringVector *DistanceUnitStrs () {return &distanceUnitStrs;} //contains strings for distance units
  virtual void set_DistTolerance (double); // sets the distance below which 2 points are considered equal; default is 1e-5 or 1e-8 for long/lat
  virtual double get_DistTolerance (); //return the current distance tolerance
  virtual double UnitDistX (); // for lonlat cords, conversion ratio from coordinate difference to unit distance on the x axis
  virtual double UnitDistY (); // for lonlat cords, conversion ratio from coordinate difference to unit distance on the y axis
  };
TCadOptions EXPORTPROC *CadOptions ();

/*
inline EXPORTPROC TPointXY0 *PointXY_py (void *ptParam) {
// provide an implementation of TPointXY0 for python bindings
  return (TPointXY0*)ptParam;
  }
*/

#endif // CadPrimitives0_Header
