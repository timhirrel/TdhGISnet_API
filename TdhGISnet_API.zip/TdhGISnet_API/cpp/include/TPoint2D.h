#ifndef TPOINT2D_H_INCLUDED
#define TPOINT2D_H_INCLUDED

#include "CadPrimitives0.h"

typedef double TvgMatrix_array [6];
//typedef TPtParam TPtParam;
typedef TPointXY TPtResult;

class EXPORTPROC TvgMatrix {
// a class defining a matrix used for transforming coordinates
protected:
  TvgMatrix_array values;
public:
  TvgMatrix () {Reset();}
  TvgMatrix (double p0, double p1, double p2, double p3, double p4, double p5) {set_Values(p0,p1,p2,p3,p4,p5);}
  virtual void Reset () {set_Values(1,0,0,1,0,0);}
  virtual void set_Values (double, double, double, double, double, double);
  virtual double Value (int pos) {return values[pos];}
  virtual void set_Value (int, double);
  virtual void incr_Value (int, double);
  virtual void mult_Value(int, double);
  virtual void IncorpMatrix (TvgMatrix);
  virtual TvgMatrix Transform(TvgMatrix);
  };

class EXPORT_common TPoint2D {
// a class for manipulating coordinates
protected:
  TPointPtr point;
  bool ptOwner;
  static bool flipy;
  static bool longlat;
  static double distTolerance;
  static double distTolerance_cordlonlat; //when distance is in lonlat coordindates, i.e. not converted to meters or feet
//  static TCadOptions::DistanceUnits distUnits;
  virtual void DeletePt();
  virtual bool okToDeletePt();
  virtual void SetFromStr (tdhString*, tdhString = "");
public:
  static TPointXY NullPt;
  virtual double angle (TPtParam, bool=true); //if 2nd param true, y will be converted to flipy
  virtual double angle_longlat (TPtParam);
public:
  TPoint2D ();
  TPoint2D (TPointPtr, bool=false);
  TPoint2D (double xparam, double yparam);
  TPoint2D (TPtParam);
  TPoint2D (TPointXY);
  virtual ~TPoint2D ();
  virtual void CopyXY (TPtParam);
  virtual void CopyXY (TPointPtr);
  virtual void setpoint (double, double);

  virtual TPointPtr getPt () {return point;}
  virtual TPointXY getPtVal () {return TPointXY(getX(), getY());}
  virtual void CopyPt (TPoint2D);
  virtual void CopyPt (TPointPtr);
  virtual double getX () {return getPt()->getX();}
  virtual double getY () {return getPt()->getY();}
  virtual void setX (double);
  virtual void setY (double);
  virtual double ConvertY();
  virtual TPointXY Convert (); //returns a converted copy of this
  virtual TPointXY Invert (); //opposite of convert
  virtual double Distance (TPtParam);
  virtual double Cord_Distance (TPtParam);
  virtual bool Within_Distance (TPtParam, double);
//  static double ratio_cord_dist (); //returns ratio of distance to coordinate distance (1 if not lonlat)
  virtual double Angle (TPtParam);
  virtual double ClockAngle (TPtParam);
  virtual double slope (TPtParam);
  bool operator == (TPtParam);
  bool operator != (TPtParam);
  void operator = (TPtParam);
  TPointXY operator + (TPtParam);
  TPointXY operator - (TPtParam);
  TPointXY operator - ();
  TPointXY operator * (double);
  TPointXY operator / (double);
  TPointXY operator * (TPtParam);
  TPointXY operator / (TPtParam);
  virtual bool minDistCheck (TPtParam, double = -1);
  virtual TPointXY MovePt (TPtParam);
  virtual TPointXY ScalePt(TPtParam, TPtParam);
  virtual TPointXY RotatePt(TPtParam, double angle, bool = true);
  virtual TPointXY mid (TPtParam);
  virtual double calcdist_longlat (TPtParam);
  virtual TPointXY rotated (double, double);
  virtual TPointXY mirrorPt ();
  virtual TPointXY mirrorPt (TPtParam, TPtParam);
  static TPointXY FromStr (tdhString*, tdhString = "");
  virtual tdhString asStr (tdhString = "");
  static double CoordFromStr (tdhString);

  //static TPoint2D NullPt();
//  static void setDistUnitsStr (tdhString);
//  static void setDistUnits (int);
//  static TCadOptions::DistanceUnits getDistUnits (tdhString = "");
//  static tdhString getDistStr ();
  static double get_distTolerance (char=0);
  static void set_distTolerance (double);
  static bool get_FlipY();
  static void set_FlipY(bool);
  static bool get_longlat();
  static void set_longlat (bool);
  static double UnitDistX ();
  static double UnitDistY ();
  virtual TPointXY ToCordDist ();
  virtual TPointXY FromCordDist ();
  virtual TPointXY transformMatrix (TvgMatrix);
  virtual TPointXY SkewX (double);
  virtual TPointXY SkewY (double);
//  virtual TPointXY FlipPt (TLine*);
  virtual bool Zero () {return getX()==0 && getY()==0;};
  };


#endif // TPOINT2D_H_INCLUDED
