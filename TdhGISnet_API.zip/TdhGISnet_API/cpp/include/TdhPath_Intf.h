#ifndef TTdhPath_Header
#define TTdhPath_Header

/*
This file defines classes used to:
- define the topology of a network consisting of links connecting to nodes and the weight associated with each link
- designate nodes to be used in a minimum path analysis
- perform a minimum path analysis, which may include
    ` a designated start node
    - a designated end node
    - a list of intermediate nodes that may visited in a defined order or the order which results in the minimum path
` access the result of a minimum path analysis
- create and use temporary nodes at designated locations
*/


#include "CadPrimitives0.h"
#include "StringDef.hpp"
#include "RecordsNav0.h"

// typedef TRecordsNav0 <

//class TTdhPath_Intf0;
class TMinPath;
class TNetNode;
class TNode_draw;
class TNetLink0;
class TNetLink;
class TLink_draw;
class TNetConn;
class TNetConn0;
class TtdhNetwork;
class TtdhNetwork0;
class TtargetNode;
class TtargetNode_wrap;
class TPathData;
class TPathData_wrap;
class TNetTraverse;
class TTempNodeFuncs0;
class TTempNodeFuncs;

enum TColorFlag_gis {cfOwner_gis, cfColor_gis};

const unsigned NoSeg = 0;


typedef TRecordsNav0 <TNetConn0, tdhString> TConnNav; //navigator for TNetConn0

class EXPORTPROC TNetNode0 {
// provides access to the data needed for nodes in network topology
protected:
  TNetNode *nodePtr; //used
  bool tempFlag;
  unsigned segnum;
  TNode_draw *draw;
  virtual TNode_draw *Draw();
  virtual void BeforePop ();
  friend class TNetNode;
public:
  TNetNode0 (TtdhNetwork0*); //constructor for TNetNode0, 1st param is the network to which the node belongs
  virtual ~TNetNode0 ();  // destructor for TNetNode0
  virtual TNetNode *NetNode() {return WrapPtr();} //used internally
  virtual TNetNode *WrapPtr() {return nodePtr;} //used internally
public:
  virtual TtdhNetwork0 *Network (); //return the network to which the node belongs
  virtual tdhString NodeID (); // unique id among nodes in the network
  virtual void set_NodeID (tdhString); // set the unique id
  virtual bool AutoDelete ();  // if true, the node is automatically deleted if all links using the node are deleted
  virtual void set_AutoDelete (bool); // sets autodelete
  virtual bool Temp () {return tempFlag;} // node will be removed when TTempNodesFuncs::RemoveTempsNodes() is called
  virtual void set_Temp (bool tempParam) {tempFlag = tempParam;} //sets Temp flag
  virtual TNetLink0 *DownLink (); // returns the connecting link along calculated path
  virtual TNetNode0 *DownNode (); // return the previous node along the calculated
  virtual TNetConn0 *DownConn(); // returns the TNetConn0 pointing downtree from this node
  virtual double TravVal (); // returns the calculated value at the node along the calculated path
  virtual int LinkCount (); // returns the number of links connecting to the node
  virtual TNetLink0 *GetLink (TNetLink0*);
    // used to access links connected to this.
    // for fist link, set 1st param to NULL
    // for a subsequent link, set 1st param to cufrrent link
  virtual void InitForTraverse () {} //called once before any traversal for a given network configuration
  virtual void ResetForTraverse () {} //called before each network traversal
  virtual unsigned Segment () {return segnum;} //return the network segment number to which the node belongs
  virtual void set_Segment (unsigned segParam) {segnum = segParam;} //set the network number to which the node belongs
  virtual TConnNav *ConnNav (); // a navigator for TNetConn's
  virtual void set_DownConn (TNetConn0*); //set the TNetCoon that goes down the traverse
  virtual TNetNode0 *PopQueue (); // pop a queue representing the order in which the nodes were traversed
  virtual TNetNode0 *PushQueue (); //return the Pushqueue pointer

// the following functions are used to draw the network
// if a drawing is not wanted or if coordinates are not available,
// the memory requirements for the API can be reduced by setting TtdhNetwork0::NoDraw (true)
// in which case the following functions will not produce meaningful results
  virtual TPointXY Pt(); // the geographic point for the node
  virtual void set_Pt (TPtParam); // set the geographic point for the node
  virtual void set_Y (double); // set the y value for the geographic point for the node
  virtual void set_X (double); // set the x value for the geographic point for the node
  virtual TPointPtr Pt_ptr(); // a pointer to the TPointXY data for the node
  virtual double Radius ();  // the radius used to draw the node, in distance units (i.e. converts lon/lat difference to distance)
  virtual void set_Radius (double);  // set the radius used to draw the node, in distance units
  virtual double Radius_cord ();  // the radius used to draw the node, in coordinate units
  virtual void set_Radius_cord (double);  // set the radius used to draw the node, in coordinate units
  virtual unsigned int Color(); // the drawing color, if ColorFlag is set to cf Color_gis
  virtual void set_Color (unsigned); // set the drawing color
  virtual TColorFlag_gis ColorFlag (); // if set to cfOwner_gis the network color is used
  virtual void set_ColorFlag (TColorFlag_gis);  // set ColorFlag
  virtual char Width(); // the drawing width, if 0 the network default width is used.
  virtual void set_Width (char); // set the width
  };
extern TNetNode0 netNode_default; // a default instance of TNetNode0

typedef TRecordsNav0 <TNetNode0, tdhString> TNodeNav; // a navigator for TNetNode0
//extern TNodeNav EXPORTPROC *Create_NodeNav (); // // creates and returns an instance of TNodeNav


class EXPORTPROC TNetLink0 {
// provides access to the data needed for links in network topology
public:
  enum dirFlags {dfReverse=-1, dfOpen, dfCheck, dfClosed};
    // allowed direction of travel
    // dfReverse: from node2 to node1 only
    // dfOpen: either direction
    // dfCheck: from node1 to node2 only
    // dfClosed: neither direction
protected:
  TNetLink *linkPtr; //used internally
  dirFlags restrict;
  double value;
  bool tempFlag;
  TLink_draw *draw; //used internally
  virtual TLink_draw *Draw(); //used internally
public:
  TNetLink0 (TtdhNetwork0*); //constructor for TNetLink0, 1st param is the network to which the node belongs
  virtual ~TNetLink0 (); //destructor for TNetLink0
  virtual TNetLink *NetLink() {return WrapPtr();} //used internally
  virtual TNetLink *WrapPtr() {return linkPtr;} //used internally
public:
  virtual TtdhNetwork0 *Network (); //the network to which the link belongs
  virtual tdhString LinkID (); //a unique id among links in the network
  virtual void set_LinkID (tdhString); //set a unique id among links in the network
  virtual TNetNode0 *Node1 (); //the first node to which the link connects
  virtual TNetNode0 *Node2 (); //the second node to which the link connects
  virtual void set_Node1 (TNetNode0*); //set the first node to which the link connects
  virtual void set_Node2 (TNetNode0*); //set the second node to which the link connects
  virtual TNetNode0 *get_Node (char); //return either the first or second node depending on whether the 1st param is 1 or 2
  virtual void set_Node (char, TNetNode0*, bool=false);
    // sets the 2nd param as the node for the link in position determined by 1st param
    // if the 3rd param is false, the existing node will he deleted, if it connects to no other link
  virtual void set_NodeByKey (char, tdhString);
    //call set_Node (1st param, Network()->GetNode (2nd param, true))
  virtual TNetConn0 *CreateConn (char);
    // returns a new TNetConn0. 1st param specifies direction (1 = node1 to node2, -1 = node2 to node1)
  virtual dirFlags Restrict (); //the travel restriction parameter for the link
  virtual void set_Restrict (dirFlags); //sets the travel restriction parameter for the link
  virtual bool TempClosed () {return false;}
    //returns true if the link is temporarily closed
    // (i.e. will be automatically opened for next analysis unless otherwise specified
  virtual char Status (bool);
    // returns 1 if the link is open, 0 if it closed for the specified direction
    // 1st param specifies desired direction, 0 for node1 to node2, 1 for node2 to node1
//  virtual bool Temp (); //returns true if the link was added as a temporary link
  virtual double Value (); //the value used for the link when calculating path values
  virtual void set_Value (double); //sets the value used for the link when calculating path values
  virtual void set_Temp (bool valParam) {tempFlag = valParam;} // sets Temp
  virtual bool Temp () {return tempFlag;}  // link will be removed when TTempNodesFuncs::RemoveTempsNodes() is called
  virtual void SplitAttributes (TNetLink0*, TNetLink0*, double);
    // split this link's attributes (e.g. multiline  and Value) among the 1st param and 2nd param
    // with the 3rd param specifying the the ratio of the split
  virtual void unSplitAttributes  (TNetLink0*);
    // combine attribute of 1st param into this (multiline and value)
  virtual TNetLink0 *CopyDataTo (TNetLink0*); //copies attributes to another link
  virtual void InitForTraverse (); //called once before any traversal for a given network configuration
  virtual void ResetForTraverse (); //called before a traverse

// the following functions are used to draw the network
// if a drawing is not wanted or if coordinates are not available,
// the memory requirements for the API can be reduced by setting TtdhNetwork0::NoDraw (true)
// in which case the following functions will not produce meaningful results
  virtual double Radius (); //the radius used to draw the link id, in distance units
  virtual void set_Radius (double); //sets the radius used to draw the link id, in distance units
  virtual double Radius_cord (); //the radius used to draw the link id, in coordinate units
  virtual void set_Radius_cord (double); //sets the radius used to draw the link id, in coordinate units
  virtual TPointXY LabelPt (); //the geographic point for drawing the link id
  virtual void set_LabelPt (TPtParam); //sets the geographic point for drawing the link id
  virtual TPointPtr LabelPt_ptr (); //returns pointer to LabelPt
  virtual unsigned Color();  // the drawing color, if ColorFlag is set to cf Color_gis
  virtual void set_Color (unsigned);  // set Color
  virtual TColorFlag_gis ColorFlag (); // if set to cfOwner_gis the network color is used
  virtual void set_ColorFlag (TColorFlag_gis);  // set ColorFlag
  virtual char Width(); // the drawing width, if 0 the network default width is used.
  virtual void set_Width (char); // set the width
  virtual TMultiLine0 *MultiLine (); // returns a TMultiLine0 containing the link vertex points between the nodes
  virtual double CalcLength (); //returns the length of the link, in distance units
  virtual TCadRect0 *GetExtents (); // returns the coordinate extents of the link
  virtual TPointXY NearestPt (TPtParam); // return the point on the link closest to cordPt
  virtual TMultiLine0 *ToMultiLine(); //returns a multiline combining the nodes and any multiline points
  virtual void FromMultiLine (TMultiLine0*, bool=true);
    //uses a TMultiLine0 (1st param) to set link geometry
    //if 2nd param is true, the first and last vertices of the 1st param used as the points for the nodes 1 and 2, respectively
  virtual bool SplitMultiline (TNetLink0*, TNetLink0*, double);
    // spli this link multiLine into 1st param and 2nd param
    // with the 3rd param specifying the the ratio of the distance to the split77 point over the link length
  virtual TPointXY GetNodeCords (int); //returns the node pt for link node in the position of the 1st param (1 or 2)
  virtual double GetNodeRadius (int); //return radius of node at pos of 1st param (1 or 2)
  };
extern TNetLink0 netLink_default; //a default instance of TNetLink0

typedef TRecordsNav0 <TNetLink0, tdhString> TLinkNav; //navigator for TNetLink0
//extern TLinkNav EXPORTPROC *Create_LinkNav (); // // creates and returns an instance of TLinkNav


class EXPORTPROC TNetConn0 {
// data desribing which links connect to a node
// this data is stored in a navigator belonging to the node
// instances of this class are not normally created by the API user
protected:
  TNetConn *wrapPtr;
public:
  TNetConn0 (TNetLink0*, char);
  virtual ~TNetConn0 ();
  virtual TNetConn *WrapPtr() {return wrapPtr;} //used internally
  virtual TNetLink0 *Link (); // the link being referenced
  virtual tdhString LinkID () {return Link()->LinkID();} // the id of the link being referenced
  virtual void set_ConnNode (TNetNode0*, TNetConn0* = NULL); // set the other node for the link and the OppConn, optionally
  virtual TNetNode0* ConnNode (); // the other node for the link
  virtual TNetConn0 *OppConn (); // the other TNetConn0 for the referenced link
  virtual TNetConn0 *DownConn (); //the DownConn() for CannNode()
  virtual char Dir (); //1 = from node1, -1 = from node2
  virtual TNetConn0 *NextConn(); // return the next TNetConn0 in the list
  };
extern TNetConn0 netConn_default;


class EXPORTPROC TtdhNetwork0 {
// contains link and node data for a network
protected:
  TtdhNetwork *network; //used internally
  TNodeNav *nodeNav; //used internally
  TLinkNav *linkNav; //used internally
  TNetTraverse *traverse;
  bool noDraw;
  friend class TNetTraverse;
public:
  TtdhNetwork0 (); //constructor for TtdhNetwork
  virtual ~TtdhNetwork0 (); //destructor for TtdhNetwork
  virtual TtdhNetwork *Network() {return network;} //used internally
  virtual TNetTraverse *Traverse () {return traverse;}  //used by extensions
  virtual bool NoDraw () {return noDraw;}  // if true, the network components will not include geographic data
  virtual void set_NoDraw (bool val) {noDraw = val;} // set noDraw
  virtual TNetNode0 *Create_Node0 (); //returns an instance of TNetNode0 appropriate the version of TtdhNetowrk0
  virtual TNetLink0 *Create_Link0 (); //returns an instance of TNetLink0 appropriate the version of TtdhNetowrk0
  virtual TNodeNav *NodeNav () {return nodeNav;} // returns default navigator for nodes in network
  virtual TLinkNav *LinkNav () {return linkNav;} // returns default navigator for links in netwofk
  virtual void set_NodeNav (TNodeNav *navParam) {nodeNav = navParam;} //set default navigator for nodes
  virtual void set_LinkNav (TLinkNav *navParam) {linkNav = navParam;} //set default navigator for links
  virtual TNodeNav *Create_NodeNav (bool = false);
   //create a new navigator for nodes.
   //if 1st param is true create a new node list for the navigator, otherwise, use default list
  virtual TLinkNav *Create_LinkNav (bool = false);
   //create a new navigator for links.
   //if 1st param is true create a new link list for the navigator, otherwise, use default list
  virtual void DeleteConns (); //delete all TNetConn0's for all nodes
public:
  virtual tdhString NetID(); // return id for the network
  virtual void set_NetID (tdhString); // sets d for the network
  virtual TNetNode0 *AddNode (tdhString, bool = false);
   // create and add a node to the network
   // 1st param is node id
   // if 2nd param is true and there is an existing node with the same id, the existing node will be replaced
   // returns new node or NULL if an existing node with same id is not replaced
  virtual TNetLink0 *AddLink (tdhString, bool = false);
   // create and add a link to the network
   // 1st param is link id
   // if 2nd param is true and there is an existing link with the same id, the existing link will be replaced
   // returns new link or NULL if an existing link with same id is not replaced
  virtual TNetNode0 *GetNode (tdhString, bool = false);
    // returns an existing node with an id equal to the 1st param, if such a node exists
    // otherwise, if the 2nd param is true, creates and return such a node
    // otherwise returns NULL
  virtual bool DeleteNode (TNetNode0*); //deletes a node (1st param) if it is not used by any link

  virtual TNetNode0 *SplitLink (TNetLink0*, double, tdhString, tdhString*, tdhString*);
    // splits a link (1st param), placing a new node at a position determined by 2nd param (ratio of length to position over total length)
    // the link value is divided between the 2 new links proportional to 2nd param
    // the existing link is removed from the network but the instance is not deleted. the instance should be saved or deleted by the client
    // if the 3rd param is not blank, it will be used for the new node id, otherwise an id will be assigned automaticallly
    // if the 4th param is not blank, it will be used for the 1st new link id, otherwise an id will be assigned automaticallly
    // if the 5th param is not blank, it will be used for the 2nd new link id, otherwise an id will be assigned automaticallly
    // the new node will be returned
  virtual TNetLink0 *FindConnectedLink (tdhString, tdhString);
    // find a link connected to the node specified by the 1st param
    // set 2nd param = "" to find first link or to a link id to find the following link.
    // returns NULL if no link found
  virtual void Reset (); //deletes all nodes and links in the network, sets id to "new"
  virtual tdhString Description(); // return user defined description for the network
  virtual void set_Description (tdhString); // set a user defined description for the network
  virtual unsigned int get_defaultColor () {return 0;} // return the color used to draw network elements when the element ColorFlag is set to cfOwner_gis
  virtual TNetNode0 *PopQueueHead (); // return the head node of a queue representing the order in which the nodes were traversed
  };
extern TtdhNetwork0 network_default; // a default instance of TtdhNetwork0



class EXPORTPROC TtargetNode0 {
// data for a target node in a minpath analysis
public:
  virtual ~TtargetNode0 (){}
  virtual TtargetNode *TargetNode() = 0; //used internally
  virtual tdhString NodeID () = 0; // return id for the node being referenced
  virtual void set_NodeID (tdhString) = 0; // set id for the node being referenced
  virtual TtargetNode_wrap *GetKey () = 0; // returns a unique value for a TtargetNode0 instance, useable in navigator functions
  virtual bool StartFlag () = 0; // indicates whether the instance can be used as a start node
  virtual void set_StartFlag (bool) = 0;  // sets whether the instance can be used as a start node
  virtual bool EndFlag () = 0; // indicates whether the instance can be used as an end node
  virtual void set_EndFlag (bool) = 0; // sets whether the instance can be used as an end node
  virtual bool IntermediateFlag () = 0; // indicates whether the instance can be used as an intermediate target
  virtual void set_IntermediateFlag (bool) = 0; // sets whether the instance can be used as an intermediate target
  };

TtargetNode0 EXPORTPROC *Create_TargetNode (tdhString); //returns a new TtargetNode0 instance

typedef TRecordsNav0 <TtargetNode0, TtargetNode_wrap*> TTargetNodeNav; // defines a TtargetNode0 navigator

TTargetNodeNav EXPORTPROC *Create_TargetNodeNav (); // returns a new TtargetNode0 navigator



class EXPORTPROC TPathData0 {
// provides data describing the components of a calculated path
// instances of this class are accessed through TPath0
public:
  enum {pcGisNode, pcGisLink}; //defines the possible path data types
  virtual ~TPathData0 () {}
  virtual TPathData *PathData () = 0; //used internally
  virtual TPathData_wrap *GetKey () = 0; //a unique value for TPathData0 within a TPathData0 navigator
  virtual TNetNode0 *Node () = 0; //if DataType() is pcGisNode, references the TNetNode0 in the path
  virtual TNetLink0 *Link () = 0; //if DataType() is pcGisLink, references the TNetLink0 in the path
  virtual char DataType () = 0; //returns the data type for the instance, pcGisNode or pcGisLink
  virtual int Dir () = 0; // for link data, indicates direction of travel, 1 = from node1 to node2, -1 = from node2 to node1
  };

typedef TRecordsNav0 <TPathData0, TPathData_wrap*> TPathDataNav; //defines a navigator for TPathData0

class EXPORTPROC TPath0 {
// provides the data needed to define a calculated path
// an instance of this class is access through TTdhPath_Intf0
public:
  virtual ~TPath0 () {}
  virtual TPathDataNav *PathData () = 0; // returns a TPathData0 navigator containing elements of a calculated path
  virtual double Distance () = 0; // returns the net of link values along the path
  virtual tdhString NetID () = 0; // returns the id for the network from which the path was calculated
  };


class EXPORTPROC TTdhPath_Intf0 {
// provides the functionality needed to calculate minimum paths
protected:
public:
  enum TPathMethod {pmSpecified, pmNearest, pmMinimum};
    //defines options for a minimum path analysis
    //pmSpecified: intermediate nodes will be visited in the specified order
    //pmNearest: the intermediate node nearest to the preceding node will be visited
    //pmMinimum: the intermediate nodes will be visited in the order which results in the minimum path
  virtual ~TTdhPath_Intf0 () {}
  virtual TMinPath *MinPath() = 0; //used internally by the TdhGISnet API
  static const char *NoneStr() {return "[None]";}
  static const char *NearStr() {return "[Nearest]";}
  virtual tdhString NotFoundStr() = 0; //returns a message listing target nodes not found
  virtual TtdhNetwork0 *Network0 () = 0; // returns the network being used
  virtual TPath0 *CalculatedPath() = 0; // returns the calculated path
  virtual bool FindMinPath (tdhString, tdhString, TTargetNodeNav*, TPathMethod) = 0;
    // find the minimum path between 1st param and 2nd param
    // using the 3rd param as intermediate nodes, as determined by 4th param (see TPathMethod)
    // if the 2nd param is NearStr(), nly the path to the nearest intermediate node will be found
    // if the 4th param is pmMinimum:
        // if the 1st param is NoneStr(), any intermediate node can be the start node
        // if the 2nd param is NoneStr(), any intermediate node can be the end node
    // returns false if no path is found
    // results are retrieved through CalculatedPath()
  virtual tdhString ReportCSV () = 0; //returns a report listing the calculated path
//  virtual TTempNodeFuncs *TempNodeFuncs () {return tempNodeFuncs;}
//  virtual void AddOneTempNode (tdhString *tempStr) = 0;
//  virtual void set_MaxDistFactor (double) = 0;

  virtual TNetNode0 *MaxTravel (tdhString, double) = 0;
    // starting from node defined by param 1
    // find the travel time to every node
    // with a travel time no more than the 2nd param (if greater than 0)
    // results can be retrieved through TNetNode0::TravVal() or in report form through ReportTravTimes()
    // return the starting node
  virtual tdhString ReportTravTimes () = 0; // return a list of all nodes visited during a call to MaxTravel() and their TravVal()
  virtual TTempNodeFuncs0 *TempNodeFuncs() = 0; // returns an instance of TTempNodeFuncs0
  virtual void RemoveTempNodes () = 0;
    // removes all temporary nodes in the associated network
    // clears calculated path
  };

TTdhPath_Intf0 EXPORTPROC *Create_TdhPath_Intf (TtdhNetwork0*, TMessenger0* = NULL);
  // return a new instance TTdhPath_Intf0
  // 1st param is the network to be used in the path calculations
  // 2nd param is using for handling messages from TTtdhPath_Intf0. Messeger_Utils() can be used for console output


class EXPORTPROC TTempNodeFuncs0 {
// provides functionality for creating and removing temporary nodes
public:
  virtual ~TTempNodeFuncs0 () {}
  virtual TTempNodeFuncs *TemmpNodeFuncs() = 0; //used internally
  static const char *TempFlagStr() {return "[temp]";}
  static const char *TempDelim () {return ":";}
  virtual TtdhNetwork0 *Network () = 0; //the network to which nodes will be added
  virtual TNetNode0 *AddNode (TNetLink0*, double, tdhString, tdhString*, tdhString*) = 0;
    // TtdhNetwork0::SplitLink is called is called, using the same parameters, creating a new node and replacing the existing link with 2 new links
    // the new node and links will be removed and the original link restored when RemoveTempNodes is called
    // the new node is returned
  virtual TNetNode0 *AddNodeAtPt (TPtParam, tdhString) = 0;
    // after finding the link which passes closest to the 1st param and the closest point
    // AddNode will be called
    // the 2nd param will be the id for the new node, if the param is not blank and not already used; otherwise an id will be assigned automatically
    // the new node is returned
  virtual bool AddOneTempNode (tdhString*) = 0;
    // calls AddNodeAtPt if the 1st param has the format:
    // "[temp]:<nodeid>:<x,y coordinates>
  virtual bool AddTempNodes (tdhString*, tdhString*, TTargetNodeNav*) = 0;
    // calls AddOneTemoNode for 1st and 2nd param and all nodes listed in the 3rd param
  virtual TNetNode0* FindCordNode (TPtParam) = 0; // return the node closest to the 1st param
  virtual TNetLink0* FindCordLink (TPtParam) = 0; // return the link passing closest to the 1st param
  };

TTempNodeFuncs0 EXPORTPROC *Create_TempNodeFuncs (TtdhNetwork0*); //return a new instance of TTempNodeFuncs

#endif // TTdhPath_Header
