#ifndef TDHGISNETDATA_H_INCLUDED
#define TDHGISNETDATA_H_INCLUDED

/*
this file extends classes found in TdhPath_Intf.h by:
  - adding data used for displaying network components as vector graphics
  - adding data for travel weights and direction restrictions to links
adds a link group class so that certain link attributes can be modified by group
*/

//#include "TdhMinPath.h"
//#include "TdhPathFuncs.h"
#include "TdhPath_Intf.h"
#include "CadPrimitives0.h"
#include "TPoint2D.h"

enum TypesElement {etCadNetLine, etPathLink, etPathNode, etLinkText, etNodeText};
  //enumerates the types of elements included in a network drawing
enum UnitsTime{tuHours, tuMinutes, tuSeconds};
  //enumerates the time units recognized by the API
enum UnitsSpeed {suNone = -1, suMiHr, suKmHr, suFtMn, suMtMn, suFtSc, suMtSc};
  //enumerates the speed units recognized by the API

class TGisNetwork;

class TGisNode : public TNetNode0 {
// an extension of TNetNode0 adding data used for writing to database
protected:
  unsigned long savecode;
public:
  TGisNode (TGisNetwork*);
  virtual ~TGisNode () {}
  virtual TGisNetwork *GisNetwork () {return (TGisNetwork*)Network();}
  virtual void set_Savecode (unsigned long codeParam) {savecode = codeParam;} // used internally
  virtual unsigned long Savecode () {return savecode;} // used internally
  };

TGisNode *Create_GisNode (TGisNetwork*); //return a new instance of TGisNode

class TGisLink;
class TLinkGroup;

class EXPORTPROC TLinkGroup0 {
// allows links to be grouped and link attributes to be modified by group
public:
  enum LinkGroupStatus {lgClosed, lgOpen};
protected:
  TLinkGroup *groupPtr;
  LinkGroupStatus status;
  double factor;
  TGisNetwork *network;
  virtual void onDelete ();
//  virtual tdhString *keyPtr () {return &groupId;}
public:
  TtdhColor color;
  TLinkGroup0 (TGisNetwork*);
  virtual ~TLinkGroup0 () {onDelete();}
  virtual TLinkGroup *WrapPtr() {return groupPtr;} //used internally
  virtual tdhString GroupID (); //a unique id with the link groups in the net
  virtual void set_GroupID (tdhString); //set a unique id with the link groups in the network
  virtual TGisNetwork *Network (); //the network to which the group belongs.
  virtual TGisLink *GetLink (TGisLink*);
    // used to access links in group.
    // for fist link, set 1st param to NULL
    // for a subsequent link, set 1st param to current link
  virtual LinkGroupStatus Status () {return status;} // determines status of links in group, if the link status is open (does not override a closed loml_
  virtual void set_Status (LinkGroupStatus valParam) {status = valParam;} //sets group status
  virtual double Factor () {return factor;} //a factor applied to the value of all links in the group
  virtual void set_Factor (double val) {factor = val;} //set a factor applied to the value of all links in the group
  };
extern TLinkGroup0 linkGroup_default;

typedef TRecordsNav0 <TLinkGroup0, tdhString> TLinkGroupNav; // a navigator for TNetNode0


class TGisLink : public TNetLink0 {
// an extension of TNetLink0 adding data used for:
  // easily switching between distance analysis and travel time analysis
  // modifying link values by a factor
  // modifying link attributes by group
protected:
//  char tempClosed;
  double factor;
  TLinkGroup0 *groupPtr;
  UnitsSpeed speedUnits;
public:
  TGisLink (TGisNetwork*);
  virtual ~TGisLink () {}
  virtual TGisNetwork *GisNetwork() {return (TGisNetwork*)Network();}
  virtual double Value (); //returns values * Use_factor();
//  virtual void set_tempClosed (char tempFlag) {tempClosed = tempFlag;} //sets whether the link is closed on a temporary baais
//  virtual char get_tempClosed () {return tempClosed;} // if true the link will be closed, but this parameter will not be saved
  virtual TNetLink0 *CopyDataTo(TNetLink0*); //extends TNetLink0::CopyDataTo, copying data provided in TGisLink
  virtual TGisNode* Node1_gis () {return (TGisNode*)Node1();} // returns a TGisNode for 1st link node
  virtual TGisNode* Node2_gis () {return (TGisNode*)Node2();} // returns a TGisNode for 2nd link node
  virtual void set_Group (TLinkGroup0 *ptrParam) {groupPtr = ptrParam;}
  virtual void set_Group_byName (tdhString);
    // finds link group with id = 1st param or creates group, sets groupPtr
  virtual TLinkGroup0 *Group () {return groupPtr;} // sets group
  virtual void set_Speed (double, UnitsSpeed = suNone);
    // sets speed
    // 1st param is speed, 2nd param is speed units
    // if 2nd param is suNone, then network speed units is used
    // sets factor equal to speed
    // sets speed units for link
  virtual UnitsSpeed SpeedUnits () {return speedUnits;} //returns speed units
  virtual tdhString SpeedUnits_asStr (); //returns a string for speed units
  virtual void set_Speed (double speedParam) {set_Factor(speedParam);}
  virtual void set_Factor (double val) {factor = val;}
    //sets factor for link. set link speed units to suNone
  virtual double Factor () {return factor;} //returns factor
  virtual double Use_Factor ();
    // sets result = factor. if Group(), sets result *= Group()->Factor()
    // if SpeedUnints() = suNone, returns result
    // else, uses result, SpeedUnits(), CadOptions()->DistUnits() and GisNetwork()->TimeUnit() to calculate a speed factor,
    // such that Use_Facgtor() * Value() = travel time in GisNetwork()->TimeUnits(), assuming Value() represents distance

  };
extern TGisLink gisLink_default; //a default instance of TGisLink


TGisLink *Create_GisLink (TGisNetwork*); //return a new TGisLink



typedef TRecordsNav0 <TGisNode, tdhString> TGisNodeNav; // a navigator for TGisNode
typedef TRecordsNav0 <TGisLink, tdhString> TGisLinkNav; // a navigator for TGisLink
typedef TRecordsNav0 <TLinkGroup0, tdhString> TLinkGroupNav; // a navigator for TLinkGroup0

class EXPORTPROC TGisNetwork : public TtdhNetwork0 {
protected:
  TLinkGroupNav *linkGroupNav;
  TLinkGroup0 *linkGroup_net;
  UnitsSpeed speedUnits;
  UnitsTime timeUnits;
//  TCadOptions::DistanceUnits distUnits;
  bool use_factors, timeFlag;
  virtual void SetUnitsStrs (); //fills SpeedStrs and TimeStrs. called within constructor.
  TStringVector speedUnitsStrs, timeUnitsStrs; //DistStrs,
    // SpeedStrs - a list of strings corresponding to UnitsSpeed
    // TimeStrs - a list of strings corresponding to UnitsTime
public:
  double default_radius, min_radius, text_ratio;
    // default radius, used if a node or link radius is set to zero
    // minimum radius, used if a node or link radius is set below this value
    // the ratio of the width of node or link id to the node or link radius
  tdhString crsStr; //CRS_sourceStr, CRS_destinStr; // CRS strings for source and destination during a coordinate transformation

  TGisNetwork ();
  virtual ~TGisNetwork ();
  virtual TGisNodeNav *GisNodeNav () {return (TGisNodeNav*)NodeNav();} // node navigator that returns TGisNode belonging to the network
  virtual TGisLinkNav *GisLinkNav () {return (TGisLinkNav*)LinkNav();} // link navigator that returns TGisLink belonging to the network
  virtual TLinkGroupNav *LinkGroupNav() {return linkGroupNav;} // a navigator that returns TLinkGroup0's  belonging to the network
  virtual void Reset(); // deletes all nodes, links and link groups belonging to the network
  virtual TNetLink0 *Create_Link0 ();
  virtual TNetNode0 *Create_Node0 ();
  virtual TGisLink *Create_Link_gis ();
  virtual TGisNode *Create_Node_gis ();
  virtual TLinkGroup0 *Create_LinkGroup (tdhString); // {return new TLinkGroup0 (this);}
  virtual TLinkGroup0 *DefaultLinkGroup () {return linkGroup_net;}
  virtual tdhString get_defaultLayer () {return "default";}
  virtual tdhString get_currLinkGroup () {return "";}

//  virtual bool usUnits ();
  virtual TStringVector *SpeedUnitsStrs () {return &speedUnitsStrs;} // a list of strings corresponding to UnitsSpped
  virtual UnitsSpeed SpeedUnits () {return speedUnits;} //returns network default speed units
  virtual void set_SpeedUnits (UnitsSpeed val) {speedUnits = val;} //sets network default speed units
  virtual UnitsSpeed SpeedUnits_fromStr (tdhString);  //return the UnitsSpeed corresponding to the 1st param
  virtual tdhString SpeedUnits_toStr (UnitsSpeed); //returns a string corresponding to the 1st param

  virtual TStringVector *TimeUnitsStrs () {return &timeUnitsStrs;}
  virtual void set_TimeUnits (UnitsTime val) {timeUnits = val;} //sets the network default time units
  virtual UnitsTime TimeUnits () {return timeUnits;} //returns the network default time units
  virtual UnitsTime TimeUnits_fromStr (tdhString); //return the UnitsTime corresponding to the 1st param
  virtual tdhString TimeUnits_toStr (UnitsTime); //returns a string corresponding to the 1st param

  virtual bool Use_Factors () {return use_factors;} // if true link factors are used
  virtual void set_Use_Factors (bool val) { use_factors = val;}  //sets whether link factors are used
  virtual double Default_Radius () {return default_radius;} //return the value used if the radius for an element is set to 0
  virtual bool TimeFlag () {return timeFlag;}
     // if true and Use_Factor() is true, the link value used in a path analysis is the calculated travel time (value (distance) / speed)
  virtual void set_TimeFlag (bool val) {timeFlag = val;} //
//  virtual tdhString CRS_SourceStr () {return CRS_sourceStr;} // the CRS string for the source when setting the current coordinates
  virtual tdhString CRSstr () {return crsStr;} // the CRS string for destination when setting the current coordinates
  virtual void set_CRSstr (tdhString strParam) {crsStr = strParam;} // set the CRS string for destination when setting the current coordinates
  };

extern TGisNetwork gisNetwork_default;

TGisNetwork EXPORTPROC *Create_GisNetwork ();

void EXPORTPROC Delete_GisNetwork();

//TGisNetwork *Create_GisNetwork ();

#endif // TDHGISNETDATA_H_INCLUDED
