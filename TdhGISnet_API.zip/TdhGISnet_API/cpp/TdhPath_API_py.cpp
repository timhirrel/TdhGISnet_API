// This file is not normally needed by the TdhPath_API_py user
// It is provided in the event there are errors needing correction in the TdhGISnet_API_py library
// This file contains code to bind the TdhGISnet API to python

#include "TdhPath_Intf.h"

EXTERNC {


TNetNode0 *NetNode_py (void *nodeParam) {
  return (TNetNode0*)nodeParam;  }

EXPORTPROC TtdhNetwork0 *TNetNode_Network (void *nodeParam) {
    return NetNode_py(nodeParam)->Network();  }

EXPORTPROC tdhString_py TNetNode_NodeID (void *nodeParam) {
  return NetNode_py(nodeParam)->NodeID().c_str(); }

EXPORTPROC void TNetNode_set_NodeID (void *nodeParam, tdhString_py idParam) {
  NetNode_py(nodeParam)->set_NodeID(idParam); }

EXPORTPROC bool TNetNode_AutoDelete (void *nodeParam){
  return NetNode_py(nodeParam)->AutoDelete(); }

EXPORTPROC void TNetNode_set_AutoDelete (void *nodeParam, bool val){
  NetNode_py(nodeParam)->set_AutoDelete(val); }

EXPORTPROC void TNetNode_set_Temp (void *nodeParam, bool tempParam) {
  NetNode_py(nodeParam)->set_Temp(tempParam); }

EXPORTPROC bool TNetNode_Temp (void *nodeParam) {
  return NetNode_py(nodeParam)->Temp();}

EXPORTPROC TNetLink0 *TNetNode_DownLink (void *nodeParam){
  return NetNode_py(nodeParam)->DownLink(); }

EXPORTPROC TNetNode0 *TNetNode_DownNode (void *nodeParam){
  return NetNode_py(nodeParam)->DownNode(); }

EXPORTPROC TNetConn0 *TNetNode_DownConn (void *nodeParam){
  return NetNode_py(nodeParam)->DownConn(); }

EXPORTPROC double TNetNode_TravVal (void *nodeParam){
  return NetNode_py(nodeParam)->TravVal(); }

EXPORTPROC int TNetNode_LinkCount (void *nodeParam){
  return NetNode_py(nodeParam)->LinkCount(); }

EXPORTPROC TNetLink0 *TNetNode_GetLink (void *nodeParam, TNetLink0 *linkParam) {
  return NetNode_py(nodeParam)->GetLink(linkParam); }

EXPORTPROC void TNetNode_InitForTraverse (void *nodeParam) {
  NetNode_py(nodeParam)->InitForTraverse(); } //called once before any traversal for a given network configuration

EXPORTPROC void TNetNode_ResetForTraverse (void *nodeParam) {
  NetNode_py(nodeParam)->ResetForTraverse();} //called before each network traversal

EXPORTPROC unsigned TNetNode_Segment (void *nodeParam) {
  return NetNode_py(nodeParam)->Segment();} //return the network segment number to which the node belongs

EXPORTPROC void TNetNode_set_Segment (void *nodeParam, unsigned segParam) {
  NetNode_py(nodeParam)->set_Segment(segParam);} //set the network number to which the node belongs

EXPORTPROC TConnNav *TNetNode_ConnNav (void *nodeParam){
  return NetNode_py(nodeParam)->ConnNav(); }

EXPORTPROC void TNetNode_set_DownConn (void *nodeParam, TNetConn0 *connParam){
  NetNode_py(nodeParam)->set_DownConn(connParam); }

EXPORTPROC TNetNode0 *TNetNode_PopQueue (void *nodeParam){
  return NetNode_py(nodeParam)->PopQueue();}

EXPORTPROC TNetNode0 *TNetNode_PushQueue (void *nodeParam) {
  return NetNode_py(nodeParam)->PushQueue(); }

EXPORTPROC double TNetNode_getX (void *nodeParam) {
  return NetNode_py(nodeParam)->Pt().getX();}

EXPORTPROC double TNetNode_getY (void *nodeParam) {
  return NetNode_py(nodeParam)->Pt().getY();}

//EXPORTPROC TPointXY TNetNode0_Pt (void *nodeParam) {
//  return NetNode_py(nodeParam)->Pt();}

EXPORTPROC void TNetNode_set_Pt (void *nodeParam, double xParam, double yParam) {
  TPointXY tempPt(xParam, yParam);
  NetNode_py(nodeParam)->set_Pt(tempPt);}

EXPORTPROC void TNetNode_set_Y (void *nodeParam, double val) {
  NetNode_py(nodeParam)->set_Y(val);}

EXPORTPROC void TNetNode_set_X (void *nodeParam, double val){
  NetNode_py(nodeParam)->set_X(val); }

EXPORTPROC TPointPtr TNetNode_Pt_ptr (void *nodeParam) {
  return NetNode_py(nodeParam)->Pt_ptr(); }

EXPORTPROC double TNetNode_Radius (void *nodeParam) {
  return NetNode_py(nodeParam)->Radius();}

EXPORTPROC void TNetNode_set_Radius (void *nodeParam, double val) {
  NetNode_py(nodeParam)->set_Radius(val);}

EXPORTPROC double TNetNode_Radius_cord (void *nodeParam) {
  return NetNode_py(nodeParam)->Radius_cord();}

EXPORTPROC void TNetNode_set_Radius_cord (void *nodeParam, double val) {
  NetNode_py(nodeParam)->set_Radius_cord(val);}

EXPORTPROC unsigned int TNetNode_Color (void *nodeParam) {
  return NetNode_py(nodeParam)->Color();}

EXPORTPROC void TNetNode_set_Color (void *nodeParam, unsigned val) {
  NetNode_py(nodeParam)->set_Color(val);}

EXPORTPROC TColorFlag_gis TNetNode_ColorFlag (void *nodeParam) {
  return NetNode_py(nodeParam)->ColorFlag();}

EXPORTPROC void TNetNode_set_ColorFlag (void *nodeParam, TColorFlag_gis val) {
  NetNode_py(nodeParam)->set_ColorFlag(val);}

EXPORTPROC char TNetNode_Width (void *nodeParam) {
  return NetNode_py(nodeParam)->Width();}

EXPORTPROC void TNetNode_set_Width (void *nodeParam, char val) {
  NetNode_py(nodeParam)->set_Width(val);}

EXPORTPROC TNetNode0 *Create_NetNode (TtdhNetwork0 *netParam) {
  return new TNetNode0 (netParam); }

EXPORTPROC void Delete_NetNode (void *nodeParam) {
  delete (TNetNode0*)nodeParam; }



TNetLink0 *NetLink_py (void *linkParam) {
  return (TNetLink0*)linkParam;  }

EXPORTPROC TtdhNetwork0 *TNetLink_Network (void *linkParam) {
  return NetLink_py(linkParam)->Network();}

EXPORTPROC tdhString_py TNetLink_LinkID (void *linkParam) {
  return NetLink_py(linkParam)->LinkID().c_str();}

EXPORTPROC void TNetLink_set_LinkID (void *linkParam, tdhString_py idParam) {
  NetLink_py(linkParam)->set_LinkID(idParam);}

EXPORTPROC TNetNode0 *TNetLink_Node1 (void *linkParam) {
  return NetLink_py(linkParam)->Node1();}

EXPORTPROC TNetNode0 *TNetLink_Node2 (void *linkParam) {
  return NetLink_py(linkParam)->Node2();}

EXPORTPROC void TNetLink_set_Node1 (void *linkParam, TNetNode0 *nodeParam) {
  NetLink_py(linkParam)->set_Node1 (nodeParam);}

EXPORTPROC void TNetLink_set_Node2 (void *linkParam, TNetNode0 *nodeParam) {
  NetLink_py(linkParam)->set_Node2(nodeParam);}

EXPORTPROC TNetNode0 *TNetLink_get_Node (void *linkParam, char pos) {
  return NetLink_py (linkParam)->get_Node(pos);}

EXPORTPROC void TNetLink_set_Node (void *linkParam, char pos, TNetNode0 *nodeParam, bool replaceParam =false) {
  NetLink_py(linkParam)->set_Node (pos, nodeParam, replaceParam);}

EXPORTPROC void TNetLink_set_NodeByKey (void *linkParam, char pos, tdhString_py idParam) {
  NetLink_py(linkParam)->set_NodeByKey(pos, idParam);}

EXPORTPROC TNetConn0 *TNetLink_CreateConn (void *linkParam, char dir) {
  return NetLink_py(linkParam)->CreateConn(dir);}

EXPORTPROC TNetLink0::dirFlags TNetLink_Restrict (void *linkParam) {
  return NetLink_py(linkParam)->Restrict();}

EXPORTPROC void TNetLink_set_Restrict (void *linkParam, int restrictParam) {
  NetLink_py(linkParam)->set_Restrict ((TNetLink0::dirFlags)restrictParam);}

EXPORTPROC bool TNetLink_TempClosed (void *linkParam) {
  return NetLink_py(linkParam)->TempClosed();}

EXPORTPROC char TNetLink_Status (void *linkParam, bool dir) {
  return NetLink_py(linkParam)->Status(dir);}

EXPORTPROC double TNetLink_Value (void *linkParam) {
  return NetLink_py(linkParam)->Value();}

EXPORTPROC void TNetLink_set_Value (void *linkParam, double val) {
  NetLink_py(linkParam)->set_Value(val);}

EXPORTPROC void TNetLink_set_Temp (void *linkParam, bool valParam) {
  NetLink_py(linkParam)->set_Temp(valParam);}

EXPORTPROC bool TNetLink_Temp (void *linkParam) {
  return NetLink_py(linkParam)->Temp();}

EXPORTPROC void TNetLink_SplitAttributes (void *linkParam, TNetLink0 *linkParam1, TNetLink0 *linkParam2, double ratioParam) {
  NetLink_py(linkParam)->SplitAttributes(linkParam1, linkParam2, ratioParam);}

EXPORTPROC void TNetLink_unSplitAttributes  (void *linkParam, TNetLink0 *linkParam1) {
  NetLink_py(linkParam)->unSplitAttributes(linkParam1);}

EXPORTPROC TNetLink0 *TNetLink_CopyDataTo (void *linkParam, TNetLink0 *linkParam1) {
  return NetLink_py(linkParam)->CopyDataTo(linkParam1);}

EXPORTPROC void TNetLink_InitForTraverse (void *linkParam) {
  NetLink_py(linkParam)->InitForTraverse();}

EXPORTPROC void TNetLink_ResetForTraverse (void *linkParam) {
  NetLink_py(linkParam)->ResetForTraverse();}

EXPORTPROC double TNetLink_Radius (void *linkParam) {
  return NetLink_py(linkParam)->Radius();}

EXPORTPROC void TNetLink_set_Radius (void *linkParam, double valParam) {
  NetLink_py(linkParam)->set_Radius(valParam);}

EXPORTPROC double TNetLink_Radius_cord (void *linkParam) {
  return NetLink_py(linkParam)->Radius_cord();}

EXPORTPROC void TNetLink_set_Radius_cord (void *linkParam, double valParam) {
  NetLink_py(linkParam)->set_Radius_cord(valParam);}

EXPORTPROC double TNetLink_LabelPt_getX (void *linkParam) {
  return NetLink_py(linkParam)->LabelPt().getX();}

EXPORTPROC double TNetLink_LabelPt_getY (void *linkParam) {
  return NetLink_py(linkParam)->LabelPt().getY();}

EXPORTPROC TPointPtr TNetLink_LabelPt_ptr (void *linkParam) {
  return NetLink_py(linkParam)->LabelPt_ptr();}

//EXPORTPROC void TNetLink_set_LabelPt (void *linkParam, TPtParam ptParam) {
//  NetLink_py(linkParam)->set_LabelPt(ptParam);}

EXPORTPROC unsigned TNetLink_Color (void *linkParam) {
  return NetLink_py(linkParam)->Color();}

EXPORTPROC void TNetLink_set_Color (void *linkParam, unsigned colorParam) {
  NetLink_py(linkParam)->set_Color(colorParam);}

EXPORTPROC TColorFlag_gis TNetLink_ColorFlag (void *linkParam) {
  return NetLink_py(linkParam)->ColorFlag();}

EXPORTPROC void TNetLink_set_ColorFlag (void *linkParam, int flagParam) {
  NetLink_py(linkParam)->set_ColorFlag((TColorFlag_gis)flagParam);}

EXPORTPROC char TNetLink_Width (void *linkParam) {
  return NetLink_py(linkParam)->Width();}

EXPORTPROC void TNetLink_set_Width (void *linkParam, char valParam) {
  NetLink_py(linkParam)->set_Width(valParam);}

EXPORTPROC TMultiLine0 *TNetLink_MultiLine (void *linkParam) {
  return NetLink_py(linkParam)->MultiLine();}

EXPORTPROC double TNetLink_CalcLength (void *linkParam) {
  return NetLink_py(linkParam)->CalcLength();}

EXPORTPROC TCadRect0 *TNetLink_GetExtents (void *linkParam) {
  return NetLink_py(linkParam)->GetExtents();}

EXPORTPROC void TNetLink_NearestPt (void *linkParam, void *inPt, void *outPt) {
  TPointXY tempPt(*(TPointPtr)inPt), result;
  result = NetLink_py(linkParam)->NearestPt(tempPt);
  result.CopyXY((TPointPtr)outPt);
  }

EXPORTPROC TMultiLine0 *TNetLink_ToMultiLine (void *linkParam) {
  return NetLink_py(linkParam)->ToMultiLine();}

EXPORTPROC void TNetLink_FromMultiLine (void *linkParam, TMultiLine0 *lineParam, bool includeNodes =true) {
  NetLink_py(linkParam)->FromMultiLine(lineParam, includeNodes);}

EXPORTPROC bool TNetLink_SplitMultiline (void *linkParam, TNetLink0 *linkParam1, TNetLink0 *linkParam2, double ratioParam) {
  return NetLink_py(linkParam)->SplitMultiline(linkParam1, linkParam2, ratioParam);}

EXPORTPROC void TNetLink_GetNodeCords (void *linkParam, int pos, void *ptParam) {
  TPointXY result = NetLink_py(linkParam)->GetNodeCords(pos);
  result.CopyXY((TPointPtr)ptParam);
  }

EXPORTPROC double TNetLink_GetNodeRadius (void *linkParam, int pos) {
  return NetLink_py(linkParam)->GetNodeRadius(pos);}

EXPORTPROC TNetLink0 *Create_NetLink (TtdhNetwork0 *netParam) {
  return new TNetLink0 (netParam); }

EXPORTPROC void Delete_NetLink (void *linkParam) {
  delete (TNetLink0*)linkParam; }



TNetConn0 *NetConn_py (void *connParam) {
  return (TNetConn0*)connParam;  }

EXPORTPROC TNetLink0 *TNetConn0_Link (void *connParam) {
  return NetConn_py(connParam)->Link();}

EXPORTPROC tdhString_py TNetConn0_LinkID (void *connParam) {
  return NetConn_py(connParam)->LinkID().c_str();}

EXPORTPROC void TNetConn0_set_ConnNode (void *connParam, TNetNode0 *nodeParam, TNetConn0 *connParam1 = NULL) {
  NetConn_py(connParam)->set_ConnNode(nodeParam, connParam1);}

EXPORTPROC TNetNode0* TNetConn0_ConnNode (void *connParam) {
  return NetConn_py(connParam)->ConnNode();}

EXPORTPROC TNetConn0 *TNetConn0_OppConn (void *connParam) {
  return NetConn_py(connParam)->OppConn();}

EXPORTPROC TNetConn0 *TNetConn0_DownConn (void *connParam) {
  return NetConn_py(connParam)->DownConn();}

EXPORTPROC char TNetConn0_Dir (void *connParam) {
  return NetConn_py(connParam)->Dir();}

EXPORTPROC TNetConn0 *TNetConn0_NextConn (void *connParam) {
  return NetConn_py(connParam)->NextConn();}


TtdhNetwork0 *Network_py (void *netParam) {
  return (TtdhNetwork0*)netParam;  }

EXPORTPROC TNetTraverse *TNetwork_Traverse (void *netParam) {
  return Network_py(netParam)->Traverse();}

EXPORTPROC bool TNetwork_NoDraw (void *netParam) {
  return Network_py(netParam)->NoDraw();}

EXPORTPROC void TNetwork_set_NoDraw (void *netParam, bool val) {
  Network_py(netParam)->set_NoDraw(val);}

EXPORTPROC TNetNode0 *TNetwork_Create_Node0 (void *netParam) {
  return Network_py(netParam)->Create_Node0();}

EXPORTPROC TNetLink0 *TNetwork_Create_Link0 (void *netParam) {
  return Network_py(netParam)->Create_Link0();}

EXPORTPROC TNodeNav *TNetwork_NodeNav (void *netParam) {
  return Network_py(netParam)->NodeNav();}

EXPORTPROC TLinkNav *TNetwork_LinkNav (void *netParam) {
  return Network_py(netParam)->LinkNav();}

EXPORTPROC void TNetwork_set_NodeNav (void *netParam, TNodeNav *navParam) {
  Network_py(netParam)->set_NodeNav(navParam);}

EXPORTPROC void TNetwork_set_LinkNav (void *netParam, TLinkNav *navParam) {
  Network_py(netParam)->set_LinkNav(navParam);}

EXPORTPROC TNodeNav *TNetwork_Create_NodeNav (void *netParam, bool listFlag) {
  return Network_py(netParam)->Create_NodeNav(listFlag);}

EXPORTPROC TLinkNav *TNetwork_Create_LinkNav (void *netParam, bool listFlag)  {
  return Network_py(netParam)->Create_LinkNav(listFlag);}

EXPORTPROC void TNetwork_DeleteConns (void *netParam) {
  Network_py(netParam)->DeleteConns();}

EXPORTPROC tdhString_py TNetwork_NetID (void *netParam) {
  return Network_py(netParam)->NetID().c_str();}

EXPORTPROC void TNetwork_set_NetID (void *netParam, tdhString_py idParam) {
  Network_py(netParam)->set_NetID(idParam);}

EXPORTPROC TNetNode0 *TNetwork_AddNode (void *netParam, tdhString_py idParam, bool replaceFlag) {
  return Network_py(netParam)->AddNode (idParam, replaceFlag);}

EXPORTPROC TNetLink0 *TNetwork_AddLink (void *netParam, tdhString_py idParam, bool replaceFla) {
  return Network_py(netParam)->AddLink (idParam, replaceFla);}

EXPORTPROC TNetNode0 *TNetwork_GetNode (void *netParam, tdhString_py idParam, bool createFlag) {
  return Network_py(netParam)->GetNode (idParam, createFlag);}

EXPORTPROC bool TNetwork_DeleteNode (void *netParam, TNetNode0 *nodeParam) {
  return Network_py(netParam)->DeleteNode (nodeParam);}

EXPORTPROC TNetNode0 *TNetwork_SplitLink (void *netParam, TNetLink0 *linkParam, double ratioVal, tdhString_py nodeid, void *linkid1, void *linkid2) {
//  tdhString linkStr1 = linkid1;
//  tdhString linkStr2 = linkid2;
  TNetNode0 *result = Network_py(netParam)->SplitLink (linkParam, ratioVal, nodeid, ((TString_Intf*)linkid1)->StrPtr(), ((TString_Intf*)linkid2)->StrPtr());
//  linkid1 = linkStr1.c_str();
//  linkid2 = linkStr2.c_str();
  return result;
  }

EXPORTPROC TNetLink0 *TNetwork_FindConnectedLink (void *netParam, tdhString_py nodeid, tdhString_py linkid) {
  return Network_py(netParam)->FindConnectedLink (nodeid, linkid);}

EXPORTPROC void TNetwork_Reset (void *netParam) {
  Network_py(netParam)->Reset();}

EXPORTPROC tdhString_py TNetwork_Description (void *netParam) {
  return Network_py(netParam)->Description().c_str();}

EXPORTPROC void TNetwork_set_Description (void *netParam, tdhString_py strParam) {
  Network_py(netParam)->set_Description (strParam);}

EXPORTPROC int TNetwork_get_defaultColor (void *netParam) {
  return Network_py(netParam)->get_defaultColor();}

EXPORTPROC TNetNode0 *TNetwork_PopQueueHead (void *netParam) {
  return Network_py(netParam)->PopQueueHead();}

TtdhNetwork0 EXPORTPROC *Create_TdhNetwork_py () {
  return new TtdhNetwork0; }

void EXPORTPROC Delete_TdhNetwork_py (TtdhNetwork0 *netParam) {
  delete netParam;
  }


TtargetNode0 *TargetNode_py (void *targetParam) {
  return (TtargetNode0*)targetParam;  }

EXPORTPROC tdhString_py TargetNode_NodeID (void *targetParam) {
  return TargetNode_py(targetParam)->NodeID().c_str();}

EXPORTPROC void TargetNode_set_NodeID (void *targetParam, tdhString_py idParam) {
  TargetNode_py(targetParam)->set_NodeID(idParam);}

EXPORTPROC TtargetNode_wrap *TargetNode_GetKey (void *targetParam) {
  return TargetNode_py(targetParam)->GetKey();}

EXPORTPROC bool TargetNode_StartFlag (void *targetParam) {
  return TargetNode_py(targetParam)->StartFlag();}

EXPORTPROC void TargetNode_set_StartFlag (void *targetParam, bool val) {
  TargetNode_py(targetParam)->set_StartFlag(val);}

EXPORTPROC bool TargetNode_EndFlag (void *targetParam) {
  return TargetNode_py(targetParam)->EndFlag();}

EXPORTPROC void TargetNode_set_EndFlag (void *targetParam, bool val) {
  TargetNode_py(targetParam)->set_EndFlag(val);}

EXPORTPROC bool TargetNode_IntermediateFlag (void *targetParam) {
  return TargetNode_py(targetParam)->IntermediateFlag();}

EXPORTPROC void TargetNode_set_IntermediateFlag (void *targetParam, bool val) {
  TargetNode_py(targetParam)->set_IntermediateFlag(val);}

TtargetNode0 EXPORTPROC *Create_TargetNode_py (tdhString_py idParam) {
  return Create_TargetNode(idParam);
  }

void EXPORTPROC Delete_TargetNode_py (TtargetNode0 *targetParam) {
  delete targetParam;
  }

TTargetNodeNav EXPORTPROC *Create_TargetNodeNav_py () {
  return Create_TargetNodeNav();
  }

void EXPORTPROC Delete_TargetNodeNav_py (TTargetNodeNav *navParam) {
  delete navParam;
  }



TPathData0 *PathData_py (void *dataParam) {
  return (TPathData0*)dataParam;  }

EXPORTPROC TPathData_wrap *PathData_GetKey (void *dataParam) {
  return PathData_py(dataParam)->GetKey();}

EXPORTPROC TNetNode0 *PathData_Node (void *dataParam) {
  return PathData_py(dataParam)->Node();}

EXPORTPROC TNetLink0 *PathData_Link (void *dataParam) {
  return PathData_py(dataParam)->Link();}

EXPORTPROC int PathData_DataType (void *dataParam) {
  return (int)PathData_py(dataParam)->DataType();}

EXPORTPROC int PathData_Dir (void *dataParam) {
  return PathData_py(dataParam)->Dir();}



TPath0 *Path_py (void *pathParam) {
  return (TPath0*)pathParam;  }

EXPORTPROC TPathDataNav *Path_PathData (void *pathParam) {
  return Path_py(pathParam)->PathData();}

EXPORTPROC double Path_Distance (void *pathParam) {
  return Path_py(pathParam)->Distance();}

EXPORTPROC tdhString_py Path_NetID (void *pathParam) {
  return Path_py(pathParam)->NetID().c_str();}

//EXPORTPROC TPath0 *Create_Path_py () {
//  return Create_Path();}

EXPORTPROC void Delete_Path_py (void *pathParam) {
  delete (TPath0*)pathParam;
  }


TTdhPath_Intf0 *PathIntf_py (void *intfParam) {
  return (TTdhPath_Intf0*)intfParam;  }

EXPORTPROC tdhString_py PathIntf_NoneStr(void *intfParam) {
  return PathIntf_py(intfParam)->NoneStr();}

EXPORTPROC tdhString_py PathIntf_NearStr(void *intfParam) {
  return PathIntf_py(intfParam)->NearStr();}

EXPORTPROC tdhString_py PathIntf_NotFoundStr(void *intfParam) {
  return PathIntf_py(intfParam)->NotFoundStr().c_str();}

EXPORTPROC TtdhNetwork0 *PathIntf_Network0 (void *intfParam) {
  return PathIntf_py(intfParam)->Network0();}

EXPORTPROC TPath0 *PathIntf_CalculatedPath (void *intfParam) {
  return PathIntf_py(intfParam)->CalculatedPath();}

EXPORTPROC bool PathIntf_FindMinPath (void *intfParam, tdhString_py startID, tdhString_py endID, TTargetNodeNav *targets, int method) {
  return PathIntf_py(intfParam)->FindMinPath(startID, endID, targets, (TTdhPath_Intf0::TPathMethod)method);}

EXPORTPROC tdhString_py PathIntf_ReportCSV (void *intfParam) {
  return TdhString_toPy(PathIntf_py(intfParam)->ReportCSV());
  }

EXPORTPROC TNetNode0 *PathIntf_MaxTravel (void *intfParam, tdhString_py startID, double maxVal) {
  return PathIntf_py(intfParam)->MaxTravel(startID, maxVal);}

EXPORTPROC tdhString_py PathIntf_ReportTravTimes (void *intfParam) {
  return TdhString_toPy(PathIntf_py(intfParam)->ReportTravTimes());}

EXPORTPROC TTempNodeFuncs0 *PathIntf_TempNodeFuncs (void *intfParam) {
  return PathIntf_py(intfParam)->TempNodeFuncs();}

EXPORTPROC void PathIntf_RemoveTempNodes (void *tempParam) {
  PathIntf_py(tempParam)->RemoveTempNodes();}



TTempNodeFuncs0 *TempNodes_py (void *tempParam) {
  return (TTempNodeFuncs0*)tempParam;  }

EXPORTPROC tdhString_py TempNodes_TempFlagStr (void *tempParam) {
  return TempNodes_py(tempParam)->TempFlagStr();}

EXPORTPROC tdhString_py TempNodes_TempDelim (void *tempParam) {
  return TempNodes_py(tempParam)->TempDelim();}

EXPORTPROC TtdhNetwork0 *TempNodes_Network (void *tempParam) {
  return TempNodes_py(tempParam)->Network();}

//EXPORTPROC bool TempNodes_RemoveTempNodes (void *tempParam) {
//  return TempNodes_py(tempParam)->RemoveTempNodes();}

EXPORTPROC TNetNode0 *TempNodes_AddNode (void *tempParam, TNetLink0 *linkParam, double ratioVal, tdhString_py nodeID, void *linkID1, void *linkID2)  {
  std::string *linkStr1 = NULL, *linkStr2 = NULL;
  if (linkID1)
    linkStr1 = ((TString_Intf*)linkID1)->StrPtr();
  if (linkID2)
    linkStr2 = ((TString_Intf*)linkID2)->StrPtr();
  return TempNodes_py(tempParam)->AddNode (linkParam, ratioVal, nodeID, linkStr1, linkStr2);}

EXPORTPROC TNetNode0 *TempNodes_AddNodeAtPt (void *tempParam, void *ptPtr, tdhString_py nodeID) {
  TPointXY tempPt ((TPointPtr)ptPtr);
  return TempNodes_py(tempParam)->AddNodeAtPt (tempPt, nodeID);
  }

EXPORTPROC bool TempNodes_AddOneTempNode (void *tempParam, void *strParam) {
  tdhString *tempStr = NULL;
  if (strParam)
    ((TString_Intf*)strParam)->StrPtr();
  bool result = TempNodes_py(tempParam)->AddOneTempNode(tempStr);
//  *strParam = tempStr.c_str();
  return result;
  }

EXPORTPROC bool TempNodes_AddTempNodes (void *tempParam, tdhString_py startParam, tdhString_py endParam, TTargetNodeNav *nodesStr) {
  tdhString startStr  = startParam, endStr = endParam;
  bool result = TempNodes_py(tempParam)->AddTempNodes (&startStr, &endStr, nodesStr);
  startParam = startStr.c_str();
  endParam = endStr.c_str();
  return result;
  }

EXPORTPROC TNetNode0* TempNodes_FindCordNode (void *tempParam, void *ptPtr) {
  TPointXY tempPt ((TPointPtr)ptPtr);
  return TempNodes_py(tempParam)->FindCordNode(tempPt);
  }

EXPORTPROC TNetLink0* TempNodes_FindCordLink (void *tempParam, void *ptPtr) {
  TPointXY tempPt ((TPointPtr)ptPtr);
  return TempNodes_py(tempParam)->FindCordLink(tempPt);

  }

TTempNodeFuncs0 EXPORTPROC *Create_TempNodeFuncs_py (void *netParam) {
  return Create_TempNodeFuncs ((TtdhNetwork0*)netParam);
  }

void EXPORTPROC Delete_TempNodeFuncs_py (void *funcsParam) {
  delete (TTempNodeFuncs0*)funcsParam;
  }

//EXPORTPROC bool TempNodes_RemoveTempNodes (void *tempParam) {
//  return TempNodes_py(tempParam)->RemoveTempNodes();}

EXPORTPROC TTdhPath_Intf0 *Create_TdhPath_Intf_py (void *netParam) {
  return Create_TdhPath_Intf((TtdhNetwork0*)netParam);
  }

EXPORTPROC void Delete_TdhPath_Intf_py (void *intfParam)  {
  delete (TTdhPath_Intf0*)intfParam;
  }

}

