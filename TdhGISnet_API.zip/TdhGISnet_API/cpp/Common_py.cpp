#include "StringDef.hpp"

EXTERNC{

TString_Intf * String_Intf(void* intfParam) {
  return (TString_Intf*)intfParam;
  }

EXPORTPROC tdhString_py String_Intf_getStr(void* intfParam) {
  return String_Intf(intfParam)->get_Str();
 }

EXPORTPROC void String_Intf_setStr(void* intfParam, tdhString_py strParam) {
  String_Intf(intfParam)->set_Str(strParam);
 }

EXPORTPROC TString_Intf * Create_StringIntf_py() {
  return new TString_Intf;
}

EXPORTPROC void Delete_StringIntf_py(void* intfParam) {
  delete (TString_Intf*)intfParam;
  }


TStringVector_Intf * StringVector_Intf(void* intfParam) {
  return (TStringVector_Intf*)intfParam;
  }

EXPORTPROC void StringVector_Intf_PushStr(void* intfParam, tdhString_py strParam) {
  StringVector_Intf(intfParam)->PushStr(strParam);
 }

EXPORTPROC tdhString_py StringVector_Intf_getStr(void* intfParam, int pos) {
  return StringVector_Intf(intfParam)->get_Str(pos);
 }

EXPORTPROC int StringVector_Intf_Count(void* intfParam) {
  return StringVector_Intf(intfParam)->Count();
 }

EXPORTPROC void StringVector_Intf_Clear(void* intfParam) {
  StringVector_Intf(intfParam)->Clear();
 }

EXPORTPROC TStringVector_Intf * Create_StringVectorIntf_py() {
  return new TStringVector_Intf;
}

EXPORTPROC void Delete_StringVectorIntf_py(void* intfParam) {
  delete (TStringVector_Intf*)intfParam;
  }

}
