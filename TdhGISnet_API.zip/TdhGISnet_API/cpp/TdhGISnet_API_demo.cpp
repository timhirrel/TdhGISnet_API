/*
This file demonstrates some functionality of the TdhGISnet API
The analysis functionality is provided within the TdhPath_API library
The input/output functionality is provided within the TdhGISnet_API library
The TdhGISnet_API library uses the Sqlite library
To visualize the data and results, please use the TdhGISnet app, selecting the supplied database with the File | Projects menu option
*/

#include <iostream>

#include "TdhPath_Intf.h"

using namespace std;


class TGisNetwork;
class TTdhGISnetIO0;

class TTdhGISnet_api_demo {
// demonstrates some functionality of the TdhGISnet API
protected:
  TGisNetwork *network;
  TTdhGISnetIO0 *gisNetAPI;
  TTdhPath_Intf0 *pathIntf;
  TTargetNodeNav *targetNav;
  TTempNodeFuncs0 *tempNodeFuncs;
  virtual TGisNetwork *Network () {return network;}
  virtual TTdhGISnetIO0 *GisNetAPI () {return gisNetAPI;}
  virtual TTdhPath_Intf0 *PathIntf () {return pathIntf;}
  virtual TTargetNodeNav *TargetNav () {return targetNav;}
  virtual TTempNodeFuncs0 *TempNodeFuncs () {return tempNodeFuncs;}
public:
  TTdhGISnet_api_demo ();
  virtual bool Set_DB (tdhString);
  virtual bool Main ();
  virtual bool ReadNetwork (tdhString);
  virtual bool FindMinPath1 ();
  virtual bool FindMinPath2 ();
  virtual void ReportPath1 ();
  virtual void ReportPath2 ();
  virtual void ImportOSM(tdhString);
};


#include "TdhGISnet_API.h"
#include "uiUtils_generic.h"

TTdhGISnet_api_demo::TTdhGISnet_api_demo() {
//create the classes used within the demo
  network = Create_GisNetwork ();
  gisNetAPI = Create_TdhGISnetIO (Messenger_Utils());
  pathIntf = Create_TdhPath_Intf (network, Messenger_Utils());
  targetNav = Create_TargetNodeNav ();
  tempNodeFuncs = Create_TempNodeFuncs(Network());
  }

bool TTdhGISnet_api_demo::Main () {
  if (!ReadNetwork("test1"))
    return false;
  if (FindMinPath1())
    ReportPath1();
  if (FindMinPath2())
    ReportPath2();
  return true;
  }

bool TTdhGISnet_api_demo::Set_DB (tdhString dbPath) {
// set the database file
  return GisNetAPI()->SetDB (dbPath);
  }

bool TTdhGISnet_api_demo::ReadNetwork (tdhString netid) {
// read network data from the database into the API data structures
  bool result = GisNetAPI()->ReadNetwork (netid, Network(), true);
  return result;
  }

bool TTdhGISnet_api_demo::FindMinPath1 () {
// a simple use of the path analysis function
// find the minimum path from node 3 to node 4 with no intermediate nodes specified
  return PathIntf()->FindMinPath("3", "4", TargetNav(), TTdhPath_Intf0::pmMinimum);
  }

bool TTdhGISnet_api_demo::FindMinPath2 () {
// a more complex use of the path analysis functionality
// specify 3 target nodes, with one of those specified as not an intermediate node (i.e. it must be either the starting node or the ending node)
// create a temporary node within link 6 and add it to the target nodes
// runs the path analysis without specifying a start or end node (i.e. any target node can be either the start or end node)

  TtargetNode0 *target5 = Create_TargetNode("5");
  TargetNav()->Push(target5);
  target5->set_IntermediateFlag(false);
  TtargetNode0 *target3 = Create_TargetNode("3");
  TargetNav()->Push(target3);
  TtargetNode0 *target4 = Create_TargetNode("4");
  TargetNav()->Push(target4);

  PathIntf()->RemoveTempNodes();
  TNetLink0 *exLink = Network()->LinkNav()->GetRec("6");
  tdhString linkStr1, linkStr2;
  TNetNode0 *tempNode = TempNodeFuncs()->AddNode(exLink, 0.60, "", &linkStr1, &linkStr2);
  std::cout << tempNode->NodeID() + " " + linkStr1 + " " + linkStr2 << std::endl;
  TtargetNode0 *targetTemp = Create_TargetNode(tempNode->NodeID());
  TargetNav()->Push (targetTemp);

  std::cout << TargetNav()->get_Count() << std::endl;
  return PathIntf()->FindMinPath(PathIntf()->NoneStr(), PathIntf()->NoneStr(), TargetNav(), TTdhPath_Intf0::pmMinimum);
  }

void TTdhGISnet_api_demo::ReportPath1 () {
// uses an API function to output the calculated path
  std::cout << PathIntf()->ReportCSV();
  }

void TTdhGISnet_api_demo::ReportPath2 () {
// demonstrates how to use API functionality to access the calculated path
  TPath0 *currPath = PathIntf()->CalculatedPath();
  TPathData0 *currElement;
  tdhString typeStr;
  std::cout << "Total Distance: " + stringify(currPath->Distance()) << std::endl;
  bool goFlag = currPath->PathData()->GotoFirst();
  while (goFlag) {
    currElement = currPath->PathData()->GetData();
    switch (currElement->DataType()) {
      case 0:
        typeStr = "Node " + currElement->Node()->NodeID();
        break;
      case 1:
        typeStr = "Link " + currElement->Link()->LinkID() + " " + stringify(currElement->Link()->Value());
        break;
      }
    std::cout <<  (typeStr) << std::endl;
    goFlag = currPath->PathData()->GotoNext();
    }
  }

void TTdhGISnet_api_demo::ImportOSM (tdhString fileStr)  {
// demonstrates importing data from an OSM data file
  TStringVector requiredTags, excludeTags;
  tdhString netid = "CarsonCity_OSM";
  GisNetAPI()->DeleteNetwork (netid);
  Network()->Reset(); //remove all elements from network
  requiredTags.push_back("highway, *"); //include all ways with highway tag
  excludeTags.push_back("highway, footpath"); //exclude way with highway tag and footpath value
  GisNetAPI()->ImportOSM(fileStr, Network(), &requiredTags, &excludeTags);
  Network()->set_NetID(netid);
  std::cout << "Carson City from OSM"  << std::endl;
  std::cout << "Nodes: " + stringify(Network()->NodeNav()->get_Count())  << std::endl;
  std::cout << "Links: " + stringify(Network()->LinkNav()->get_Count())  << std::endl;
  GisNetAPI()->WriteNetwork(Network());
  }

int main() {
  TTdhGISnet_api_demo *gisNetAPI_demo = new TTdhGISnet_api_demo;
//  tdhString dataDir = "/media/tim/ntfs/API_Bindings/TdhGISnet_API_demo_Data/"; //set this to the location of the TdhGISnet_API_demo Data directory
  tdhString dataDir = "e:/API_Bindings/TdhGISnet_API_demo_Data/"; //set this to the location of the TdhGISnet_API_demo Data directory
  if (!gisNetAPI_demo->Set_DB(dataDir + "TdhGISnet_Data.sqlite"))
    return false;
  gisNetAPI_demo->Main();
  gisNetAPI_demo->ImportOSM (dataDir+"CarsonCity_NV.osm");
  std::cout << "hit any key to exit...";
  std::cin.get();
  return 0;
  }

