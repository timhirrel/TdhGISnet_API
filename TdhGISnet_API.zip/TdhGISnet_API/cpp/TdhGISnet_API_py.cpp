// This file is not normally needed by the TdhGISnet_API_py user
// It is provided in the event there are errors needing correction in the TdhGISnet_API_py library
// This file contains code to bind the TdhGISnet API to python

#include "TdhGISnet_API.h"

EXTERNC {

TTdhGISnetIO0 *GISnetAPI_py (void *ptrParam) {
  return (TTdhGISnetIO0*)ptrParam;  }

EXPORTPROC bool TdhGISnetIO_SetDB (void *ptrParam, tdhString_py strParam) {
  return GISnetAPI_py(ptrParam)->SetDB (strParam);
  }

EXPORTPROC bool TdhGISnetIO_ReadNetwork (void *ptrParam, tdhString_py netID, TGisNetwork *netParam, bool reset= true) {
  return GISnetAPI_py(ptrParam)->ReadNetwork (netID, netParam, reset);
  }

EXPORTPROC bool TdhGISnetIO_WriteNetwork (void *ptrParam, TGisNetwork *netParam) {
  return GISnetAPI_py(ptrParam)->WriteNetwork (netParam);
  }

EXPORTPROC void TdhGISnetIO_DeleteNetwork (void *ptrParam, tdhString_py netID) {
  GISnetAPI_py(ptrParam)->DeleteNetwork (netID);
  }

EXPORTPROC bool TdhGISnetIO_ImportOSM (void *ptrParam, tdhString_py fileStr, TGisNetwork *netParam, TStringVector_Intf *tagsReqParam, TStringVector_Intf *tagsExclParam) {
  return GISnetAPI_py(ptrParam)->ImportOSM (fileStr, netParam, tagsReqParam->StrPtr(), tagsExclParam->StrPtr());
  }

EXPORTPROC TTdhGISnetIO0 *Create_TdhGISnetIO_py() {
  return Create_TdhGISnetIO();
  }

EXPORTPROC void Delete_TdhGISnetIO_py (void *apiParam) {
  delete (TTdhGISnetIO0*)apiParam;
  }


EXPORTPROC TGisNetwork *Create_GisNetwork_py () {
  return Create_GisNetwork();
  }

EXPORTPROC void Delete_GisNetwork_py (void *netParam) {
  delete (TGisNetwork*)netParam;
  }

}
