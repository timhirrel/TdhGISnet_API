
// This file is not normally needed by the TdhGIS_API user
// It is provided in the event there are errors needing correction in the TdhCommon_py library
// This file contains code to bind the TdhGIS API to python

#include "RecordsNav0.h"
#include "TdhObjs.h"


typedef TtdhStdStrKey objType;
//typedef tdhString_py keyType_py;
typedef const char* keyType_py;
typedef tdhString keyType_c;
typedef TRecordsNav0 <objType, keyType_c> TRecordsNav_str;

TRecordsNav_str *RecordsNav_str (void *navParam) {
  return (TRecordsNav_str*)navParam; }

objType *RecordsNav_obj (void *objParam) {
  return (objType*)objParam; }

//TRecordsNav_str *Create_RecordsNav_str_py () {
//  return new TRecordsNav_str; }

int recCount = 0;

EXTERNC {

EXPORTPROC bool RecordsNav_pyStr_AddRec (void *navParam, void *objParam, keyType_py keyParam, bool replaceFlag) {
  return RecordsNav_str(navParam)->AddRec(RecordsNav_obj(objParam), keyParam, replaceFlag);
  }

EXPORTPROC bool RecordsNav_pyStr_DeleteAll (void *navParam) {
//deletes all object (instances) in the navigator
  return RecordsNav_str(navParam)->DeleteAll();
  }

EXPORTPROC bool RecordsNav_pyStr_DeleteOne (void *navParam, keyType_py keyParam, bool keepParam=false) {
//find object with key = 1st param and remove from list, delete object if 2nd param = false
  return RecordsNav_str(navParam)->DeleteOne(keyParam, keepParam);
  }

EXPORTPROC bool RecordsNav_pyStr_DeleteCount(void *navParam,  unsigned pos, unsigned delcount) {
// deletes the number of objects (2nd parameter) starting at the position of 1st parameter
  return RecordsNav_str(navParam)->DeleteCount(pos, delcount);
  }

EXPORTPROC objType *RecordsNav_pyStr_GetFirst (void *navParam) {
//returns the first object (or NULl) in the navigator
  return RecordsNav_str(navParam)->GetFirst();
  }

EXPORTPROC objType *RecordsNav_pyStr_GetNext (void *navParam, void *objParam) {
//returns the object (or NULL) following the 1st param
  return RecordsNav_str(navParam)->GetNext(RecordsNav_obj(objParam));
  }

EXPORTPROC objType *RecordsNav_pyStr_GetLast (void *navParam) {
//returns the last object (or NULl) in the navigator
  return RecordsNav_str(navParam)->GetLast();
  }

EXPORTPROC objType *RecordsNav_pyStr_GetPrev (void *navParam, void *objParam) {
//returns the object (or NULL) preceding the 1st param
  return RecordsNav_str(navParam)->GetNext(RecordsNav_obj(objParam));
  }

EXPORTPROC objType *RecordsNav_pyStr_GetRec (void *navParam, keyType_py keyParam) {
  return RecordsNav_str(navParam)->GetRec(keyParam);
  }

EXPORTPROC objType *RecordsNav_pyStr_GetItem (void *navParam, unsigned pos) {
//return object pointer in position = 1st param
  return RecordsNav_str(navParam)->GetItem(pos);
  }

EXPORTPROC unsigned RecordsNav_pyStr_get_Count (void *navParam) {
//returns the number of objects in the navigator
  return RecordsNav_str(navParam)->get_Count();
  }

EXPORTPROC objType *RecordsNav_pyStr_DefaultRec (void *navParam) {
//returns a default object
  return RecordsNav_str(navParam)->DefaultRec();
  }

EXPORTPROC void RecordsNav_pyStr_set_DefaultRec (void *navParam, void *objParam ) {
//sets the object for the navigator
  RecordsNav_str(navParam)->set_DefaultRec(RecordsNav_obj(objParam));
  }


typedef TRecordsNav0 <TtdhQueObj, TtdhNoKey> TRecordsNav_queue;

TRecordsNav_queue *RecordsNav_queue (void *queueParam) {
  return (TRecordsNav_queue*)queueParam;
  }

TtdhQueObj *QueueObj (void *objParam) {
  return (TtdhQueObj*)objParam;
  }

EXPORTPROC bool RecordsNav_queue_Push (void *queueParam,  void *objParam) {
  return RecordsNav_queue(queueParam)->Push(QueueObj(objParam));
  }

EXPORTPROC TtdhQueObj *RecordsNav_queue_Pop (void *queueParam) {
  return RecordsNav_queue(queueParam)->DefaultRec();
  }

EXPORTPROC bool RecordsNav_queue_Insert (void *queueParam, void *objParam, unsigned pos) {
  return RecordsNav_queue(queueParam)->Insert(QueueObj(objParam), pos);
  } //adds the 1st param in the 2nd param position

EXPORTPROC bool RecordsNav_queue_InsertNav (void *queueParam, void *navParam, unsigned pos) {
  return RecordsNav_queue(queueParam)->InsertNav(RecordsNav_queue(navParam), pos);
  }


EXPORTPROC bool RecordsNav_pyStr_DataExists (void *navParam ) {
  return RecordsNav_str(navParam)->DataExists();
  }

EXPORTPROC bool RecordsNav_pyStr_GotoFirst (void *navParam) {
  return RecordsNav_str(navParam)->GotoFirst();
  }
    // if the navigator has at least one object, sets the object pointer to the first object and returns true
    // otherwise, returns false

EXPORTPROC bool RecordsNav_pyStr_GotoLast (void *navParam) {
  return RecordsNav_str(navParam)->GotoLast();
  }
    // if the navigator has at least one object, sets the object pointer to the last object and returns true
    // otherwise, returns false

EXPORTPROC bool RecordsNav_pyStr_GotoNext (void *navParam) {
  return RecordsNav_str(navParam)->GotoNext();
  }
    // if the object pointer is not at the last object, sets the object pointer to the next object and returns true
    // otherwise, returns false

EXPORTPROC bool RecordsNav_pyStr_GotoPrev (void *navParam) {
  return RecordsNav_str(navParam)->GotoPrev();
  }
    // if the object pointer is not at the last object, sets the object pointer to the next object and returns true
    // otherwise, returns false

EXPORTPROC bool RecordsNav_pyStr_GotoRec (void *navParam, keyType_py keyParam) {
  return RecordsNav_str(navParam)->GotoRec(keyParam);
  }
    // if such and object exists, sets the object pointer to the object whose key value matches the 1st parameter and returns true
    // otherwise, returns false and the object pointer is not changed

EXPORTPROC bool RecordsNav_pyStr_GotoNear (void *navParam, keyType_py keyParam) {
  return RecordsNav_str(navParam)->GotoNear(keyParam);
  }
    // sets the object pointer to the object whose key value is closest to but not more than the 1st parameter.
    // returns false only if no objects exist

EXPORTPROC bool RecordsNav_pyStr_AtFirst (void *navParam) {
  return RecordsNav_str(navParam)->AtFirst();
  }

EXPORTPROC bool RecordsNav_pyStr_AtLast (void *navParam) {
  return RecordsNav_str(navParam)->AtLast();
  }

EXPORTPROC unsigned RecordsNav_pyStr_get_RecNum (void *navParam) {
  return RecordsNav_str(navParam)->get_RecNum();
  } // returns the position of the current object

EXPORTPROC keyType_py RecordsNav_pyStr_GetKey (void *navParam) {
  return RecordsNav_str(navParam)->GetKey().c_str();
  }

EXPORTPROC keycomp_result RecordsNav_pyStr_KeyComp (void *navParam, keyType_py strParam) {
  return RecordsNav_str(navParam)->KeyComp(strParam);
  }

EXPORTPROC bool RecordsNav_pyStr_SetKey (void *navParam, keyType_py strParam, bool replaceFlag) {
  return RecordsNav_str(navParam)->SetKey(strParam, replaceFlag);
  }
    // sets the key value of the current object and inserts or moves the object within the container.
    // if there is an existing object with the same key and the 2nd parameter is true, the exiting object is deleted; otherwise the change is rejected
    // returns true if is the key is set

EXPORTPROC objType *RecordsNav_pyStr_SetOrGetKey (void *navParam, keyType_py strParam) {
  return RecordsNav_str(navParam)->SetOrGetKey(strParam);
  }
    // sets the key value of the current object and inserts or moves the object within the container.
    // if there is an existing object with the same key that object becomes the current object
    //return the current object

EXPORTPROC objType *RecordsNav_pyStr_get_UnUsedObj (void *navParam) {
  return RecordsNav_str(navParam)->get_UnUsedObj();
  }

EXPORTPROC objType *RecordsNav_pyStr_GetData (void *navParam) {
  return RecordsNav_str(navParam)->GetData();
  }

EXPORTPROC bool RecordsNav_pyStr_SetData (void *navParam, objType *objParam) {
  return RecordsNav_str(navParam)->SetData (objParam);
  }
    // if the 1st param belongs to the navigator, set the object pointer to 1st param and return true
    // otherwise, return false

EXPORTPROC unsigned RecordsNav_pyStr_GetPosition (void *navParam, objType *objParam) {
  return RecordsNav_str(navParam)->GetPosition(objParam);
  }

EXPORTPROC bool RecordsNav_pyStr_GotoPosition (void *navParam, unsigned pos) {
  return RecordsNav_str(navParam)->GotoPosition(pos);
  }

EXPORTPROC bool RecordsNav_pyStr_NewData_nokey (void *navParam, objType *objParam) {
  return RecordsNav_str(navParam)->NewData_nokey(objParam);
  } // sets current current object to 1st parameter. must be followed by a call to SetKey to add to container

EXPORTPROC keyType_py RecordsNav_pyStr_KeyToStr (void *navParam) {
  return TdhString_toPy(RecordsNav_str(navParam)->KeyToStr());
  } //returns a string representation of the key

EXPORTPROC bool RecordsNav_pyStr_KeyError (void *navParam) {
  return RecordsNav_str(navParam)->KeyError();
  }

EXPORTPROC bool RecordsNav_pyStr_KeyUsed (void *navParam, keyType_py keyParam) {
  return RecordsNav_str(navParam)->KeyUsed(keyParam);
  }

EXPORTPROC keyType_py RecordsNav_pyStr_GetNextAvailableKey (void *navParam, tdhString_py strParam) {
  return TdhString_toPy(RecordsNav_str(navParam)->GetNextAvailableKey(strParam));
  }
    // for use with string keys
    // returns the lowest value unused key with the specified prefix (1st param)

TNavNotify0 *NavNotify_py (void *notifyParam) {
  return (TNavNotify0*)notifyParam;
  }

EXPORTPROC void RecordsNav_pyStr_AddNotify (void *navParam, void *notifyParam) {
  RecordsNav_str(navParam)->AddNotify(NavNotify_py(notifyParam));
  }

EXPORTPROC void RecordsNav_pyStr_RemoveNotify (void *navParam, void *notifyParam) {
  RecordsNav_str(navParam)->RemoveNotify(NavNotify_py(notifyParam));
  }; //deletes a notification from the container

EXPORTPROC void RecordsNav_pyStr_SetIDs (void *navParam) {
  RecordsNav_str(navParam)->SetIDs();
  } //set the id for all objects accessed by the navigator
//  virtual TRecordsNav0 <objType, keyType> *CopyNav (TRecordsNav0 <objType, keyType>* = NULL, bool = true) {return NULL;}

EXPORTPROC void RecordsNav_pyStr_set_Hide (void *navParam, bool hideFlag) {
  RecordsNav_str(navParam)->set_Hide(hideFlag);
  } //controls whether records marked for hiding are hidden in navigators that allow hiding

EXPORTPROC bool RecordsNav_pyStr_Hide (void *navParam) {
  return RecordsNav_str(navParam)->Hide();
  }

}


