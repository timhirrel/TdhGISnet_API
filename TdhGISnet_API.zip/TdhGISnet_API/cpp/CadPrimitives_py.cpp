// This file is not normally needed by the TdhGIS_API user
// It is provided in the event there are errors needing correction in the TdhCommon_py library
// This file contains code to bind the TdhGIS API to python

#include "CadPrimitives.h"
//#include "StringDef.hpp"

EXTERNC {

EXPORTPROC TPointXY0 *PointXY_py (void *ptParam) {
// provide an implementation of TPointXY0 for python bindings
  return (TPointXY0*)ptParam;
  }


EXPORTPROC void PointXY_py_setX (void *ptParam, double xParam) {
  PointXY_py(ptParam)->setX(xParam);
  }

EXPORTPROC void PointXY_py_setY (void *ptParam, double yParam) {
  PointXY_py(ptParam)->setY(yParam);
  }

EXPORTPROC double PointXY_py_getX (void *ptParam) {
  return PointXY_py(ptParam)->getX();
  }

EXPORTPROC double PointXY_py_getY (void *ptParam) {
  return PointXY_py(ptParam)->getY();
  }

EXPORTPROC void PointXY_py_SetXY (void *ptParam, double xParam, double yParam) {
  PointXY_py(ptParam)->SetXY(xParam, yParam);
  }

EXPORTPROC void PointXY_py_CopyPt (void *ptParam, void *ptParam2) {
  PointXY_py(ptParam)->CopyXY(PointXY_py(ptParam2));
  }

EXPORTPROC void PointXY_py_CopyXY (void *ptParam, double xParam, double yParam) {
  TPointXY tempPt (xParam, yParam);
  PointXY_py(ptParam)->CopyXY(tempPt);
  }

EXPORTPROC bool PointXY_py_IsShareable (void *ptParam) {
  return PointXY_py(ptParam)->IsShareable();
  }

EXPORTPROC bool PointXY_py_IsShared (void *ptParam) {
  return PointXY_py(ptParam)->IsShared();
  }

EXPORTPROC bool PointXY_py_okToDelete (void *ptParam) {
  return PointXY_py(ptParam)->okToDelete();
  }

EXPORTPROC unsigned long PointXY_py_ShareCode (void *ptParam) {
  return PointXY_py(ptParam)->ShareCode();
  }

EXPORTPROC TPointPtr Create_PointXY_py (double xParam, double yParam) {
  return new TPointXY (xParam, yParam);
  }

EXPORTPROC void Delete_PointXY_py (void *ptParam) {
  delete (TPointPtr)ptParam;
  }

TCadRect0 *CadRect_py (void *rectParam) {
  return (TCadRect0*)rectParam;
  }

EXPORTPROC TPointPtr CadRect_py_MinPt (void *rectParam) {
  return CadRect_py(rectParam)->MinPt();
  }

EXPORTPROC TPointPtr CadRect_py_MaxPt (void *rectParam) {
  return CadRect_py(rectParam)->MaxPt();
  }

EXPORTPROC void CadRect_py_SetPoints (void *rectParam, double xParam1, double yParam1, double xParam2, double yParam2) {
  TPointXY tempPt1 (xParam1, yParam1), tempPt2 (xParam2, yParam2);
  CadRect_py(rectParam)->SetPoints(tempPt1, tempPt2);
  }

EXPORTPROC double CadRect_py_Height (void *rectParam) {
  return CadRect_py(rectParam)->Height();
  }

EXPORTPROC double CadRect_py_Width (void *rectParam) {
  return CadRect_py(rectParam)->Width();
  }

EXPORTPROC double CadRect_py_MaxX (void *rectParam) {
  return CadRect_py(rectParam)->MaxX();
  }

EXPORTPROC double CadRect_py_MaxY (void *rectParam) {
  return CadRect_py(rectParam)->MaxY();
  }

EXPORTPROC double CadRect_py_MinX (void *rectParam) {
  return CadRect_py(rectParam)->MinX();
  }

EXPORTPROC double CadRect_py_MinY (void *rectParam) {
  return CadRect_py(rectParam)->MinY();
  }

EXPORTPROC bool CadRect_py_Expand (void *rectParam, double xParam, double yParam) {
  TPointXY tempPt(xParam, yParam);
  return CadRect_py(rectParam)->Expand(tempPt);
  }

EXPORTPROC bool CadRect_py_ExtentsValid (void *rectParam) {
  return CadRect_py(rectParam)->ExtentsValid();
  }

EXPORTPROC bool CadRect_py_ContainsPt (void *rectParam, double xParam, double yParam, double tolerance= -1) {
  TPointXY tempPt(xParam, yParam);
  return CadRect_py(rectParam)->ContainsPt(tempPt, tolerance);
  }

EXPORTPROC bool CadRect_py_ContainsRect (void *rectParam, double xParam1, double yParam1, double xParam2, double yParam2, double tolerance= -1) {
  TPointXY tempPt1 (xParam1, yParam1), tempPt2 (xParam2, yParam2);
  TCadRect tempRect (tempPt1, tempPt2);
  return CadRect_py(rectParam)->ContainsRect(&tempRect, tolerance);
  }

EXPORTPROC bool CadRect_py_InfinExtents (void *rectParam) {
  return CadRect_py(rectParam)->InfinExtents();
  }

EXPORTPROC void CadRect_py_MidPoint (void *rectParam, void *ptParam) {
  return CadRect_py(rectParam)->MidPoint(PointXY_py(ptParam));
  }

EXPORTPROC double CadRect_py_CalcArea (void *rectParam) {
  return CadRect_py(rectParam)->CalcArea();
  }

EXPORTPROC double CadRect_py_NearestDist (void *rectParam, double xParam, double yParam){
  TPointXY tempPt(xParam, yParam);
  return CadRect_py(rectParam)->NearestDist(tempPt);
  }

TCadRect0 EXPORTPROC *Create_CadRect_py () {
  return new TCadRect;
  }

void EXPORTPROC Delete_CadRect_py (void *rectParam) {
  delete (TCadRect*)rectParam;
  }

TVertex0 *Vertex_py (void *vertexParam) {
  return (TVertex0*)vertexParam;
  }


EXPORTPROC TVertex_tdh *Vertex_py_GetKey (void *vertexParam) {
  return Vertex_py(vertexParam)->GetKey();
  }

EXPORTPROC double Vertex_py_getX (void *vertexParam) {
  return Vertex_py(vertexParam)->getX();
  }

EXPORTPROC double Vertex_py_getY (void *vertexParam) {
  return Vertex_py(vertexParam)->getY();
  }

EXPORTPROC void Vertex_py_setX (void *vertexParam, double valParam) {
  Vertex_py(vertexParam)->setX(valParam);
  }

EXPORTPROC void Vertex_py_setY (void *vertexParam, double valParam) {
  Vertex_py(vertexParam)->setY(valParam);
  }

EXPORTPROC void Vertex_py_SetXY (void *vertexParam, double xParam, double yParam) {
  Vertex_py(vertexParam)->SetXY(xParam, yParam);
  }

//EXPORTPROC void Vertex_py_SetXY (void *vertexParam, TPtParam) {
//  return Vertex_py(vertexParam)->getX();
//  }

EXPORTPROC bool Vertex_py_setPt (void *vertexParam, void *ptParam, bool ownParam) {
  return Vertex_py(vertexParam)->setPt(PointXY_py(ptParam), ownParam);
  }
    // sets the TPointPtr used by the vertex, overriding the default TPointXY
    // the 2nd param specifies whether the TPointPtr is owned by the vertex

EXPORTPROC TPointPtr Vertex_py_getPt (void *vertexParam) {
  return Vertex_py(vertexParam)->getPt();
  }

//EXPORTPROC TPointXY Vertex_py_getPtVal (void *vertexParam) {
//  }

EXPORTPROC TPointPtr *Vertex_py_getPtAddr (void *vertexParam) {
  return Vertex_py(vertexParam)->getPtAddr();
  }
//the following 3 functions to be overridden if sharing is allowed

EXPORTPROC void Vertex_py_Share (void *vertexParam, void **ptParam) {
  Vertex_py(vertexParam)->Share((TPointPtr*)ptParam);
  }
    //if the 1st param is a shared TPointXY0, it will not be changed, otherwise, it will be changed to a shared TPointXY0 using the same xy data
    //this vertex will use the shared TPointXY0 resulting from the above statement

EXPORTPROC void Vertex_py_UnShare (void *vertexParam) {
  Vertex_py(vertexParam)->UnShare();
  } //if the TPointXY0 is shared, it will be replaced with a new, unshared TPointXY0

EXPORTPROC bool Vertex_py_IsShared (void *vertexParam) {
  return Vertex_py(vertexParam)->IsShared();
  } //return true if the TPointXY0 is shared


//TVertexNav EXPORTPROC *Create_Vertex_py () {
//  return Create_Vertex();  }

TVertexNav EXPORTPROC *Create_VertexNav_py () {
  return Create_VertexNav();
  }

void EXPORTPROC Delete_VertexNav_py (TVertexNav *navParam) {
  delete navParam;
  }

TVertexNav *VertexNav_py (void *navParam) {
  return (TVertexNav*)navParam;
  }

typedef TMultiLine0* (*TMultiLineProc) (void*);

TMultiLine0 *MultiLine_py (void *lineParam) {
  return (TMultiLine0*)lineParam;
  }

EXPORTPROC TMultiLineProc get_TMultiLineProc() {
    return MultiLine_py;
  }

EXPORTPROC  TVertexNav *MultiLine_py_PtNav (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->PtNav();
  }

EXPORTPROC bool MultiLine_py_Closed (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->Closed();
  }

EXPORTPROC void MultiLine_py_set_Closed (void *lineParam, void *procParam, bool closedFlag) {
  ((TMultiLineProc)procParam)(lineParam)->set_Closed(closedFlag);
  }

//EXPORTPROC TVertex0 *Create_Vertex (void *lineParam, TPtParam) = 0; //return a new TVertex0 using the xy data in the 1st param

EXPORTPROC TVertex0 *MultiLine_py_Create_Vertex (void *lineParam, void *procParam, void *ptParam, bool ownFlag) {
  return ((TMultiLineProc)procParam)(lineParam)->Create_Vertex(PointXY_py(ptParam));
  }
    //return a new TVertex0 using the TPointXY instance in the first param.
    //if the 2nd param is true, the TVertex0 instance takes ownership of the TPointXY instance

EXPORTPROC TVertex0 *MultiLine_py_AddXY (void *lineParam, void *procParam, double xParam, double yParam) {
  return ((TMultiLineProc)procParam)(lineParam)->AddPt(xParam, yParam);
  }

//EXPORTPROC TVertex0 *AddPt (void *lineParam, TPtParam) = 0; //add a vertex using the x,y data in the 1st param; return the vertex or NULL if not sucessfule

EXPORTPROC TVertex0 *MultiLine_py_AddPt (void *lineParam, void *procParam, void *ptParam, bool ownParam) {
  return ((TMultiLineProc)procParam)(lineParam)->AddPt(PointXY_py(ptParam), ownParam);
  }

EXPORTPROC TVertex0 *MultiLine_py_AddPt_First (void *lineParam, void *procParam, double xParam, double yParam, bool delFlag) {
  TPointXY tempPt (xParam, yParam);
  return ((TMultiLineProc)procParam)(lineParam)->AddPt_First(tempPt, delFlag);
  }

EXPORTPROC TVertex0 *MultiLine_py_AddPt_shared (void *lineParam, void *procParam, void **ptParam) {
  return ((TMultiLineProc)procParam)(lineParam)->AddPt_shared((TPointXY0**)ptParam);
  }

EXPORTPROC bool MultiLine_py_AddVertex (void *lineParam, void *procParam, void *vertexParam) {
  return ((TMultiLineProc)procParam)(lineParam)->AddVertex(Vertex_py(vertexParam));
  }

//EXPORTPROC void set_PtCreator (TPtCreator*) = 0;
    //allows the TMultiLine0 instance to use a different TPointXY0 than the default of TPointXY
    //by creating a derivative of the class TTdhOGR_PtCreator

EXPORTPROC TPointPtr MultiLine_py_CopyPt (void *lineParam, void *procParam, void **ptParam, bool shareFlag) {
  return ((TMultiLineProc)procParam)(lineParam)->CopyPt((TPointXY0**)ptParam, shareFlag);
  }
    //for the current vertex in PtNav(),
    // if the 2nd param is true, copy the 1st param as a shared pt  (see TVertex0::Share)
    // if the 2nd param is false, copy the xy data from the 1st parm

EXPORTPROC TMultiLine0 *MultiLine_py_CopyPts (void *lineParam, void *procParam, void *lineSource, unsigned pos, unsigned numPts, char shareFlag)  {
  return ((TMultiLineProc)procParam)(lineParam)->CopyPts(MultiLine_py(lineSource), pos, numPts, shareFlag);
  }
    // pts are added to the 1st param using data from this PtNav
    // 2nd param is staring at the position within PtNav
    // 3rd param is the number of pts from PtNav
    // 4th param specifies whether the pts are shared, as follows:
      // 0 - pts are never shared, only xy data is used
      // 1 - pt is shared with target if the source pt is shared
      // 2 - all pts are shared

EXPORTPROC void MultiLine_py_CopyPtVals (void *lineParam, void *procParam, void *lineSource) {
  return ((TMultiLineProc)procParam)(lineParam)->CopyPtVals(MultiLine_py(lineSource));
  }
    // for up to the number of pts in this or the number of pts in the 1st param
    // the value of a pt in this copied the pt in the corresponding position of the 1st param

EXPORTPROC bool MultiLine_py_InsertPt (void *lineParam, void *procParam, double xParam, double yParam, unsigned pos) {
  TPointXY tempPt (xParam, yParam);
  return ((TMultiLineProc)procParam)(lineParam)->InsertPt(tempPt, pos);
  }

EXPORTPROC bool MultiLine_py_InsertPts (void *lineParam, void *procParam, void *navParam, unsigned pos) {
  return ((TMultiLineProc)procParam)(lineParam)->InsertPts(VertexNav_py(navParam), pos);
  }
    // the verices contained the 1st param are inserted into PtNav starting as position specified by 2nd param
    // 1st param is emptied

EXPORTPROC void MultiLine_py_AddendMultiLine (void *lineParam, void *procParam, void *navParam) {
  return ((TMultiLineProc)procParam)(lineParam)->AddendMultiLine(VertexNav_py(navParam));
  }

EXPORTPROC void MultiLine_py_PrependMultiLine (void *lineParam, void *procParam, void *navParam) {
  return ((TMultiLineProc)procParam)(lineParam)->PrependMultiLine(VertexNav_py(navParam));
  }

EXPORTPROC void MultiLine_py_ReversePts (void *lineParam, void *procParam) {
  ((TMultiLineProc)procParam)(lineParam)->ReversePts();
  }

EXPORTPROC void MultiLine_py_set_Point (void *lineParam, void *procParam, unsigned pos, double xParam, double yParam) {
  TPointXY tempPt (xParam, yParam);
  ((TMultiLineProc)procParam)(lineParam)->set_Point(pos, tempPt);
  }

EXPORTPROC TPointPtr MultiLine_py_get_Point(void *lineParam, void *procParam, unsigned pos) {
  return ((TMultiLineProc)procParam)(lineParam)->get_Point(pos);
  }

EXPORTPROC void MultiLine_py_ResetExtents (void *lineParam, void *procParam) {
  ((TMultiLineProc)procParam)(lineParam)->ResetExtents();
  }

EXPORTPROC bool MultiLine_py_ExtentsValid (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->ExtentsValid();
  }

EXPORTPROC TCadRect0 *MultiLine_py_GetExtents (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->GetExtents();
  }

EXPORTPROC int MultiLine_py_CleanVertices (void *lineParam, void *procParam, double tolerance) {
  return ((TMultiLineProc)procParam)(lineParam)->CleanVertices(tolerance);
  }

EXPORTPROC void MultiLine_py_UnSharePt (void *lineParam, void *procParam, unsigned pos) {
  ((TMultiLineProc)procParam)(lineParam)->UnSharePt (pos);
  }

EXPORTPROC double MultiLine_py_CalcLength (void *lineParam, void* procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->CalcLength();
  }

EXPORTPROC void MultiLine_py_CalcMidPt (void *lineParam, void *procParam, void *ptParam) {
  TPointXY tempPt = ((TMultiLineProc)procParam)(lineParam)->CalcMidPt();
  PointXY_py_CopyPt(ptParam, &tempPt);
  }

EXPORTPROC TVertex0 *MultiLine_py_NearestVertex (void *lineParam, void *procParam, double xParam, double yParam) {
  TPointXY tempPt (xParam, yParam);
  return ((TMultiLineProc)procParam)(lineParam)->NearestVertex(tempPt);
  }

EXPORTPROC void MultiLine_py_NearestPt (void *lineParam, void *procParam, double xParam, double yParam, void *ptOut) {
  TPointXY tempPt (xParam, yParam);
  tempPt = ((TMultiLineProc)procParam)(lineParam)->NearestPt(tempPt);
  PointXY_py_CopyPt(ptOut, &tempPt);
  }

EXPORTPROC TVertex0 *MultiLine_py_CurrVertex (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->PtNav()->GetData();
  }

EXPORTPROC void MultiLine_py_CurrPt (void *lineParam, void *procParam, void *ptOut) {
  TPointXY tempPt = ((TMultiLineProc)procParam)(lineParam)->CurrVertex()->getPtVal();
  PointXY_py_CopyPt(ptOut, &tempPt);
  } //return the xy data used by the current vertex

EXPORTPROC TVertex0 *MultiLine_py_NextPt (void *lineParam, void *procParam, void *ptParam) {
  return ((TMultiLineProc)procParam)(lineParam)->NextPt(Vertex_py(ptParam));
  }
    // return the next vertex after the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return first vertex

EXPORTPROC TVertex0 *MultiLine_py_PrevPt (void *lineParam, void *procParam, void *ptParam) {
  return ((TMultiLineProc)procParam)(lineParam)->PrevPt(Vertex_py(ptParam));
  }
    // return the next vertex before the 1st param
    // if 1st param is NULL, use CurrVertex()
    // if 1st param is last vertex and Closed(), return last vertex

EXPORTPROC bool MultiLine_py_GotoVertex (void *lineParam, void *procParam, void *ptParam) {
  return ((TMultiLineProc)procParam)(lineParam)->GotoVertex(PointXY_py(ptParam));
  }

EXPORTPROC bool MultiLine_py_MovePt (void *lineParam, void *procParam, double xParam, double yParam) {
  TPointXY tempPt (xParam, yParam);
  return ((TMultiLineProc)procParam)(lineParam)->MovePt(tempPt);
  }

EXPORTPROC bool MultiLine_py_DeleteVertex (void *lineParam, void *procParam, void *ptParam) {
  return ((TMultiLineProc)procParam)(lineParam)->DeleteVertex(Vertex_py(ptParam));
  }

EXPORTPROC bool MultiLine_py_DeleteCurrent (void *lineParam, void *procParam) {
  return ((TMultiLineProc)procParam)(lineParam)->DeleteCurrent();
  }


TMultiLine0 EXPORTPROC *Create_MultiLine_py (TVertexNav *navParam, bool ownParam) {
  return Create_MultiLine(navParam, ownParam);
  }
  // create multiline using 1st param as pt navigator and 2nd param owner navigator owner flag
  // if the default parameters are used, a TVertexNav is created

void EXPORTPROC Delete_MultiLine_py (TMultiLine0 *lineParam) {
  delete lineParam;
  }

TCadOptions *CadOptions_py (void *optParam) {
  return (TCadOptions*)optParam;
  }

EXPORTPROC TCadOptions *Create_CadOptions_py () {
  return new TCadOptions (TCadOptions::duMeters);
  }

EXPORTPROC void Delete_CadOptions_py (TCadOptions *optsParam) {
  delete optsParam; }

EXPORTPROC void CadOptions_py_set_LonLat (void *cadOptions, bool lonlatFlag) {
  CadOptions_py(cadOptions)->set_LonLat(lonlatFlag);
  }

EXPORTPROC bool CadOptions_py_get_LonLat (void *cadOptions) {
  return CadOptions_py(cadOptions)->get_LonLat();
  }

//EXPORTPROC void CadOptions_py_setDistUnitsStr (void *cadOptions, tdhString_py strParam) {
//  CadOptions_py(cadOptions)->setDistUnitsStr(strParam);  }

EXPORTPROC void CadOptions_py_setDistUnits (void *cadOptions, int unitsParam) {
  return CadOptions_py(cadOptions)->set_DistUnits((TCadOptions::UnitsDist)unitsParam);
  }

EXPORTPROC int CadOptions_py_getDistUnits (void *cadOptions) {
  return CadOptions_py(cadOptions)->DistUnits();
  }

EXPORTPROC int CadOptions_py_DistUnitsFromStr (void *cadOptions, tdhString_py strParam) {
  return CadOptions_py(cadOptions)->DistUnits_fromStr(strParam);
  }

EXPORTPROC tdhString_py CadOptions_py_DistUnits_ToStr (void *cadOptions, int unitsParam) {
  return TdhString_toPy(CadOptions_py(cadOptions)->DistUnits_toStr((TCadOptions::UnitsDist)unitsParam));
  }

EXPORTPROC void CadOptions_py_set_DistTolerance (void *cadOptions, double tolerance) {
  CadOptions_py(cadOptions)->set_DistTolerance(tolerance);
  }

EXPORTPROC double CadOptions_py_get_DistTolerance (void *cadOptions) {
  return CadOptions_py(cadOptions)->get_DistTolerance();
  }

}

